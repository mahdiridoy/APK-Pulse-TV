# Ridoy IPTV — Android + Android TV App

Single codebase, works on phone and Android TV (D-pad navigable).

## What's included
- **Live TV**: pulls `https://mahdiridoy.github.io/Tv/mahdi_iptv.m3u8`, re-fetches every time
  the tab opens or on pull-to-refresh, plus a background WorkManager check every 6 hours.
  Configured in `app/src/main/java/com/mahdiridoy/iptvapp/util/Prefs.kt`.
- **Movies & Series**: built-in repo list (`movies/RepoRegistry.kt`) pointing at JSON manifests
  you host yourself:
  ```json
  [
    { "title": "Movie Name", "poster": "https://.../poster.jpg", "streamUrl": "https://.../stream.m3u8" }
  ]
  ```
  Add your own manifest URLs to `RepoRegistry.repos`. No in-app "add repo" UI, as requested.
- **Player**: Media3 ExoPlayer, handles HLS/.m3u8 and progressive streams, works with TV remote
  controls out of the box.
- TV support: `LEANBACK_LAUNCHER` intent filter + banner in the manifest, plus focus-highlight
  styling on every grid item and nav entry so the D-pad always shows what's selected.

## Getting the APK
Push this project to a GitHub repo (or your existing `Tv` repo as a subfolder) and the included
`.github/workflows/build-apk.yml` will build a debug APK automatically on every push to `main`,
and attach it to a GitHub Release for you to download and sideload — no local Android Studio
build needed.

You can also open it in Android Studio directly if you'd rather build/debug locally.

## To customize
- Change the M3U URL: `util/Prefs.kt` → `DEFAULT_M3U_URL`
- Add/remove Movies & Series repos: `movies/RepoRegistry.kt`
- App name/colors: `res/values/strings.xml`, `res/values/colors.xml`
- Replace the placeholder launcher icon/TV banner with real artwork:
  `res/mipmap-*/ic_launcher.png`, `res/drawable/tv_banner.xml`

## Not included (on purpose)
Movies & Series does not include a Cloudstream plugin loader or MovieBox API integration —
those pull from unauthorized streaming sources. The manifest-based repo system above is the
extension point; what you put in your own JSON manifests is up to you.
