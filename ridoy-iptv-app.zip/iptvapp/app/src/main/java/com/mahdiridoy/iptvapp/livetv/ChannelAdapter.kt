package com.mahdiridoy.iptvapp.livetv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mahdiridoy.iptvapp.R
import com.mahdiridoy.iptvapp.databinding.ItemChannelBinding
import com.squareup.picasso.Picasso

class ChannelAdapter(
    private var channels: List<Channel>,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.ChannelViewHolder>() {

    inner class ChannelViewHolder(val binding: ItemChannelBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val binding = ItemChannelBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ChannelViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = channels[position]
        holder.binding.channelName.text = channel.name
        if (!channel.logoUrl.isNullOrBlank()) {
            Picasso.get().load(channel.logoUrl).placeholder(R.drawable.ic_channel_placeholder)
                .into(holder.binding.channelLogo)
        } else {
            holder.binding.channelLogo.setImageResource(R.drawable.ic_channel_placeholder)
        }

        val card = holder.binding.root
        card.isFocusable = true
        card.isFocusableInTouchMode = true
        card.setOnClickListener { onClick(channel) }

        // Visual feedback for TV remote D-pad focus
        card.setOnFocusChangeListener { view, hasFocus ->
            view.animate().scaleX(if (hasFocus) 1.1f else 1f)
                .scaleY(if (hasFocus) 1.1f else 1f)
                .setDuration(150)
                .start()
            holder.binding.focusBorder.visibility = if (hasFocus) View.VISIBLE else View.INVISIBLE
        }
    }

    override fun getItemCount(): Int = channels.size

    fun updateData(newChannels: List<Channel>) {
        channels = newChannels
        notifyDataSetChanged()
    }
}
