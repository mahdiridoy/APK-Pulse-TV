package com.mahdiridoy.iptvapp.player

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.mahdiridoy.iptvapp.R

/**
 * Plays live TV streams (HLS/.m3u8) and movie/series stream links with the same player.
 * PlayerView's default controls are D-pad focusable out of the box for TV remotes.
 */
class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_URL = "extra_url"
    }

    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Playing"
        val url = intent.getStringExtra(EXTRA_URL)
        supportActionBar?.hide()
        title?.let { }

        if (url.isNullOrBlank()) {
            finish()
            return
        }

        val playerView = findViewById<PlayerView>(R.id.playerView)
        val exoPlayer = ExoPlayer.Builder(this).build()
        player = exoPlayer
        playerView.player = exoPlayer
        playerView.keepScreenOn = true

        val mediaItem = MediaItem.fromUri(url)
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
