package com.mahdiridoy.iptvapp.movies

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.mahdiridoy.iptvapp.databinding.FragmentMoviesBinding
import com.mahdiridoy.iptvapp.player.PlayerActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MoviesFragment : Fragment() {

    private var _binding: FragmentMoviesBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: MovieItemAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMoviesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = MovieItemAdapter(emptyList()) { item ->
            val intent = Intent(requireContext(), PlayerActivity::class.java)
            intent.putExtra(PlayerActivity.EXTRA_TITLE, item.title)
            intent.putExtra(PlayerActivity.EXTRA_URL, item.streamUrl)
            startActivity(intent)
        }

        val spanCount = if (resources.configuration.screenWidthDp > 600) 5 else 3
        binding.movieGrid.layoutManager = GridLayoutManager(requireContext(), spanCount)
        binding.movieGrid.adapter = adapter

        buildRepoButtons()

        // Load first repo by default
        RepoRegistry.repos.firstOrNull()?.let { loadRepo(it) }
    }

    private fun buildRepoButtons() {
        binding.repoButtonRow.removeAllViews()
        RepoRegistry.repos.forEach { repo ->
            val button = Button(requireContext()).apply {
                text = repo.name
                isFocusable = true
                isFocusableInTouchMode = true
                setOnClickListener { loadRepo(repo) }
            }
            binding.repoButtonRow.addView(button)
        }
    }

    private fun loadRepo(repo: Repo) {
        binding.moviesEmptyState.visibility = View.GONE
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val items = withContext(Dispatchers.IO) { RepoRepository.fetchItems(repo) }
                adapter.updateData(items)
                binding.moviesEmptyState.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Couldn't load ${repo.name}: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                binding.moviesEmptyState.visibility = View.VISIBLE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
