package com.mahdiridoy.iptvapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.mahdiridoy.iptvapp.databinding.ActivityMainBinding
import com.mahdiridoy.iptvapp.livetv.LiveTvFragment
import com.mahdiridoy.iptvapp.movies.MoviesFragment
import com.mahdiridoy.iptvapp.util.PlaylistRefreshWorker
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            showLiveTv()
        }

        binding.navLiveTv.setOnClickListener { showLiveTv() }
        binding.navMovies.setOnClickListener { showMovies() }

        // Request initial focus on the nav rail so the remote D-pad works immediately
        binding.navLiveTv.requestFocus()

        schedulePlaylistRefresh()
    }

    private fun showLiveTv() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.contentContainer, LiveTvFragment())
            .commit()
    }

    private fun showMovies() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.contentContainer, MoviesFragment())
            .commit()
    }

    /**
     * Checks your GitHub M3U for changes every 6 hours in the background,
     * on top of the always-fresh fetch that happens whenever Live TV opens.
     */
    private fun schedulePlaylistRefresh() {
        val request = PeriodicWorkRequestBuilder<PlaylistRefreshWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "playlist_refresh",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
