package com.mahdiridoy.iptvapp.livetv

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.mahdiridoy.iptvapp.databinding.FragmentLiveTvBinding
import com.mahdiridoy.iptvapp.player.PlayerActivity
import com.mahdiridoy.iptvapp.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LiveTvFragment : Fragment() {

    private var _binding: FragmentLiveTvBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: ChannelAdapter
    private var allChannels: List<Channel> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLiveTvBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = ChannelAdapter(emptyList()) { channel ->
            val intent = Intent(requireContext(), PlayerActivity::class.java)
            intent.putExtra(PlayerActivity.EXTRA_TITLE, channel.name)
            intent.putExtra(PlayerActivity.EXTRA_URL, channel.streamUrl)
            startActivity(intent)
        }

        // 5 columns on TV-sized screens, fewer on phones - simple width-based heuristic
        val spanCount = if (resources.configuration.screenWidthDp > 600) 5 else 3
        binding.channelGrid.layoutManager = GridLayoutManager(requireContext(), spanCount)
        binding.channelGrid.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadPlaylist(forceRefresh = true) }

        loadPlaylist(forceRefresh = false)
    }

    /**
     * Always re-fetches the M3U from your GitHub URL. Since you commit a fresh
     * output.m3u/ridoyiptv.m3u daily via your Tv pipeline, this keeps the app in sync
     * every time the user opens Live TV or pulls to refresh.
     */
    private fun loadPlaylist(forceRefresh: Boolean) {
        binding.swipeRefresh.isRefreshing = true
        val url = Prefs.getPlaylistUrl(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val channels = withContext(Dispatchers.IO) { M3uParser.fetch(url) }
                allChannels = channels
                adapter.updateData(channels)
                binding.emptyState.visibility = if (channels.isEmpty()) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Couldn't load playlist: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                binding.emptyState.visibility = if (allChannels.isEmpty()) View.VISIBLE else View.GONE
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
