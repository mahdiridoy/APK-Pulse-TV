plugins {
    // Bumped from 8.5.0 - CloudStream's :library dependency (see app/build.gradle.kts)
    // requires compileSdk 37, and AGP 8.5.0's max supported compileSdk is 34. AGP
    // 9.1.1 is CloudStream's own upstream repo's exact AGP version, so it's a known
    // pairing rather than a guess. This is a hard Gradle-version-bump requirement too
    // (see gradle/wrapper/gradle-wrapper.properties) - not optional once compileSdk 37
    // is needed.
    id("com.android.application") version "9.1.1" apply false
    // NOT applying "org.jetbrains.kotlin.android" anymore, and deliberately - confirmed
    // by the actual build failure this caused: "The 'org.jetbrains.kotlin.android'
    // plugin is no longer required for Kotlin support since AGP 9.0 ... Remove the
    // 'org.jetbrains.kotlin.android' plugin from this project's build file." AGP 9
    // builds Kotlin support directly into com.android.application - applying the old
    // plugin on top now hard-fails instead of just being redundant. See
    // app/build.gradle.kts for what replaces kotlinOptions{} because of this.
    //
    // AGP 9's built-in Kotlin bundles Kotlin Gradle Plugin 2.2.10 by default, older
    // than the 2.4.0 CloudStream's :library was compiled with. This classpath
    // dependency is the officially documented way to override that bundled version
    // project-wide (see "runtime dependency on Kotlin Gradle Plugin upgrade" at
    // https://developer.android.com/build/releases/agp-9-0-0-release-notes) -
    // achieves the same "make Kotlin 2.4.0 the one actually used" goal the removed
    // plugin's version used to, without applying the plugin itself.
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.0" apply false
    // Bumped from 1.9.24-1.0.20 - KSP versioning decoupled from the old
    // <kotlinVersion>-<kspVersion> format as of KSP 2.3.0; 2.3.5 is both confirmed to
    // support Kotlin 2.4.0+ AND is past the version (2.3.1) where KSP added AGP 9
    // built-in-Kotlin support in the first place - an older KSP hard-refuses to run
    // under built-in Kotlin at all ("KSP is not compatible with Android Gradle
    // Plugin's built-in Kotlin"), so this isn't just a nice-to-have version bump.
    id("com.google.devtools.ksp") version "2.3.5" apply false
}

buildscript {
    dependencies {
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.0")
    }
}
