plugins {
    // Bumped from 8.5.0 - CloudStream's :library dependency (see app/build.gradle.kts)
    // requires compileSdk 37, and AGP 8.5.0's max supported compileSdk is 34. AGP
    // 9.1.1 is CloudStream's own upstream repo's exact AGP version, so it's a known
    // pairing rather than a guess. This is a hard Gradle-version-bump requirement too
    // (see gradle/wrapper/gradle-wrapper.properties) - not optional once compileSdk 37
    // is needed.
    id("com.android.application") version "9.1.1" apply false
    // Bumped from 1.9.24 to match the Kotlin version :library was actually compiled
    // with - Kotlin's compiled-metadata compatibility across major versions (1.9.x
    // consumer reading 2.4.0-compiled classes) isn't guaranteed, so matching exactly
    // is the safe choice rather than relying on cross-version compatibility holding.
    id("org.jetbrains.kotlin.android") version "2.4.0" apply false
    // New: Kotlin >= 2.0 moved the Compose compiler out of a separately-pinned
    // artifact (the old composeOptions.kotlinCompilerExtensionVersion) into this
    // Kotlin-version-matched Gradle plugin - see app/build.gradle.kts.
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.0" apply false
    // Bumped from 1.9.24-1.0.20 - KSP versioning decoupled from the old
    // <kotlinVersion>-<kspVersion> format as of KSP 2.3.0; 2.3.5 is confirmed to
    // support Kotlin 2.4.0+.
    id("com.google.devtools.ksp") version "2.3.5" apply false
}
