# Third-party license notice

This app depends on the `:library` module of **CloudStream**
(https://github.com/recloudstream/cloudstream), used to load and run
CloudStream-compatible plugins (`.cs3` files) - see
`app/src/main/java/com/mahdiridoy/iptvapp/plugins/CloudStreamPluginManager.kt`.

CloudStream is licensed under the **GNU General Public License v3.0**
(see `LICENSE` at the project root). Because this app links against
CloudStream's library at build time, **this app as a whole is a
derivative work and must also be distributed under GPL-3.0** - source
code must be made available to anyone the compiled app is given to,
under the same license, including any modifications made here.

What this means in practice:
- If you distribute a built APK (even privately, to friends, etc.),
  you're obligated to make this project's full source available to
  whoever receives it, under GPL-3.0.
- You cannot relicense this app under a more restrictive license, sell
  it as closed-source, or add usage restrictions GPL-3.0 doesn't
  allow.
- This applies regardless of how small the CloudStream-dependent part
  is relative to the rest of the app - GPL-3.0's copyleft covers the
  whole combined work once linked.

If closed-source distribution matters for this project, the
alternative is dropping the CloudStream `:library` dependency and
`plugins/CloudStreamPluginManager.kt`, and writing a native scraper
against a specific source's site/API directly instead (no GPL
obligation, but fragile - breaks whenever that site changes, and
carries its own separate copyright/ToS considerations).
