package com.mahdiridoy.iptvapp.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.mahdiridoy.iptvapp.catalog.CategoryShelf
import com.mahdiridoy.iptvapp.catalog.ContentSummary
import com.mahdiridoy.iptvapp.data.db.HistoryEntity

/**
 * Milestone 3: real featured rows (a couple of Movies categories, a couple of
 * Series categories). Milestone 5 adds a Continue Watching row above them,
 * from real Room progress data.
 * [onItemClick] hands back the tapped [ContentSummary] so the nav host can
 * route to the right details screen based on its `type`. [onResumeClick]
 * hands back the tapped Continue Watching [HistoryEntity] so the nav host can
 * resume it directly (it already has the stream URL and saved position).
 */
@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel = viewModel(),
    onItemClick: (ContentSummary) -> Unit = {},
    onResumeClick: (HistoryEntity) -> Unit = {}
) {
    val state by viewModel.uiState.collectAsState()
    val continueWatching by viewModel.continueWatching.collectAsState()

    when (val current = state) {
        is HomeUiState.Loading -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }

        is HomeUiState.Error -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Couldn't load your home feed", style = MaterialTheme.typography.titleMedium)
                Text(current.message, style = MaterialTheme.typography.bodySmall)
            }
        }

        is HomeUiState.Loaded -> {
            if (current.rows.isEmpty() && continueWatching.isEmpty()) {
                Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Nothing to show yet - add titles to your Movies/Series repos.",
                        modifier = Modifier.padding(24.dp)
                    )
                }
                return
            }
            LazyColumn(modifier = modifier.fillMaxSize()) {
                if (continueWatching.isNotEmpty()) {
                    item {
                        ContinueWatchingShelf(items = continueWatching, onClick = onResumeClick)
                    }
                }
                items(current.rows, key = { it.name }) { row ->
                    CategoryShelf(name = row.name, items = row.items, onItemClick = onItemClick)
                }
            }
        }
    }
}

@Composable
private fun ContinueWatchingShelf(items: List<HistoryEntity>, onClick: (HistoryEntity) -> Unit) {
    Column {
        Text(
            "Continue Watching",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp)
        ) {
            items(items, key = { it.contentId }) { entry ->
                val percent = if (entry.durationMs > 0) {
                    (entry.positionMs * 100 / entry.durationMs).coerceIn(0, 100)
                } else 0
                Column(modifier = Modifier.width(160.dp).clickable { onClick(entry) }) {
                    Box {
                        if (entry.posterUrl != null) {
                            AsyncImage(
                                model = entry.posterUrl,
                                contentDescription = entry.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .width(160.dp)
                                    .height(90.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .width(160.dp)
                                    .height(90.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                            )
                        }
                    }
                    Text(
                        entry.title,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    if (percent > 0) {
                        Text(
                            "$percent% watched",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
    }
}
