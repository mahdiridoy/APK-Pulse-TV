package com.mahdiridoy.iptvapp.movies

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mahdiridoy.iptvapp.catalog.CatalogRepository
import com.mahdiridoy.iptvapp.catalog.MovieCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface MoviesUiState {
    data object Loading : MoviesUiState
    data class Loaded(val categories: List<MovieCategory>) : MoviesUiState
    data class Error(val message: String) : MoviesUiState
}

/**
 * Milestone 2: fetches and parses the real Movies manifests. Deliberately not
 * wired to a polished grid/details UI yet (Milestone 3) - [MoviesUiState] only
 * needs to prove the data layer works end to end.
 */
class MoviesViewModel : ViewModel() {

    private val _uiState = MutableStateFlow<MoviesUiState>(MoviesUiState.Loading)
    val uiState: StateFlow<MoviesUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh(forceRefresh: Boolean = false) {
        _uiState.value = MoviesUiState.Loading
        viewModelScope.launch {
            _uiState.value = runCatching { CatalogRepository.fetchAllMovieCategories(forceRefresh) }
                .fold(
                    onSuccess = { MoviesUiState.Loaded(it) },
                    onFailure = { MoviesUiState.Error(it.message ?: "Failed to load movies") }
                )
        }
    }

    /** Looks up a single movie from whatever's already loaded - no separate network call. */
    fun findById(id: String): com.mahdiridoy.iptvapp.catalog.MovieDetail? {
        val loaded = _uiState.value as? MoviesUiState.Loaded ?: return null
        return loaded.categories.flatMap { it.items }.firstOrNull { it.summary.id == id }
    }
}
