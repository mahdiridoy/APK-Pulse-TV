package com.mahdiridoy.iptvapp.livetv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.mahdiridoy.iptvapp.R
import com.mahdiridoy.iptvapp.databinding.ItemChannelBinding

class ChannelAdapter(
    private var channels: List<Channel>,
    private val onClick: (Channel) -> Unit,
    private val onFavoriteClick: (Channel) -> Unit = {}
) : RecyclerView.Adapter<ChannelAdapter.ChannelViewHolder>() {

    /** Stream URLs of currently-favorited channels - see [Channel.streamUrl], the same id Favorites uses. */
    private var favoriteUrls: Set<String> = emptySet()

    inner class ChannelViewHolder(val binding: ItemChannelBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val binding = ItemChannelBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ChannelViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = channels[position]
        holder.binding.channelName.text = channel.name
        if (!channel.logoUrl.isNullOrBlank()) {
            holder.binding.channelLogo.load(channel.logoUrl) {
                placeholder(R.drawable.ic_channel_placeholder)
                error(R.drawable.ic_channel_placeholder)
            }
        } else {
            holder.binding.channelLogo.setImageResource(R.drawable.ic_channel_placeholder)
        }

        val isFavorite = channel.streamUrl in favoriteUrls
        holder.binding.favoriteIcon.setImageResource(
            if (isFavorite) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border
        )
        holder.binding.favoriteIcon.setOnClickListener { onFavoriteClick(channel) }

        val card = holder.binding.root
        card.isFocusable = true
        card.setOnClickListener { onClick(channel) }

        // Visual feedback for TV remote D-pad focus
        card.setOnFocusChangeListener { view, hasFocus ->
            view.animate().scaleX(if (hasFocus) 1.1f else 1f)
                .scaleY(if (hasFocus) 1.1f else 1f)
                .setDuration(150)
                .start()
            holder.binding.focusBorder.visibility = if (hasFocus) View.VISIBLE else View.INVISIBLE
        }
    }

    override fun getItemCount(): Int = channels.size

    fun updateData(newChannels: List<Channel>) {
        channels = newChannels
        notifyDataSetChanged()
    }

    /** Called whenever the favorites set changes so hearts stay in sync without a full data reload. */
    fun updateFavorites(urls: Set<String>) {
        favoriteUrls = urls
        notifyDataSetChanged()
    }
}
