package com.mahdiridoy.iptvapp.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.mahdiridoy.iptvapp.MainActivity
import com.mahdiridoy.iptvapp.R
import com.mahdiridoy.iptvapp.catalog.CatalogSyncManager
import com.mahdiridoy.iptvapp.livetv.M3uParser
import com.mahdiridoy.iptvapp.plugins.CloudStreamPluginManager
import com.mahdiridoy.iptvapp.update.UpdateChecker
import com.mahdiridoy.iptvapp.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Shown once per app open: a 10s ad screen while the app checks the M3U for
 * updates, warms the Movies/Series catalog cache, and checks GitHub for a new
 * app version in the background, then moves on to MainActivity automatically.
 * Ad only ever shows here, never again mid-session.
 */
class SplashActivity : AppCompatActivity() {

    companion object {
        // Host this exact file (see ad_page_snippet.html in the project root)
        // on your GitHub Pages site. Most ad networks tie a zone to a specific
        // registered domain, and a real page load (not an in-memory data: URI)
        // matches what they expect far more reliably.
        private const val AD_PAGE_URL = "https://mahdiridoy.github.io/Tv/ad.html"
    }

    private var updateInfo: UpdateChecker.ReleaseInfo? = null
    private var updateCheckReason: String = ""
    private var pageLoadFailed = false

    @Volatile private var m3uDone = false
    @Volatile private var moviesDone = false
    @Volatile private var seriesDone = false
    @Volatile private var updateDone = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val webView = findViewById<WebView>(R.id.adWebView)
        val countdownText = findViewById<TextView>(R.id.countdownText)
        // Always-on native overlay: whatever the hosted ad.html does or doesn't show,
        // the user still sees real progress and a real countdown from the app itself.
        countdownText.visibility = View.VISIBLE

        // Ads stay on for every device including TV - shortening the window to 5s
        // (below, and in ad_page_snippet.html/ad.html to match) is the actual fix for
        // TV load/lag instead of skipping the ad screen outright.
        setUpAdWebView(webView, countdownText)
        webView.loadUrl(AD_PAGE_URL)

        // Background work while the ad is showing: Live TV M3U refresh, Movies/Series
        // catalog sync (streamed straight into Room - see CatalogSyncManager; a 304
        // Not Modified response means this is a fast no-op most launches), and version
        // check - all run concurrently, not one after another, so the full 5s is
        // actually available to all of them. None of this blocks proceed(): if the
        // catalog sync is still running when the user opens Movies & Series, Paging3's
        // Room integration auto-invalidates as new rows land, so the grid just keeps
        // filling in - it doesn't wait on this job to finish first.
        lifecycleScope.launch {
            val m3uJob = launch(Dispatchers.IO) {
                try {
                    M3uParser.fetch(Prefs.getPlaylistUrl(this@SplashActivity))
                } catch (_: Exception) { /* non-fatal, LiveTvFragment will retry */ }
                m3uDone = true
            }
            val catalogJob = launch(Dispatchers.IO) {
                runCatching { CatalogSyncManager.sync(applicationContext) }
                moviesDone = true
                seriesDone = true
            }
            // Re-loads any previously-installed CloudStream .cs3 plugin(s) so their
            // MainAPI providers are registered again (PathClassLoader/APIHolder don't
            // survive a process restart) - see CloudStreamPluginManager.
            launch(Dispatchers.IO) {
                runCatching { CloudStreamPluginManager.reloadInstalledPlugins(applicationContext) }
            }
            val updateJob = launch(Dispatchers.IO) {
                try {
                    val (info, reason) = UpdateChecker.checkForUpdateVerbose()
                    updateInfo = info
                    updateCheckReason = reason
                } catch (e: Exception) {
                    updateCheckReason = "Update check crashed: ${e.message}"
                }
                updateDone = true
            }
            m3uJob.join()
            catalogJob.join()
            updateJob.join()
        }

        var secondsLeft = 5
        val handler = Handler(Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                if (secondsLeft <= 0) {
                    proceed()
                    return
                }
                // Always reflects real state - whichever job hasn't finished yet is
                // what's actually still shown, not a canned message.
                val step = when {
                    !m3uDone -> getString(R.string.wait_step_channels)
                    !moviesDone || !seriesDone -> getString(R.string.wait_step_catalog)
                    !updateDone -> getString(R.string.wait_step_update)
                    else -> getString(R.string.wait_step_ready)
                }
                countdownText.text = "$step  •  ${getString(R.string.wait_seconds, secondsLeft)}"
                secondsLeft -= 1
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(tick)
    }

    private fun setUpAdWebView(webView: WebView, countdownText: TextView) {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        // Display-only: the ad renders and loads normally, but nothing in it is
        // tappable. This is deliberate - it means nobody can accidentally (or
        // via a bait creative like the "please wait" redirect we saw) end up
        // tapping through to wherever the ad script wants to send them.
        webView.isClickable = false
        webView.isLongClickable = false
        webView.setOnTouchListener { _, _ -> true }
        // Most ad networks (including this one) rely on third-party cookies to
        // serve/track creatives - WebView blocks these by default.
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        // Ad tags frequently deliver via window.open() (popunders); without
        // multi-window support enabled, WebView silently drops them with
        // nothing visibly happening.
        webView.settings.setSupportMultipleWindows(true)
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message
            ): Boolean {
                // Swallow the popup silently instead of leaving it unhandled -
                // this still counts the ad impression without disrupting the
                // 10-second countdown UI.
                val popup = WebView(this@SplashActivity)
                popup.settings.javaScriptEnabled = true
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }
        }
        // The hosted ad.html page has its own countdown/status UI. If it fails
        // to load (no internet, DNS issue, page not uploaded yet), fall back
        // to the plain native countdown so the screen isn't just blank/broken.
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                // Ad tags sometimes try to redirect through non-http(s) schemes
                // (intent://, market://, etc.) to bounce out to other apps/stores.
                // WebView can't navigate those directly - it just shows a raw
                // "Webpage not available" error. Swallow them here instead so the
                // splash screen stays clean regardless of what the ad script tries.
                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                    return true
                }
                return false
            }

            override fun onReceivedError(
                view: WebView, request: WebResourceRequest, error: WebResourceError
            ) {
                if (request.isForMainFrame) {
                    pageLoadFailed = true
                    countdownText.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun proceed() {
        val intent = Intent(this, MainActivity::class.java)
        updateInfo?.let {
            intent.putExtra(MainActivity.EXTRA_UPDATE_TAG, it.tagName)
            intent.putExtra(MainActivity.EXTRA_UPDATE_APK_URL, it.apkUrl)
        }
        intent.putExtra(MainActivity.EXTRA_UPDATE_CHECK_REASON, updateCheckReason)
        startActivity(intent)
        finish()
    }
}
