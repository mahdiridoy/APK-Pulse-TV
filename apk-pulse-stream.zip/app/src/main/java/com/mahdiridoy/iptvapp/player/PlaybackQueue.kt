package com.mahdiridoy.iptvapp.player

import com.mahdiridoy.iptvapp.catalog.Quality

/**
 * Holds the current playback list in memory instead of passing it through Intent
 * extras. Large M3U playlists (hundreds/thousands of channels) blow past Android's
 * Binder transaction size limit if put in an Intent, which crashes the app the
 * moment you tap a channel. Since PlayerActivity always launches from the same
 * process, a simple in-memory singleton avoids that entirely.
 *
 * Milestone 4 adds three optional, parallel fields (contentIds, qualityOptions,
 * startPositionMs) used only by Movies/Series playback - for history/resume
 * tracking and manual quality-URL switching. [set] (used by Live TV, unchanged)
 * fills them with harmless defaults; Movies/Series use [setWithDetails] instead.
 */
object PlaybackQueue {
    var titles: List<String> = emptyList()
    var urls: List<String> = emptyList()
    var startIndex: Int = 0

    /** contentId per item, for history/resume writes. Null = not tracked (Live TV). */
    var contentIds: List<String?> = emptyList()

    /** Alternate quality URLs per item. An empty list means "no manual switch UI" - Live TV's
     * single HLS URL still gets adaptive-rendition switching in [PlayerActivity], just not this. */
    var qualityOptions: List<List<Quality>> = emptyList()

    /** Resume position for the initially-selected item only (ignored when swiping/paging). */
    var startPositionMs: Long = 0L

    /** Extra request headers (Referer, sometimes an overriding User-Agent) some links
     * need beyond the app-wide default - keyed by the exact stream URL. Populated for
     * CloudStream-plugin-sourced links (see CloudStreamBridge.resolveLinks); empty
     * for M3U-catalog/Live TV links, which fall back to PlayerActivity's default UA.
     * Looked up by URL rather than threaded through every list above so quality
     * switching (which just swaps in a Quality's .url) keeps working unchanged. */
    var urlHeaders: Map<String, Map<String, String>> = emptyMap()

    /** Live TV's call site - unchanged from before Milestone 4. */
    fun set(titles: List<String>, urls: List<String>, startIndex: Int) {
        this.titles = titles
        this.urls = urls
        this.startIndex = startIndex
        this.contentIds = List(titles.size) { null }
        this.qualityOptions = List(titles.size) { emptyList() }
        this.startPositionMs = 0L
        this.urlHeaders = emptyMap()
    }

    /** Movies/Series call site - carries history ids, quality alternates, and a resume position. */
    fun setWithDetails(
        titles: List<String>,
        urls: List<String>,
        startIndex: Int,
        contentIds: List<String?>,
        qualityOptions: List<List<Quality>>,
        startPositionMs: Long,
        urlHeaders: Map<String, Map<String, String>> = emptyMap()
    ) {
        this.titles = titles
        this.urls = urls
        this.startIndex = startIndex
        this.contentIds = contentIds
        this.qualityOptions = qualityOptions
        this.startPositionMs = startPositionMs
        this.urlHeaders = urlHeaders
    }
}
