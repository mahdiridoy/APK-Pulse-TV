package com.mahdiridoy.iptvapp.movies

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mahdiridoy.iptvapp.catalog.CategoryShelf
import com.mahdiridoy.iptvapp.catalog.ContentSummary

/**
 * Milestone 3: real poster shelves per category, pulling from
 * [com.mahdiridoy.iptvapp.catalog.CatalogRepository]. Tapping a poster hands
 * its id to [onMovieClick], which the nav host turns into a details route.
 *
 * [MoviesFragment], [RepoRegistry] and [RepoRepository] in this package are
 * the old flat-list prototype - left in place, unused, superseded by
 * [com.mahdiridoy.iptvapp.catalog.CatalogRepository].
 */
@Composable
fun MoviesScreen(
    modifier: Modifier = Modifier,
    viewModel: MoviesViewModel,
    onMovieClick: (String) -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    when (val current = state) {
        is MoviesUiState.Loading -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }

        is MoviesUiState.Error -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Couldn't load movies", style = MaterialTheme.typography.titleMedium)
                Text(current.message, style = MaterialTheme.typography.bodySmall)
            }
        }

        is MoviesUiState.Loaded -> {
            if (current.categories.isEmpty()) {
                Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No movies found in the configured repos.")
                }
                return
            }
            LazyColumn(modifier = modifier.fillMaxSize()) {
                items(current.categories, key = { it.name }) { category ->
                    CategoryShelf(
                        name = category.name,
                        items = category.items.map { it.summary },
                        onItemClick = { summary: ContentSummary -> onMovieClick(summary.id) }
                    )
                }
            }
        }
    }
}
