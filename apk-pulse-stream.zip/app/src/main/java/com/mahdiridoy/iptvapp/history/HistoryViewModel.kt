package com.mahdiridoy.iptvapp.history

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mahdiridoy.iptvapp.data.LibraryRepository
import com.mahdiridoy.iptvapp.data.db.HistoryEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = LibraryRepository.getInstance(application)

    val history: StateFlow<List<HistoryEntity>> = repository.observeHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun removeEntry(contentId: String) {
        viewModelScope.launch { repository.removeHistoryEntry(contentId) }
    }

    fun clearAll() {
        viewModelScope.launch { repository.clearHistory() }
    }
}
