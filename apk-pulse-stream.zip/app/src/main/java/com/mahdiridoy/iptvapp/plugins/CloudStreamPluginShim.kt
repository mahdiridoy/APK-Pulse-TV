package com.lagradost.cloudstream3.plugins

import android.content.Context
import android.content.res.Resources

/**
 * A real build failed with "Unresolved reference 'Plugin'" - `Plugin` (the
 * Android-specific subclass of [BasePlugin] that adds a `Context`-aware `load()` and
 * `resources`) is only defined in CloudStream's `:app` module
 * (`app/src/main/java/com/lagradost/cloudstream3/plugins/Plugin.kt`), not in the
 * `:library` module this project actually depends on via JitPack (see
 * app/build.gradle.kts) - and `:app` can't be added as a dependency of another
 * `com.android.application` module (a hard Android Gradle Plugin restriction), so
 * there's no way to pull in the real class directly.
 *
 * This is a from-scratch reimplementation matching the real class's package, name,
 * and member signatures exactly (ported by reading CloudStream's actual source, not
 * guessed) - JVM class/method resolution works by (owner class binary name, method
 * name, descriptor), not by "compiled from the same source", so a real `.cs3` plugin
 * that extends `com.lagradost.cloudstream3.plugins.Plugin` and overrides
 * `load(context: Context)` resolves against *this* class the same way it would
 * against the real one, the same way any `compileOnly`/stub-jar dependency works in
 * the Java/Android ecosystem generally.
 *
 * Deliberately omits `registerVideoClickAction`/`openSettings` from the real class -
 * they depend on other app-module-only types this project has no use for. A specific
 * plugin that calls one of those (most providers - focused on search/load/loadLinks -
 * won't) would fail at that specific call with a NoSuchMethodError rather than
 * anything failing to build; not worth reimplementing further app-only classes for a
 * capability nothing this app's own UI uses yet.
 */
abstract class Plugin : BasePlugin() {
    @Throws(Throwable::class)
    open fun load(context: Context) {
        load()
    }

    /** Holds the plugin's own bundled resources (drawables etc.) when its
     * manifest.json sets requiresResources - see CloudStreamPluginManager. */
    var resources: Resources? = null
}
