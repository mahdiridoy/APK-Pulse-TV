package com.mahdiridoy.iptvapp.catalog.db

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface CatalogDao {

    /** Backs the Movies & Series grid when there's no active search - see [BrowseTileRow]. */
    @Query("SELECT * FROM browse_tiles ORDER BY title COLLATE NOCASE ASC")
    fun pagingSource(): PagingSource<Int, BrowseTileRow>

    /** Same grid, filtered - the title index on both base tables keeps this fast even at 100k+ rows. */
    /**
     * Prefix match, not `LIKE '%' || :query || '%'` - a leading wildcard can't use the
     * title index at all, which meant every keystroke was a full scan across the whole
     * table (134k+ rows) with no way to speed it up. This can use the index (a plain
     * B-tree range scan), which is what actually makes search feel instant at that
     * scale. The honest tradeoff: this only matches titles starting with the typed
     * text, not a match anywhere inside it - "Avengers" won't turn up for "veng". A
     * proper arbitrary-substring search at this scale really wants an FTS index, which
     * this isn't (yet) - flag if prefix-only feels too limiting and that's worth adding.
     */
    @Query("SELECT * FROM browse_tiles WHERE title LIKE :query || '%' ORDER BY title COLLATE NOCASE ASC")
    fun searchPagingSource(query: String): PagingSource<Int, BrowseTileRow>

    /** Every episode of one show, in watch order - what builds a series' auto-play queue. */
    @Query("SELECT * FROM series_episodes WHERE show_title = :showTitle ORDER BY season ASC, episode ASC")
    suspend fun episodesForShow(showTitle: String): List<SeriesEpisodeRow>

    /** For small "just show a few" cases like Home's featured row - full pagination would be overkill there. */
    @Query("SELECT * FROM browse_tiles ORDER BY title COLLATE NOCASE ASC LIMIT :limit")
    suspend fun firstTiles(limit: Int): List<BrowseTileRow>

    @Query("SELECT * FROM movies WHERE id = :id LIMIT 1")
    suspend fun movieById(id: String): MovieRow?

    // Deliberately not suspend: called from inside CatalogSyncManager's streaming parse
    // loop (a plain non-suspend lambda passed to the inline M3uParser.streamEntries),
    // which already runs entirely on Dispatchers.IO - a direct blocking Room call there
    // is correct and avoids needing runBlocking or a suspend lambda in an inline
    // function (both work, but this is the more certain, simpler option). Every other
    // DAO method here that's called from regular suspend/coroutine contexts stays
    // suspend as normal.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertMoviesBlocking(rows: List<MovieRow>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertEpisodesBlocking(rows: List<SeriesEpisodeRow>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMovies(rows: List<MovieRow>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEpisodes(rows: List<SeriesEpisodeRow>)

    /**
     * Removes anything not touched by the sync pass that started at [cutoff] - i.e.
     * whatever's no longer in the remote M3U. Called once, after a full streaming pass
     * completes successfully; rows are upserted in place throughout the pass itself, so
     * readers never see a gap, and this only ever removes what's genuinely gone
     * upstream. See [com.mahdiridoy.iptvapp.catalog.CatalogSyncManager].
     */
    @Query("DELETE FROM movies WHERE last_synced_at < :cutoff")
    suspend fun deleteStaleMovies(cutoff: Long)

    @Query("DELETE FROM series_episodes WHERE last_synced_at < :cutoff")
    suspend fun deleteStaleEpisodes(cutoff: Long)

    @Query("SELECT COUNT(*) FROM movies")
    suspend fun movieCount(): Int

    @Query("SELECT COUNT(*) FROM series_episodes")
    suspend fun episodeCount(): Int
}
