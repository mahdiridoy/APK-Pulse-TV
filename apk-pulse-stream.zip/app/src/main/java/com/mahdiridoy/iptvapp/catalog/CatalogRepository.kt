package com.mahdiridoy.iptvapp.catalog

import com.mahdiridoy.iptvapp.data.ContentType
import com.mahdiridoy.iptvapp.livetv.Channel
import com.mahdiridoy.iptvapp.livetv.M3uParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * Fetches and parses Movies/Series manifests.
 *
 * Expected JSON shape (Movies manifest):
 * ```
 * { "categories": [
 *     { "name": "Action", "items": [
 *         { "id": "movie-1", "title": "...", "poster": "https://...jpg",
 *           "backdrop": "https://...jpg", "description": "...", "year": 2023,
 *           "qualities": [ { "label": "1080p", "url": "https://...m3u8" } ] }
 *     ] }
 * ] }
 * ```
 * Series manifests are the same shape, with each item additionally carrying a
 * `"seasons"` array of `{ "seasonNumber": 1, "episodes": [ ... same fields as a
 * movie item, plus "episodeNumber" ... ] }`.
 *
 * A bare `"streamUrl": "https://..."` on any movie/episode item is still
 * accepted as shorthand for a single "Default" quality, so existing simple
 * manifests (see the old [com.mahdiridoy.iptvapp.movies.RepoRepository] format)
 * don't need to be rewritten to pick up categories - only to add them.
 *
 * Also merges in [M3U_CATALOG_URL], a single M3U playlist (same format as Live
 * TV's) covering both movies and series - see [fetchM3uCatalog] for how
 * series episodes get told apart from standalone movies.
 */
object CatalogRepository {
    private val client = OkHttpClient()

    /** Single M3U source for both Movies and Series - "for now" per your request. */
    private const val M3U_CATALOG_URL = "https://mahdiridoy.github.io/ridoymovieserver/ridoymovieserver.m3u"

    /**
     * An entry counts as a series episode if its title carries a SxxEyy marker
     * (common punctuation/spacing variants - "S01E02", "S1 E2", "S01.E02", etc).
     * Group 1 = the show title (everything before the marker), group 2 = season
     * number, group 3 = episode number, group 4 = whatever trails the marker
     * (often the actual episode title). Anything that doesn't match is a movie.
     */
    private val seriesEpisodePattern = Regex("""(?i)^(.*?)[\s._-]*S(\d{1,2})\s*E(\d{1,3})\b[\s._-]*(.*)$""")

    @Volatile private var movieCache: List<MovieCategory>? = null
    @Volatile private var seriesCache: List<SeriesCategory>? = null

    @Throws(IOException::class)
    suspend fun fetchMovieCategories(repo: ContentRepo): List<MovieCategory> =
        withContext(Dispatchers.IO) {
            val root = fetchJson(repo.manifestUrl)
            val categories = root.optJSONArray("categories") ?: JSONArray()
            (0 until categories.length()).map { i ->
                val catObj = categories.getJSONObject(i)
                val items = catObj.optJSONArray("items") ?: JSONArray()
                MovieCategory(
                    name = catObj.optString("name", "Untitled"),
                    items = (0 until items.length()).mapNotNull { j ->
                        parseMovieItem(items.getJSONObject(j))
                    }
                )
            }
        }

    @Throws(IOException::class)
    suspend fun fetchSeriesCategories(repo: ContentRepo): List<SeriesCategory> =
        withContext(Dispatchers.IO) {
            val root = fetchJson(repo.manifestUrl)
            val categories = root.optJSONArray("categories") ?: JSONArray()
            (0 until categories.length()).map { i ->
                val catObj = categories.getJSONObject(i)
                val items = catObj.optJSONArray("items") ?: JSONArray()
                SeriesCategory(
                    name = catObj.optString("name", "Untitled"),
                    items = (0 until items.length()).mapNotNull { j ->
                        parseSeriesItem(items.getJSONObject(j))
                    }
                )
            }
        }

    /**
     * Fetches [M3U_CATALOG_URL] once and splits it into movie categories (grouped
     * by the M3U's own group-title) and series categories (grouped shows, each
     * with its episodes organized into seasons) - see [seriesEpisodePattern].
     */
    @Throws(IOException::class)
    private fun fetchM3uCatalog(): Pair<List<MovieCategory>, List<SeriesCategory>> {
        val entries: List<Channel> = M3uParser.fetch(M3U_CATALOG_URL)

        val movieEntries = mutableListOf<Channel>()
        // show title -> season number -> episodes (insertion order preserved both levels)
        val showSeasons = LinkedHashMap<String, LinkedHashMap<Int, MutableList<Episode>>>()
        val showLogo = HashMap<String, String?>()
        val showGroup = HashMap<String, String>()

        for (entry in entries) {
            val match = seriesEpisodePattern.find(entry.name)
            if (match == null) {
                movieEntries.add(entry)
                continue
            }
            val showTitle = match.groupValues[1].trim(' ', '-', '_', '.').ifBlank { entry.name }
            val season = match.groupValues[2].toIntOrNull() ?: 1
            val episodeNumber = match.groupValues[3].toIntOrNull() ?: 0
            val trailingTitle = match.groupValues[4].trim(' ', '-', '_', '.', ':')
            val episodeTitle = trailingTitle.ifBlank { "Episode $episodeNumber" }

            val seasons = showSeasons.getOrPut(showTitle) { LinkedHashMap() }
            val episodes = seasons.getOrPut(season) { mutableListOf() }
            episodes.add(
                Episode(
                    id = "$showTitle-S${season}E$episodeNumber",
                    episodeNumber = episodeNumber,
                    title = episodeTitle,
                    description = null,
                    posterUrl = entry.logoUrl,
                    qualities = listOf(Quality("Default", entry.streamUrl))
                )
            )
            showLogo.putIfAbsent(showTitle, entry.logoUrl)
            showGroup[showTitle] = entry.group
        }

        val movieCategories = movieEntries
            .groupBy { it.group }
            .map { (group, items) ->
                MovieCategory(
                    name = group,
                    items = items.map { entry ->
                        MovieDetail(
                            summary = ContentSummary(
                                id = entry.streamUrl,
                                title = entry.name,
                                posterUrl = entry.logoUrl,
                                backdropUrl = entry.logoUrl,
                                description = null,
                                year = null,
                                type = ContentType.MOVIE
                            ),
                            qualities = listOf(Quality("Default", entry.streamUrl))
                        )
                    }
                )
            }

        val seriesCategories = showSeasons.entries
            .groupBy { (showTitle, _) -> showGroup[showTitle] ?: "Series" }
            .map { (group, showsInGroup) ->
                SeriesCategory(
                    name = group,
                    items = showsInGroup.map { (showTitle, seasonsMap) ->
                        SeriesDetail(
                            summary = ContentSummary(
                                id = showTitle,
                                title = showTitle,
                                posterUrl = showLogo[showTitle],
                                backdropUrl = showLogo[showTitle],
                                description = null,
                                year = null,
                                type = ContentType.SERIES
                            ),
                            seasons = seasonsMap.entries
                                .sortedBy { it.key }
                                .map { (seasonNumber, episodes) ->
                                    Season(seasonNumber, episodes.sortedBy { it.episodeNumber })
                                }
                        )
                    }
                )
            }

        return movieCategories to seriesCategories
    }

    /**
     * Fetches every configured Movies repo plus [M3U_CATALOG_URL] and concatenates
     * their categories. Cached for the process lifetime after the first successful
     * call - the splash screen "warms" this during its ad/countdown window (see
     * [com.mahdiridoy.iptvapp.splash.SplashActivity]) so the Movies screen
     * opens instantly instead of showing its own loading spinner. Pass
     * [forceRefresh] to bypass the cache (not currently wired to any UI -
     * Movies/Series have no pull-to-refresh yet, unlike Live TV).
     */
    suspend fun fetchAllMovieCategories(forceRefresh: Boolean = false): List<MovieCategory> {
        movieCache?.let { if (!forceRefresh) return it }
        val fromRepos = CatalogRegistry.movieRepos().flatMap { repo ->
            runCatching { fetchMovieCategories(repo) }.getOrDefault(emptyList())
        }
        val fromM3u = withContext(Dispatchers.IO) {
            runCatching { fetchM3uCatalog().first }.getOrDefault(emptyList())
        }
        val result = fromRepos + fromM3u
        movieCache = result
        return result
    }

    /** Fetches every configured Series repo plus [M3U_CATALOG_URL] and concatenates their categories. Cached - see [fetchAllMovieCategories]. */
    suspend fun fetchAllSeriesCategories(forceRefresh: Boolean = false): List<SeriesCategory> {
        seriesCache?.let { if (!forceRefresh) return it }
        val fromRepos = CatalogRegistry.seriesRepos().flatMap { repo ->
            runCatching { fetchSeriesCategories(repo) }.getOrDefault(emptyList())
        }
        val fromM3u = withContext(Dispatchers.IO) {
            runCatching { fetchM3uCatalog().second }.getOrDefault(emptyList())
        }
        val result = fromRepos + fromM3u
        seriesCache = result
        return result
    }

    private fun fetchJson(url: String): JSONObject {
        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Failed to fetch $url: HTTP ${response.code}")
            }
            val body = response.body?.string() ?: "{}"
            return JSONObject(body)
        }
    }

    private fun parseMovieItem(obj: JSONObject): MovieDetail? {
        val summary = parseSummary(obj, ContentType.MOVIE) ?: return null
        val qualities = parseQualities(obj)
        if (qualities.isEmpty()) return null
        return MovieDetail(summary, qualities)
    }

    private fun parseSeriesItem(obj: JSONObject): SeriesDetail? {
        val summary = parseSummary(obj, ContentType.SERIES) ?: return null
        val seasonsArray = obj.optJSONArray("seasons") ?: JSONArray()
        val seasons = (0 until seasonsArray.length()).mapNotNull { i ->
            parseSeason(seasonsArray.getJSONObject(i))
        }
        if (seasons.isEmpty()) return null
        return SeriesDetail(summary, seasons)
    }

    private fun parseSeason(obj: JSONObject): Season? {
        val seasonNumber = obj.optInt("seasonNumber", -1)
        if (seasonNumber < 0) return null
        val episodesArray = obj.optJSONArray("episodes") ?: JSONArray()
        val episodes = (0 until episodesArray.length()).mapNotNull { i ->
            parseEpisode(episodesArray.getJSONObject(i))
        }
        if (episodes.isEmpty()) return null
        return Season(seasonNumber, episodes)
    }

    private fun parseEpisode(obj: JSONObject): Episode? {
        val qualities = parseQualities(obj)
        if (qualities.isEmpty()) return null
        val title = obj.optString("title", "Untitled")
        val id = obj.optString("id").ifBlank { title }
        return Episode(
            id = id,
            episodeNumber = obj.optInt("episodeNumber", 0),
            title = title,
            description = obj.optString("description").ifBlank { null },
            posterUrl = obj.optString("poster").ifBlank { null },
            qualities = qualities
        )
    }

    private fun parseSummary(obj: JSONObject, type: ContentType): ContentSummary? {
        val title = obj.optString("title").ifBlank { return null }
        val id = obj.optString("id").ifBlank { title }
        return ContentSummary(
            id = id,
            title = title,
            posterUrl = obj.optString("poster").ifBlank { null },
            backdropUrl = obj.optString("backdrop").ifBlank { null },
            description = obj.optString("description").ifBlank { null },
            year = obj.optInt("year", -1).takeIf { it > 0 },
            type = type
        )
    }

    /** Reads a "qualities" array if present, otherwise falls back to a bare "streamUrl". */
    private fun parseQualities(obj: JSONObject): List<Quality> {
        val qualitiesArray = obj.optJSONArray("qualities")
        if (qualitiesArray != null) {
            return (0 until qualitiesArray.length()).mapNotNull { i ->
                val q = qualitiesArray.getJSONObject(i)
                val url = q.optString("url").ifBlank { return@mapNotNull null }
                Quality(label = q.optString("label", "Default"), url = url)
            }
        }
        val streamUrl = obj.optString("streamUrl")
        return if (streamUrl.isNotBlank()) listOf(Quality("Default", streamUrl)) else emptyList()
    }
}
