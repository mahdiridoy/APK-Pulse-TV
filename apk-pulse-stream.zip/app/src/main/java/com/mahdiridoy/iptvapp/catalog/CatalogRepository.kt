package com.mahdiridoy.iptvapp.catalog

import com.mahdiridoy.iptvapp.data.ContentType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * Fetches and parses Movies/Series manifests.
 *
 * Expected JSON shape (Movies manifest):
 * ```
 * { "categories": [
 *     { "name": "Action", "items": [
 *         { "id": "movie-1", "title": "...", "poster": "https://...jpg",
 *           "backdrop": "https://...jpg", "description": "...", "year": 2023,
 *           "qualities": [ { "label": "1080p", "url": "https://...m3u8" } ] }
 *     ] }
 * ] }
 * ```
 * Series manifests are the same shape, with each item additionally carrying a
 * `"seasons"` array of `{ "seasonNumber": 1, "episodes": [ ... same fields as a
 * movie item, plus "episodeNumber" ... ] }`.
 *
 * A bare `"streamUrl": "https://..."` on any movie/episode item is still
 * accepted as shorthand for a single "Default" quality, so existing simple
 * manifests (see the old [com.mahdiridoy.iptvapp.movies.RepoRepository] format)
 * don't need to be rewritten to pick up categories - only to add them.
 */
object CatalogRepository {
    private val client = OkHttpClient()

    @Volatile private var movieCache: List<MovieCategory>? = null
    @Volatile private var seriesCache: List<SeriesCategory>? = null

    @Throws(IOException::class)
    suspend fun fetchMovieCategories(repo: ContentRepo): List<MovieCategory> =
        withContext(Dispatchers.IO) {
            val root = fetchJson(repo.manifestUrl)
            val categories = root.optJSONArray("categories") ?: JSONArray()
            (0 until categories.length()).map { i ->
                val catObj = categories.getJSONObject(i)
                val items = catObj.optJSONArray("items") ?: JSONArray()
                MovieCategory(
                    name = catObj.optString("name", "Untitled"),
                    items = (0 until items.length()).mapNotNull { j ->
                        parseMovieItem(items.getJSONObject(j))
                    }
                )
            }
        }

    @Throws(IOException::class)
    suspend fun fetchSeriesCategories(repo: ContentRepo): List<SeriesCategory> =
        withContext(Dispatchers.IO) {
            val root = fetchJson(repo.manifestUrl)
            val categories = root.optJSONArray("categories") ?: JSONArray()
            (0 until categories.length()).map { i ->
                val catObj = categories.getJSONObject(i)
                val items = catObj.optJSONArray("items") ?: JSONArray()
                SeriesCategory(
                    name = catObj.optString("name", "Untitled"),
                    items = (0 until items.length()).mapNotNull { j ->
                        parseSeriesItem(items.getJSONObject(j))
                    }
                )
            }
        }

    /**
     * Fetches every configured Movies repo and concatenates their categories.
     * Cached for the process lifetime after the first successful call - the
     * splash screen "warms" this during its ad/countdown window (see
     * [com.mahdiridoy.iptvapp.splash.SplashActivity]) so the Movies screen
     * opens instantly instead of showing its own loading spinner. Pass
     * [forceRefresh] to bypass the cache (not currently wired to any UI -
     * Movies/Series have no pull-to-refresh yet, unlike Live TV).
     */
    suspend fun fetchAllMovieCategories(forceRefresh: Boolean = false): List<MovieCategory> {
        movieCache?.let { if (!forceRefresh) return it }
        val result = CatalogRegistry.movieRepos().flatMap { repo ->
            runCatching { fetchMovieCategories(repo) }.getOrDefault(emptyList())
        }
        movieCache = result
        return result
    }

    /** Fetches every configured Series repo and concatenates their categories. Cached - see [fetchAllMovieCategories]. */
    suspend fun fetchAllSeriesCategories(forceRefresh: Boolean = false): List<SeriesCategory> {
        seriesCache?.let { if (!forceRefresh) return it }
        val result = CatalogRegistry.seriesRepos().flatMap { repo ->
            runCatching { fetchSeriesCategories(repo) }.getOrDefault(emptyList())
        }
        seriesCache = result
        return result
    }

    private fun fetchJson(url: String): JSONObject {
        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Failed to fetch $url: HTTP ${response.code}")
            }
            val body = response.body?.string() ?: "{}"
            return JSONObject(body)
        }
    }

    private fun parseMovieItem(obj: JSONObject): MovieDetail? {
        val summary = parseSummary(obj, ContentType.MOVIE) ?: return null
        val qualities = parseQualities(obj)
        if (qualities.isEmpty()) return null
        return MovieDetail(summary, qualities)
    }

    private fun parseSeriesItem(obj: JSONObject): SeriesDetail? {
        val summary = parseSummary(obj, ContentType.SERIES) ?: return null
        val seasonsArray = obj.optJSONArray("seasons") ?: JSONArray()
        val seasons = (0 until seasonsArray.length()).mapNotNull { i ->
            parseSeason(seasonsArray.getJSONObject(i))
        }
        if (seasons.isEmpty()) return null
        return SeriesDetail(summary, seasons)
    }

    private fun parseSeason(obj: JSONObject): Season? {
        val seasonNumber = obj.optInt("seasonNumber", -1)
        if (seasonNumber < 0) return null
        val episodesArray = obj.optJSONArray("episodes") ?: JSONArray()
        val episodes = (0 until episodesArray.length()).mapNotNull { i ->
            parseEpisode(episodesArray.getJSONObject(i))
        }
        if (episodes.isEmpty()) return null
        return Season(seasonNumber, episodes)
    }

    private fun parseEpisode(obj: JSONObject): Episode? {
        val qualities = parseQualities(obj)
        if (qualities.isEmpty()) return null
        val title = obj.optString("title", "Untitled")
        val id = obj.optString("id").ifBlank { title }
        return Episode(
            id = id,
            episodeNumber = obj.optInt("episodeNumber", 0),
            title = title,
            description = obj.optString("description").ifBlank { null },
            posterUrl = obj.optString("poster").ifBlank { null },
            qualities = qualities
        )
    }

    private fun parseSummary(obj: JSONObject, type: ContentType): ContentSummary? {
        val title = obj.optString("title").ifBlank { return null }
        val id = obj.optString("id").ifBlank { title }
        return ContentSummary(
            id = id,
            title = title,
            posterUrl = obj.optString("poster").ifBlank { null },
            backdropUrl = obj.optString("backdrop").ifBlank { null },
            description = obj.optString("description").ifBlank { null },
            year = obj.optInt("year", -1).takeIf { it > 0 },
            type = type
        )
    }

    /** Reads a "qualities" array if present, otherwise falls back to a bare "streamUrl". */
    private fun parseQualities(obj: JSONObject): List<Quality> {
        val qualitiesArray = obj.optJSONArray("qualities")
        if (qualitiesArray != null) {
            return (0 until qualitiesArray.length()).mapNotNull { i ->
                val q = qualitiesArray.getJSONObject(i)
                val url = q.optString("url").ifBlank { return@mapNotNull null }
                Quality(label = q.optString("label", "Default"), url = url)
            }
        }
        val streamUrl = obj.optString("streamUrl")
        return if (streamUrl.isNotBlank()) listOf(Quality("Default", streamUrl)) else emptyList()
    }
}
