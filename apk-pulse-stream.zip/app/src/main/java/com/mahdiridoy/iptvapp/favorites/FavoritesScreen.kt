package com.mahdiridoy.iptvapp.favorites

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mahdiridoy.iptvapp.data.db.FavoriteEntity

@Composable
fun FavoritesScreen(
    modifier: Modifier = Modifier,
    viewModel: FavoritesViewModel = viewModel(),
    onFavoriteClick: (FavoriteEntity) -> Unit = {}
) {
    val favorites by viewModel.favorites.collectAsState()

    if (favorites.isEmpty()) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("No favorites yet", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Channels, movies and series you favorite will show up here.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        return
    }

    LazyColumn(modifier = modifier.fillMaxSize().padding(vertical = 8.dp)) {
        items(favorites, key = { it.contentId }) { favorite ->
            ListItem(
                headlineContent = { Text(favorite.title) },
                supportingContent = { Text(favorite.type.name) },
                trailingContent = {
                    IconButton(onClick = { viewModel.removeFavorite(favorite.contentId) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Remove from favorites")
                    }
                },
                modifier = Modifier.clickable { onFavoriteClick(favorite) }
            )
        }
    }
}
