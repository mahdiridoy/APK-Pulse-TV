package com.mahdiridoy.iptvapp.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mahdiridoy.iptvapp.data.ContentType

/**
 * A single "you watched this" row. One row per [contentId], upserted every time
 * playback starts/stops, so this table serves both the History screen (sort by
 * [lastWatchedAtMs]) and Continue Watching (filter where [positionMs] is between
 * a few seconds and ~95% of [durationMs] - that filtering logic lands with the
 * player rework milestone; the schema is ready for it now).
 */
@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey val contentId: String,
    val title: String,
    val posterUrl: String?,
    val type: ContentType,
    val streamUrl: String,
    val positionMs: Long,
    val durationMs: Long,
    val lastWatchedAtMs: Long
)
