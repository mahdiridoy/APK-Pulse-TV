package com.mahdiridoy.iptvapp.movies

/**
 * Built-in, non-editable-by-user list of Movies & Series repositories.
 * Add your own repo manifest URLs here - no in-app "add repo" UI by design.
 */
object RepoRegistry {
    val repos: List<Repo> = listOf(
        Repo(
            name = "MovieBox Provider",
            manifestUrl = "https://raw.githubusercontent.com/phisher98/cloudstream-extensions-phisher/builds/MovieBoxProvider.cs3"
        )
    )
}
