package com.mahdiridoy.iptvapp.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mahdiridoy.iptvapp.catalog.CatalogRepository
import com.mahdiridoy.iptvapp.catalog.ContentSummary
import com.mahdiridoy.iptvapp.data.LibraryRepository
import com.mahdiridoy.iptvapp.data.db.HistoryEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeRow(val name: String, val items: List<ContentSummary>)

sealed interface HomeUiState {
    data object Loading : HomeUiState
    data class Loaded(val rows: List<HomeRow>) : HomeUiState
    data class Error(val message: String) : HomeUiState
}

/**
 * Milestone 3: featured rows for Home, one per Movies category and one per
 * Series category (first couple of each, so Home doesn't just repeat the full
 * Movies/Series screens). This fetches independently of [com.mahdiridoy.iptvapp.movies.MoviesViewModel]/
 * [com.mahdiridoy.iptvapp.series.SeriesViewModel] rather than sharing their
 * cache - a small duplicate network fetch, acceptable for now and worth
 * revisiting if repos grow large.
 *
 * Milestone 5 adds [continueWatching] - real Room data (Movies/Series only;
 * Live TV history entries have no meaningful duration/position, so they're
 * filtered out by [com.mahdiridoy.iptvapp.data.db.HistoryDao]'s query itself).
 */
class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = LibraryRepository.getInstance(application)

    private val _uiState = MutableStateFlow<HomeUiState>(HomeUiState.Loading)
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    val continueWatching: StateFlow<List<HistoryEntity>> = repository.observeContinueWatching()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch {
            _uiState.value = runCatching {
                val movieRows = CatalogRepository.fetchAllMovieCategories()
                    .take(2)
                    .map { HomeRow(it.name, it.items.map { m -> m.summary }) }
                val seriesRows = CatalogRepository.fetchAllSeriesCategories()
                    .take(2)
                    .map { HomeRow(it.name, it.items.map { s -> s.summary }) }
                (movieRows + seriesRows).filter { it.items.isNotEmpty() }
            }.fold(
                onSuccess = { HomeUiState.Loaded(it) },
                onFailure = { HomeUiState.Error(it.message ?: "Failed to load home feed") }
            )
        }
    }
}
