package com.mahdiridoy.iptvapp.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mahdiridoy.iptvapp.catalog.ContentSummary
import com.mahdiridoy.iptvapp.catalog.db.CatalogDatabase
import com.mahdiridoy.iptvapp.data.ContentType
import com.mahdiridoy.iptvapp.data.LibraryRepository
import com.mahdiridoy.iptvapp.data.db.HistoryEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeRow(val name: String, val items: List<ContentSummary>)

sealed interface HomeUiState {
    data object Loading : HomeUiState
    data class Loaded(val rows: List<HomeRow>) : HomeUiState
    data class Error(val message: String) : HomeUiState
}

/**
 * Featured row(s) for Home. Reads directly from the Movies & Series Room database (see
 * [CatalogDatabase]/[com.mahdiridoy.iptvapp.catalog.CatalogSyncManager]) rather than
 * the old JSON-manifest [com.mahdiridoy.iptvapp.catalog.CatalogRepository] - that's
 * where the actual M3U-sourced catalog lives now, so Home would otherwise show nothing
 * from it. A plain `LIMIT` query (see [com.mahdiridoy.iptvapp.catalog.db.CatalogDao.firstTiles])
 * rather than the grid's full Paging3 setup, since Home only ever needs a small taste.
 *
 * [continueWatching] is real Room data too (Movies/Series only; Live TV history entries
 * have no meaningful duration/position, so they're filtered out by
 * [com.mahdiridoy.iptvapp.data.db.HistoryDao]'s query itself).
 */
class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = LibraryRepository.getInstance(application)
    private val catalogDao = CatalogDatabase.getInstance(application).catalogDao()

    private val _uiState = MutableStateFlow<HomeUiState>(HomeUiState.Loading)
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    val continueWatching: StateFlow<List<HistoryEntity>> = repository.observeContinueWatching()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch {
            _uiState.value = runCatching {
                val tiles = catalogDao.firstTiles(20).map { tile ->
                    ContentSummary(
                        id = tile.id,
                        title = tile.title,
                        posterUrl = tile.logo,
                        backdropUrl = tile.logo,
                        description = null,
                        year = null,
                        type = if (tile.type == "SERIES") ContentType.SERIES else ContentType.MOVIE
                    )
                }
                if (tiles.isEmpty()) emptyList() else listOf(HomeRow("Movies & Series", tiles))
            }.fold(
                onSuccess = { HomeUiState.Loaded(it) },
                onFailure = { HomeUiState.Error(it.message ?: "Failed to load home feed") }
            )
        }
    }
}
