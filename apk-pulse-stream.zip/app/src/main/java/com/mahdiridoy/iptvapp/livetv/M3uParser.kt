package com.mahdiridoy.iptvapp.livetv

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

/**
 * Fetches and parses M3U playlists. Works with standard #EXTM3U / #EXTINF format,
 * including tvg-id, tvg-logo, and group-title attributes.
 *
 * Two entry points, deliberately:
 * - [fetch]/[parse]: loads the whole playlist into memory at once. Fine for Live TV's
 *   playlist (a few hundred channels) - simple, and nothing here needs to paginate.
 * - [streamEntries]: never holds the whole file as a single String or List, used for
 *   the Movies & Series catalog (100k+ entries, tens of MB) where loading it all into
 *   memory at once is exactly what needs avoiding - see [com.mahdiridoy.iptvapp.catalog.CatalogSyncManager].
 *
 * Both share the same per-line parsing ([parseExtinfLine]) so the actual EXTINF/tvg-*
 * attribute rules only exist in one place.
 */
object M3uParser {

    private val client = OkHttpClient()

    /** One #EXTINF line's parsed attributes - the display name, plus whatever tvg-id, tvg-logo, and group-title tags it carried. */
    data class ExtinfInfo(val name: String, val logoUrl: String?, val group: String, val tvgId: String?)

    private val extInfRegex = Regex("#EXTINF:-?\\d+.*?,(.*)")
    private val logoRegex = Regex("tvg-logo=\"([^\"]*)\"")
    private val groupRegex = Regex("group-title=\"([^\"]*)\"")
    private val tvgIdRegex = Regex("tvg-id=\"([^\"]*)\"")

    fun parseExtinfLine(line: String): ExtinfInfo {
        val name = extInfRegex.find(line)?.groupValues?.get(1)?.trim()?.ifEmpty { "Unknown Channel" } ?: "Unknown Channel"
        val logo = logoRegex.find(line)?.groupValues?.get(1)
        val group = groupRegex.find(line)?.groupValues?.get(1)?.ifEmpty { "Uncategorized" } ?: "Uncategorized"
        val tvgId = tvgIdRegex.find(line)?.groupValues?.get(1)
        return ExtinfInfo(name, logo, group, tvgId)
    }

    @Throws(IOException::class)
    fun fetch(playlistUrl: String): List<Channel> {
        val request = Request.Builder().url(playlistUrl).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Failed to fetch playlist: HTTP ${response.code}")
            }
            val body = response.body?.string() ?: ""
            return parse(body)
        }
    }

    fun parse(content: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        streamEntries(content.lineSequence()) { info, streamUrl ->
            channels.add(Channel(info.name, info.logoUrl, info.group, streamUrl))
        }
        return channels
    }

    /**
     * Walks [lines] once, calling [onEntry] for each EXTINF+URL pair as it's found -
     * nothing is buffered into a list first. Pass a [java.io.BufferedReader.lineSequence]
     * sourced from a live response body stream (not `content.lines()` on an
     * already-fully-read String) to get the actual memory benefit.
     */
    inline fun streamEntries(lines: Sequence<String>, onEntry: (ExtinfInfo, streamUrl: String) -> Unit) {
        var pending: ExtinfInfo? = null
        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF")) {
                pending = parseExtinfLine(line)
            } else if (!line.startsWith("#")) {
                val info = pending ?: continue
                pending = null
                onEntry(info, line)
            }
        }
    }
}
