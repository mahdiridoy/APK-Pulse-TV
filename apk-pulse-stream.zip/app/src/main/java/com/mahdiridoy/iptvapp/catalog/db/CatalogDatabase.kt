package com.mahdiridoy.iptvapp.catalog.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * A separate database file from [com.mahdiridoy.iptvapp.data.db.AppDatabase]
 * (favorites/history) on purpose - this one is a disposable local cache of what's on
 * the remote M3U (see [com.mahdiridoy.iptvapp.catalog.CatalogSyncManager]), not user
 * data, so it can be wiped and rebuilt at will with zero risk to a user's favorites,
 * watch history, or resume positions.
 */
@Database(
    entities = [MovieRow::class, SeriesEpisodeRow::class],
    views = [BrowseTileRow::class],
    version = 1,
    exportSchema = false
)
abstract class CatalogDatabase : RoomDatabase() {

    abstract fun catalogDao(): CatalogDao

    companion object {
        @Volatile
        private var instance: CatalogDatabase? = null

        fun getInstance(context: Context): CatalogDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CatalogDatabase::class.java,
                    "catalog.db"
                ).build().also { instance = it }
            }
    }
}
