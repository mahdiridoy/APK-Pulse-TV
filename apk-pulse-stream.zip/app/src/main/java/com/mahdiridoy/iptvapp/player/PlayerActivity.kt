package com.mahdiridoy.iptvapp.player

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import com.mahdiridoy.iptvapp.R
import com.mahdiridoy.iptvapp.catalog.Quality
import com.mahdiridoy.iptvapp.data.LibraryRepository
import com.mahdiridoy.iptvapp.util.DeviceUtil
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Fullscreen landscape playback for Live TV, Movies and Series alike.
 * Gestures: horizontal swipe = change channel/item, vertical swipe on the
 * left half = brightness, vertical swipe on the right half = volume.
 * TV remote: CH+/CH- (or DPAD_UP/DOWN) changes channel like an analog tuner;
 * MENU/INFO/GUIDE opens a Quality/Subtitles chooser - a guaranteed path to
 * both regardless of whatever currently has D-pad focus.
 *
 * Milestone 4 additions (Movies/Series only - [PlaybackQueue.contentIds] is
 * null for every Live TV item, so all of this is a no-op there):
 *  - Resumes from the last saved position on the initially-played item.
 *  - Writes position/duration to Room every 5s while playing, and whenever
 *    the item changes or the Activity stops, so History/Continue Watching
 *    stay current without any explicit "save" step.
 *  - Quality button switches between manifest-declared quality URLs (distinct
 *    files) when there's more than one, preserving playback position; falls
 *    back to the original adaptive-rendition track override otherwise (that's
 *    still what Live TV's single HLS URL uses). Both dialogs mark the option
 *    that's actually active right now.
 *  - CC button: embedded subtitle track selection, or Off.
 *
 * Post-Milestone-5 fixes:
 *  - A broken/expired stream link auto-skips to the next item instead of
 *    crashing (see the Player.Listener in onCreate).
 *  - CH+/DPAD_UP now moves forward and CH-/DPAD_DOWN moves backward - they
 *    were swapped before.
 */
class PlayerActivity : AppCompatActivity() {

    companion object

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var indicatorText: TextView
    private lateinit var trackSelector: DefaultTrackSelector

    private var titles: List<String> = emptyList()
    private var urls: List<String> = emptyList()
    private var contentIds: List<String?> = emptyList()
    private var qualityOptions: List<List<Quality>> = emptyList()
    private var currentIndex = 0
    private var initialIndex = 0
    private var pendingResumeMs = 0L
    private var activeQualityUrl: String = ""
    private var consecutiveErrors = 0

    private var qualityButtonView: View? = null
    private var subtitleButtonView: View? = null
    private var moreOptionsButtonView: View? = null

    private var castPlayer: CastPlayer? = null
    private var usingCastPlayer = false

    private val repository by lazy { LibraryRepository.getInstance(applicationContext) }

    private var audioManager: AudioManager? = null

    // gesture tracking
    private var gestureDownX = 0f
    private var gestureDownY = 0f
    private var gestureMode = 0 // 0=undecided, 1=horizontal(channel), 2=vertical-brightness, 3=vertical-volume
    private var startBrightness = 0.5f
    private var startVolume = 0

    private val progressHandler = Handler(Looper.getMainLooper())
    private val progressRunnable = object : Runnable {
        override fun run() {
            writeProgress()
            progressHandler.postDelayed(this, 5_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // NOTE: deliberately NOT calling setRequestedOrientation() here. On some
        // Android skins, calling it at runtime throws IllegalStateException
        // ("Only fullscreen activities can request orientation") in a way that
        // can kill the process before any Java exception handler reacts. The
        // manifest's android:screenOrientation="landscape" on this Activity
        // already locks it to landscape - that alone is enough, and it's what
        // the very first working build relied on.

        setContentView(R.layout.activity_player)
        playerView = findViewById(R.id.playerView)
        indicatorText = findViewById(R.id.indicatorText)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        enterFullscreen()

        titles = PlaybackQueue.titles
        urls = PlaybackQueue.urls
        contentIds = PlaybackQueue.contentIds
        qualityOptions = PlaybackQueue.qualityOptions
        currentIndex = PlaybackQueue.startIndex.coerceIn(0, (urls.size - 1).coerceAtLeast(0))
        initialIndex = currentIndex
        pendingResumeMs = PlaybackQueue.startPositionMs

        if (urls.isEmpty()) {
            finish()
            return
        }

        try {
            trackSelector = DefaultTrackSelector(this)
            val exoPlayer = ExoPlayer.Builder(this).setTrackSelector(trackSelector).build()
            player = exoPlayer
            playerView.player = exoPlayer
            playerView.keepScreenOn = true

            // A broken/expired M3U link (common on free IPTV sources) used to crash straight
            // through to a black screen with no recovery. Now it just skips ahead, the same
            // way changing the channel normally does - up to once per item in the queue, so a
            // fully-dead playlist still stops instead of toast-spamming forever.
            exoPlayer.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    consecutiveErrors++
                    val failedTitle = titles.getOrNull(currentIndex).orEmpty()
                    if (urls.size > 1 && consecutiveErrors < urls.size) {
                        Toast.makeText(
                            this@PlayerActivity,
                            "Couldn't play \"$failedTitle\" - skipping to next",
                            Toast.LENGTH_SHORT
                        ).show()
                        changeChannel(1)
                    } else {
                        Toast.makeText(
                            this@PlayerActivity,
                            "Nothing playable in this list right now",
                            Toast.LENGTH_LONG
                        ).show()
                        finish()
                    }
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) consecutiveErrors = 0
                }
            })

            val qualityButton = findViewById<View>(R.id.qualityButton)
            val subtitleButton = findViewById<View>(R.id.subtitleButton)
            val moreOptionsButton = findViewById<View>(R.id.moreOptionsButton)
            qualityButtonView = qualityButton
            subtitleButtonView = subtitleButton
            moreOptionsButtonView = moreOptionsButton
            qualityButton?.setOnClickListener { showQualityDialog() }
            subtitleButton?.setOnClickListener { showSubtitleDialog() }
            moreOptionsButton?.setOnClickListener { showOptionsMenu() }
            setUpCastIfAvailable()
            // D-pad users need something focused immediately - without this, Android may
            // never assign initial focus at all on some TV boxes, making these buttons
            // impossible to reach. The MENU-key shortcut below is the guaranteed path
            // regardless; this is the secondary, nicer-when-it-works one.
            qualityButton?.requestFocus()

            playCurrent()
            setupGestures()
            progressHandler.postDelayed(progressRunnable, 5_000)
        } catch (e: Exception) {
            Toast.makeText(this, "Playback failed to start: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    // ---- Video quality ----
    // Movies/Series manifests can list several *separate* files (a "1080p" and a
    // "720p" URL that aren't part of one adaptive stream) - that needs an actual
    // MediaItem swap, which the old adaptive-track dialog below can't do. Live TV's
    // single HLS URL has no such alternates, so it always falls through to that
    // adaptive dialog, unchanged from before Milestone 4.

    private fun showQualityDialog() {
        if (usingCastPlayer) {
            Toast.makeText(this, R.string.cast_unavailable_action, Toast.LENGTH_SHORT).show()
            return
        }
        val alternates = qualityOptions.getOrNull(currentIndex).orEmpty()
        if (alternates.size > 1) {
            showManualQualityDialog(alternates)
        } else {
            showAdaptiveQualityDialog()
        }
    }

    private fun showManualQualityDialog(alternates: List<Quality>) {
        val labels = alternates.map { it.label }.toTypedArray()
        val currentIndex = alternates.indexOfFirst { it.url == activeQualityUrl }.let { if (it < 0) 0 else it }
        AlertDialog.Builder(this)
            .setTitle(R.string.quality_dialog_title)
            .setSingleChoiceItems(labels, currentIndex) { dialog, which ->
                switchToQualityUrl(alternates[which].url)
                Toast.makeText(this, alternates[which].label, Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .show()
    }

    private fun switchToQualityUrl(url: String) {
        val exoPlayer = player ?: return
        val resumeMs = exoPlayer.currentPosition.coerceAtLeast(0)
        activeQualityUrl = url
        exoPlayer.setMediaItem(MediaItem.fromUri(url))
        exoPlayer.prepare()
        exoPlayer.seekTo(resumeMs)
        exoPlayer.playWhenReady = true
    }

    private fun showAdaptiveQualityDialog() {
        val exoPlayer = player ?: return
        val options = mutableListOf<Pair<String, TrackSelectionOverride?>>()

        for (group in exoPlayer.currentTracks.groups) {
            if (group.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until group.length) {
                if (!group.isTrackSupported(i)) continue
                val format = group.getTrackFormat(i)
                val label = if (format.height > 0) "${format.height}p" else {
                    if (format.bitrate > 0) "${format.bitrate / 1000} kbps" else "Unknown"
                }
                options.add(label to TrackSelectionOverride(group.mediaTrackGroup, i))
            }
        }

        // Highest resolution first - matches what people expect from a quality picker,
        // and makes it obvious at a glance whether a fixed pick is actually the top option.
        val sortedOptions = options.distinctBy { it.first }
            .sortedByDescending { it.first.filter(Char::isDigit).toIntOrNull() ?: 0 }

        if (sortedOptions.isEmpty()) {
            Toast.makeText(this, R.string.quality_unavailable, Toast.LENGTH_SHORT).show()
            return
        }

        val activeOverride = trackSelector.parameters.overrides.values.firstOrNull { it.type == C.TRACK_TYPE_VIDEO }
        // Auto's label used to just say "Auto" with no indication of what it's actually
        // rendering right now - on a real network that adapts, that read as "stuck on the
        // wrong quality" even when it wasn't. Naming the currently-decoding resolution
        // makes Auto's live behavior visible instead of a black box.
        val liveHeight = exoPlayer.videoFormat?.height?.takeIf { it > 0 }
        val autoLabel = if (activeOverride == null && liveHeight != null) {
            getString(R.string.quality_auto) + " (${liveHeight}p)"
        } else {
            getString(R.string.quality_auto)
        }
        val deduped: List<Pair<String, TrackSelectionOverride?>> =
            listOf(autoLabel to null) + sortedOptions

        val labels = deduped.map { it.first }.toTypedArray()
        val currentIndex = if (activeOverride == null) {
            0
        } else {
            deduped.indexOfFirst { it.second?.mediaTrackGroup == activeOverride.mediaTrackGroup }.let { if (it < 0) 0 else it }
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.quality_dialog_title)
            .setSingleChoiceItems(labels, currentIndex) { dialog, which ->
                val override = deduped[which].second
                val builder = trackSelector.parameters.buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                if (override != null) {
                    builder.addOverride(override)
                }
                trackSelector.parameters = builder.build()
                Toast.makeText(this, deduped[which].first, Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .show()
    }

    // ---- Subtitles: embedded text tracks, or Off ----

    private fun showSubtitleDialog() {
        if (usingCastPlayer) {
            Toast.makeText(this, R.string.cast_unavailable_action, Toast.LENGTH_SHORT).show()
            return
        }
        val exoPlayer = player ?: return
        val options = mutableListOf<Pair<String, TrackSelectionOverride?>>()
        options.add(getString(R.string.subtitle_off) to null)

        for (group in exoPlayer.currentTracks.groups) {
            if (group.type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until group.length) {
                if (!group.isTrackSupported(i)) continue
                val format = group.getTrackFormat(i)
                val label = format.label ?: format.language ?: "Track ${i + 1}"
                options.add(label to TrackSelectionOverride(group.mediaTrackGroup, i))
            }
        }

        if (options.size <= 1) {
            Toast.makeText(this, R.string.subtitle_unavailable, Toast.LENGTH_SHORT).show()
            return
        }
        val labels = options.map { it.first }.toTypedArray()
        val textDisabled = trackSelector.parameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
        val activeOverride = trackSelector.parameters.overrides.values.firstOrNull { it.type == C.TRACK_TYPE_TEXT }
        val currentIndex = if (textDisabled || activeOverride == null) {
            0
        } else {
            options.indexOfFirst { it.second?.mediaTrackGroup == activeOverride.mediaTrackGroup }.let { if (it < 0) 0 else it }
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.subtitle_dialog_title)
            .setSingleChoiceItems(labels, currentIndex) { dialog, which ->
                val override = options[which].second
                val builder = trackSelector.parameters.buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                    .setIgnoredTextSelectionFlags(0)
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, override == null)
                if (override != null) {
                    builder.addOverride(override)
                }
                trackSelector.parameters = builder.build()
                Toast.makeText(this, options[which].first, Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .show()
    }

    private fun enterFullscreen() {
        try {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.insetsController?.let {
                    it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                    it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    )
            }
        } catch (e: Exception) {
            // Fullscreen chrome is cosmetic - never let it take playback down with it.
        }
    }

    private fun playCurrent() {
        val exoPlayer = player ?: return
        val title = titles.getOrNull(currentIndex) ?: ""
        activeQualityUrl = urls[currentIndex]
        // A quality override from the previous item won't map to this item's
        // renditions - reset to Auto every time we switch.
        trackSelector.parameters = trackSelector.parameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
            .build()
        exoPlayer.setMediaItem(MediaItem.fromUri(urls[currentIndex]))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true

        if (currentIndex == initialIndex && pendingResumeMs > 0) {
            exoPlayer.seekTo(pendingResumeMs)
            val minutes = pendingResumeMs / 60_000
            val seconds = (pendingResumeMs / 1000) % 60
            Toast.makeText(
                this,
                getString(R.string.resumed_from_message, String.format("%d:%02d", minutes, seconds)),
                Toast.LENGTH_SHORT
            ).show()
            pendingResumeMs = 0L
        } else if (title.isNotBlank()) {
            Toast.makeText(this, title, Toast.LENGTH_SHORT).show()
        }
    }

    private fun changeChannel(delta: Int) {
        if (urls.size <= 1) return
        if (usingCastPlayer) {
            Toast.makeText(this, R.string.cast_unavailable_action, Toast.LENGTH_SHORT).show()
            return
        }
        writeProgress()
        currentIndex = (currentIndex + delta + urls.size) % urls.size
        playCurrent()
    }

    /** Writes position/duration for the currently-playing item. No-op for Live TV (no contentId). */
    private fun writeProgress() {
        val activePlayer: Player? = if (usingCastPlayer) castPlayer else player
        val exoPlayer = activePlayer ?: return
        val contentId = contentIds.getOrNull(currentIndex) ?: return
        val duration = exoPlayer.duration
        if (duration <= 0) return
        val position = exoPlayer.currentPosition.coerceIn(0, duration)
        lifecycleScope.launch {
            runCatching { repository.updateProgress(contentId, position, duration) }
        }
    }

    // ---- Touch gestures: swipe horizontal = channel, vertical L/R = brightness/volume ----

    private fun setupGestures() {
        playerView.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    gestureDownX = event.x
                    gestureDownY = event.y
                    gestureMode = 0
                    startBrightness = window.attributes.screenBrightness.let { if (it < 0) 0.5f else it }
                    startVolume = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - gestureDownX
                    val dy = event.y - gestureDownY
                    if (gestureMode == 0 && (abs(dx) > 24 || abs(dy) > 24)) {
                        gestureMode = if (abs(dx) > abs(dy)) 1
                        else if (gestureDownX < view.width / 2f) 2 else 3
                    }
                    when (gestureMode) {
                        2 -> adjustBrightness(-dy / view.height)
                        3 -> adjustVolume(-dy / view.height)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (gestureMode == 1) {
                        val dx = event.x - gestureDownX
                        if (abs(dx) > 80) {
                            if (dx < 0) changeChannel(1) else changeChannel(-1)
                        }
                    }
                    indicatorText.visibility = View.GONE
                    gestureMode = 0
                    view.performClick()
                    true
                }
                else -> false
            }
        }
    }

    private fun adjustBrightness(delta: Float) {
        val newValue = (startBrightness + delta).coerceIn(0.05f, 1f)
        val params = window.attributes
        params.screenBrightness = newValue
        window.attributes = params
        indicatorText.visibility = View.VISIBLE
        indicatorText.text = getString(R.string.brightness_percent, (newValue * 100).toInt())
    }

    private fun adjustVolume(delta: Float) {
        val maxVolume = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 1
        val newVolume = (startVolume + delta * maxVolume).toInt().coerceIn(0, maxVolume)
        audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0)
        indicatorText.visibility = View.VISIBLE
        indicatorText.text = getString(R.string.volume_percent, (newVolume * 100 / maxVolume))
    }

    // ---- Remote-accessible options menu ----
    // MENU/INFO/GUIDE is a guaranteed path to Quality/Subtitles regardless of
    // whatever currently has D-pad focus - the on-screen buttons are a nice-to-have
    // on top of this, not the only way in.

    private fun showOptionsMenu() {
        val options = arrayOf(
            getString(R.string.quality_button),
            getString(R.string.subtitle_dialog_title),
            getString(R.string.open_with_external_player)
        )
        AlertDialog.Builder(this)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showQualityDialog()
                    1 -> showSubtitleDialog()
                    2 -> openInExternalPlayer()
                }
            }
            .show()
    }

    // ---- TV remote: analog-style channel up/down ----

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_SETTINGS -> {
                showOptionsMenu()
                return true
            }
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_DPAD_UP -> {
                // If a control button currently holds D-pad focus, let the key move focus/
                // click it as normal instead of hijacking it for channel change.
                if (currentFocus?.id == R.id.qualityButton ||
                    currentFocus?.id == R.id.subtitleButton ||
                    currentFocus?.id == R.id.moreOptionsButton
                ) {
                    return super.onKeyDown(keyCode, event)
                }
                changeChannel(1)
                return true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (currentFocus?.id == R.id.qualityButton ||
                    currentFocus?.id == R.id.subtitleButton ||
                    currentFocus?.id == R.id.moreOptionsButton
                ) {
                    return super.onKeyDown(keyCode, event)
                }
                changeChannel(-1)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---- Picture-in-Picture (phones/tablets only - not offered on Android TV, ----
    // ---- where leaving the app doesn't work the same way) ----

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N &&
            !DeviceUtil.isTelevision(this) &&
            player?.isPlaying == true
        ) {
            enterPipMode()
        }
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val params = PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                enterPictureInPictureMode(params)
            } else {
                // API 24-25: PictureInPictureParams doesn't exist yet - the class can't even
                // be referenced in this branch, only the older no-arg method.
                @Suppress("DEPRECATION")
                enterPictureInPictureMode()
            }
        } catch (e: Exception) {
            // Some OEM skins advertise PiP support but throw anyway - playback should
            // just continue fullscreen rather than crash the Activity over this.
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        // There's no room to tap these in a thumbnail-sized PiP window anyway.
        val visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE
        qualityButtonView?.visibility = visibility
        subtitleButtonView?.visibility = visibility
        moreOptionsButtonView?.visibility = visibility
    }

    // ---- Chromecast (optional - many generic/budget Android TV boxes have no Google Play ----
    // ---- Services at all, so every bit of this has to fail silently, not crash) ----

    private fun setUpCastIfAvailable() {
        try {
            val castContext = CastContext.getSharedInstance(this)
            val cast = CastPlayer(castContext)
            cast.setSessionAvailabilityListener(object : SessionAvailabilityListener {
                override fun onCastSessionAvailable() = switchToCastPlayer()
                override fun onCastSessionUnavailable() = switchToLocalPlayer()
            })
            castPlayer = cast

            val castButton = findViewById<MediaRouteButton>(R.id.castButton)
            CastButtonFactory.setUpMediaRouteButton(applicationContext, castButton)
            castButton.visibility = View.VISIBLE
        } catch (e: Exception) {
            // No Play Services / Cast framework unavailable - skip entirely, button stays hidden.
        }
    }

    /**
     * Casting plays exactly the one item that was active locally - it doesn't take over
     * channel-changing/quality-switching (see the guards in [changeChannel] and
     * [showQualityDialog]/[showSubtitleDialog]), a deliberately simpler scope than full
     * remote-control parity.
     */
    private fun switchToCastPlayer() {
        val cast = castPlayer ?: return
        val localPlayer = player ?: return
        val resumeMs = localPlayer.currentPosition.coerceAtLeast(0)
        localPlayer.pause()
        usingCastPlayer = true
        cast.setMediaItem(MediaItem.fromUri(urls[currentIndex]))
        cast.prepare()
        cast.seekTo(resumeMs)
        cast.playWhenReady = true
        playerView.player = cast
        Toast.makeText(this, R.string.now_casting, Toast.LENGTH_SHORT).show()
    }

    private fun switchToLocalPlayer() {
        if (!usingCastPlayer) return
        val cast = castPlayer
        val localPlayer = player ?: return
        val resumeMs = cast?.currentPosition?.coerceAtLeast(0) ?: 0L
        usingCastPlayer = false
        playerView.player = localPlayer
        localPlayer.seekTo(resumeMs)
        localPlayer.playWhenReady = true
    }

    // ---- External player ----

    private fun openInExternalPlayer() {
        val url = urls.getOrNull(currentIndex) ?: return
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), "video/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(Intent.createChooser(intent, getString(R.string.open_with_external_player)))
        } catch (e: Exception) {
            Toast.makeText(this, R.string.no_external_player_found, Toast.LENGTH_LONG).show()
        }
    }

    override fun onStop() {
        super.onStop()
        writeProgress()
        progressHandler.removeCallbacks(progressRunnable)
        castPlayer?.setSessionAvailabilityListener(null)
        player?.release()
        player = null
    }
}
