package com.mahdiridoy.iptvapp.series

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mahdiridoy.iptvapp.catalog.CategoryShelf
import com.mahdiridoy.iptvapp.catalog.ContentSummary

/**
 * Milestone 3: real poster shelves per category. Tapping a poster hands its id
 * to [onSeriesClick], which the nav host turns into a details route (seasons/episodes).
 */
@Composable
fun SeriesScreen(
    modifier: Modifier = Modifier,
    viewModel: SeriesViewModel,
    onSeriesClick: (String) -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    when (val current = state) {
        is SeriesUiState.Loading -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }

        is SeriesUiState.Error -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Couldn't load series", style = MaterialTheme.typography.titleMedium)
                Text(current.message, style = MaterialTheme.typography.bodySmall)
            }
        }

        is SeriesUiState.Loaded -> {
            if (current.categories.isEmpty()) {
                Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No series found in the configured repos.")
                }
                return
            }
            LazyColumn(modifier = modifier.fillMaxSize()) {
                items(current.categories, key = { it.name }) { category ->
                    CategoryShelf(
                        name = category.name,
                        items = category.items.map { it.summary },
                        onItemClick = { summary: ContentSummary -> onSeriesClick(summary.id) }
                    )
                }
            }
        }
    }
}
