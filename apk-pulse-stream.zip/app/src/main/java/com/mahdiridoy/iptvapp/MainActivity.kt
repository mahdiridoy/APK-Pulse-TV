package com.mahdiridoy.iptvapp

import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.mahdiridoy.iptvapp.core.nav.PulseAppShell
import com.mahdiridoy.iptvapp.core.nav.UpdateDialogState
import com.mahdiridoy.iptvapp.core.theme.PulseStreamTheme
import com.mahdiridoy.iptvapp.update.UpdateManager
import com.mahdiridoy.iptvapp.util.DeviceUtil
import com.mahdiridoy.iptvapp.util.PlaylistRefreshWorker
import java.util.concurrent.TimeUnit

/**
 * Milestone 1: the whole nav shell (drawer + all eight sections) is now
 * Compose/Material 3. Live TV keeps running as
 * [com.mahdiridoy.iptvapp.livetv.LiveTvFragment], completely unchanged,
 * hosted inside the shell via fragment-compose's AndroidFragment.
 *
 * Not carried over from the old View-based shell (both were custom nav-rail
 * behaviors tied to the View hierarchy this replaces; revisited in the
 * Milestone 6 TV/D-pad pass):
 *  - D-pad-left-at-grid-edge opening the nav rail
 *  - BACK closing an open Live TV search panel before closing the drawer
 * The drawer still opens via its menu icon and the standard edge-swipe gesture.
 *
 * The manual "check Drive for an update" action moved into the Settings
 * screen (self-contained there now) - this Activity only still handles the
 * update dialog that Splash's launch-time check passes in via intent extras.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_UPDATE_TAG = "extra_update_tag"
        const val EXTRA_UPDATE_APK_URL = "extra_update_apk_url"
        const val EXTRA_UPDATE_CHECK_REASON = "extra_update_check_reason"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Phones: portrait for browsing UI. Android TV: leave as the system's
        // fixed landscape (locking portrait on a TV display just looks broken).
        requestedOrientation = if (DeviceUtil.isTelevision(this)) {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }

        schedulePlaylistRefresh()

        val launchUpdateTag = intent.getStringExtra(EXTRA_UPDATE_TAG)
        val launchUpdateApkUrl = intent.getStringExtra(EXTRA_UPDATE_APK_URL)
        val launchUpdateReason = intent.getStringExtra(EXTRA_UPDATE_CHECK_REASON)

        setContent {
            var updateDialogState by remember {
                mutableStateOf(
                    if (launchUpdateTag != null && launchUpdateApkUrl != null) {
                        UpdateDialogState(launchUpdateTag, launchUpdateApkUrl)
                    } else null
                )
            }

            LaunchedEffect(Unit) {
                // No update found from the launch-time check - show why, so this is
                // debuggable without logcat. Remove once update checks are confirmed
                // working end to end.
                if (updateDialogState == null && !launchUpdateReason.isNullOrBlank()) {
                    Toast.makeText(this@MainActivity, launchUpdateReason, Toast.LENGTH_LONG).show()
                }
            }

            PulseStreamTheme {
                PulseAppShell(
                    updateDialogState = updateDialogState,
                    onUpdateNow = { apkUrl ->
                        updateDialogState = null
                        UpdateManager.downloadAndInstall(this, apkUrl)
                    },
                    onDismissUpdate = { updateDialogState = null },
                    onOpenTelegram = { openTelegramChannel() }
                )
            }
        }
    }

    private fun openTelegramChannel() {
        val url = "https://t.me/liveapkpulse"
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open link: no browser or Telegram app found", Toast.LENGTH_LONG).show()
        }
    }

    private fun schedulePlaylistRefresh() {
        val request = PeriodicWorkRequestBuilder<PlaylistRefreshWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "playlist_refresh",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
