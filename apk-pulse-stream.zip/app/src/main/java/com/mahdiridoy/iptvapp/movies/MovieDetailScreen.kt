package com.mahdiridoy.iptvapp.movies

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.mahdiridoy.iptvapp.catalog.MovieDetail
import com.mahdiridoy.iptvapp.data.ContentType
import com.mahdiridoy.iptvapp.data.LibraryActionsViewModel
import com.mahdiridoy.iptvapp.data.db.FavoriteEntity

@Composable
fun MovieDetailScreen(
    detail: MovieDetail?,
    onPlay: (title: String, contentId: String, url: String, qualities: List<com.mahdiridoy.iptvapp.catalog.Quality>) -> Unit,
    modifier: Modifier = Modifier,
    libraryViewModel: LibraryActionsViewModel = viewModel()
) {
    if (detail == null) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Movie not found - try going back and reopening it.")
        }
        return
    }

    val summary = detail.summary
    var selectedQuality by remember(detail) { mutableStateOf(detail.qualities.first()) }
    val isFavorite by libraryViewModel.isFavorite(summary.id).collectAsState(initial = false)

    LazyColumn(modifier = modifier.fillMaxSize()) {
        item {
            if (summary.backdropUrl != null) {
                AsyncImage(
                    model = summary.backdropUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
            }
        }
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(summary.title, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        libraryViewModel.setFavorite(
                            !isFavorite,
                            FavoriteEntity(
                                contentId = summary.id,
                                title = summary.title,
                                posterUrl = summary.posterUrl,
                                type = ContentType.MOVIE,
                                streamUrl = selectedQuality.url,
                                addedAtMs = System.currentTimeMillis()
                            )
                        )
                    }) {
                        Icon(
                            if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Toggle favorite"
                        )
                    }
                }
                summary.year?.let {
                    Text(it.toString(), style = MaterialTheme.typography.bodySmall)
                }
                summary.description?.let {
                    Text(it, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                }

                if (detail.qualities.size > 1) {
                    Text(
                        "Quality",
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        detail.qualities.forEach { quality ->
                            FilterChip(
                                selected = quality == selectedQuality,
                                onClick = { selectedQuality = quality },
                                label = { Text(quality.label) }
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        libraryViewModel.recordWatchStart(
                            com.mahdiridoy.iptvapp.data.db.HistoryEntity(
                                contentId = summary.id,
                                title = summary.title,
                                posterUrl = summary.posterUrl,
                                type = ContentType.MOVIE,
                                streamUrl = selectedQuality.url,
                                positionMs = 0L,
                                durationMs = 0L,
                                lastWatchedAtMs = System.currentTimeMillis()
                            )
                        )
                        onPlay(summary.title, summary.id, selectedQuality.url, detail.qualities)
                    },
                    modifier = Modifier.padding(top = 16.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Text(" Play", modifier = Modifier.padding(start = 4.dp))
                }
            }
        }
    }
}
