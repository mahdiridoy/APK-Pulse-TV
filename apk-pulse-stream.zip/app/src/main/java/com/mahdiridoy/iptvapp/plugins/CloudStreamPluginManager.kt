package com.mahdiridoy.iptvapp.plugins

import android.content.Context
import android.content.res.AssetManager
import android.content.res.Resources
import android.util.Log
import com.lagradost.cloudstream3.APIHolder
import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.plugins.BasePlugin
import com.lagradost.cloudstream3.plugins.Plugin
import dalvik.system.PathClassLoader
import org.json.JSONObject
import java.io.File
import java.io.InputStreamReader

/**
 * Loads and runs real CloudStream `.cs3` plugins - the part that was missing before.
 * A `.cs3` is compiled bytecode, not a movie list: it's a zip containing `classes.dex`
 * plus a `manifest.json` describing which class to instantiate. This is a direct port
 * of the loading half of CloudStream's own `PluginManager.loadPlugin()` (see
 * recloudstream/cloudstream, `plugins/PluginManager.kt`) - same technique
 * ([PathClassLoader] pointed straight at the `.cs3` file, parent = this app's own
 * classloader so the plugin's references to `com.lagradost.cloudstream3.*` resolve
 * against the real classes pulled in via the `:library` dependency in
 * app/build.gradle.kts), trimmed to just what a host app needs: load a file someone
 * chose, keep it loaded, don't try to be an update/repository manager too.
 *
 * Once loaded, a plugin's [MainAPI] instance(s) register themselves into
 * [APIHolder.allProviders] via `registerMainAPI()` - that's CloudStream's own real
 * registry, not something reimplemented here. [CloudStreamBridge] reads from it.
 */
object CloudStreamPluginManager {
    private const val TAG = "CloudStreamPluginMgr"

    // Keyed by absolute file path, same as upstream - reloading the same file is a
    // no-op instead of registering duplicate MainAPI instances.
    private val loadedPlugins = mutableMapOf<String, BasePlugin>()

    val isLoaded: Boolean get() = loadedPlugins.isNotEmpty()

    /**
     * Loads one `.cs3` file. Safe to call again for a file already loaded (returns
     * true immediately, mirroring upstream's own dedupe-by-path behavior).
     */
    @Synchronized
    fun loadPlugin(context: Context, file: File): Result<MainAPI> {
        val filePath = file.absolutePath
        if (!file.exists() || file.length() <= 0L) {
            return Result.failure(IllegalStateException("Plugin file missing or empty: $filePath"))
        }

        loadedPlugins[filePath]?.let { existing ->
            val provider = APIHolder.allProviders.firstOrNull { it.sourcePlugin == filePath }
            return if (provider != null) {
                Result.success(provider)
            } else {
                Result.failure(IllegalStateException("Plugin loaded but registered no MainAPI: ${file.name}"))
            }
        }

        return try {
            // Android 14+ refuses to execute dex from a writable file - matches
            // upstream's own workaround.
            runCatching { file.setReadOnly() }

            val loader = PathClassLoader(filePath, context.classLoader)

            val manifestJson = loader.getResourceAsStream("manifest.json")?.use { stream ->
                InputStreamReader(stream).use { it.readText() }
            } ?: return Result.failure(IllegalStateException("No manifest.json inside ${file.name} - not a valid .cs3"))

            val manifest = JSONObject(manifestJson)
            val pluginClassName = manifest.optString("pluginClassName").takeIf { it.isNotBlank() }
                ?: return Result.failure(IllegalStateException("manifest.json in ${file.name} has no pluginClassName"))
            val requiresResources = manifest.optBoolean("requiresResources", false)

            @Suppress("UNCHECKED_CAST")
            val pluginClass = loader.loadClass(pluginClassName) as Class<out BasePlugin>
            val pluginInstance = pluginClass.getDeclaredConstructor().newInstance()
            pluginInstance.filename = filePath

            if (requiresResources && pluginInstance is Plugin) {
                // Same reflection trick upstream uses to expose the plugin's own
                // resources/assets (drawables etc. bundled inside the .cs3) - internal
                // Android API with no public constructor.
                runCatching {
                    val assets = AssetManager::class.java.getDeclaredConstructor().newInstance()
                    val addAssetPath = AssetManager::class.java.getMethod("addAssetPath", String::class.java)
                    addAssetPath.invoke(assets, filePath)
                    @Suppress("DEPRECATION")
                    pluginInstance.resources = Resources(
                        assets,
                        context.resources.displayMetrics,
                        context.resources.configuration
                    )
                }.onFailure { Log.w(TAG, "Failed to attach plugin resources for ${file.name}", it) }
            }

            val beforeCount = APIHolder.allProviders.size
            if (pluginInstance is Plugin) {
                pluginInstance.load(context)
            } else {
                pluginInstance.load()
            }

            loadedPlugins[filePath] = pluginInstance
            val registered = APIHolder.allProviders.drop(beforeCount)
            val provider = registered.firstOrNull()
                ?: return Result.failure(IllegalStateException("${file.name} loaded but called registerMainAPI() zero times"))

            Log.i(TAG, "Loaded plugin ${file.name} -> ${registered.size} provider(s), using ${provider.name}")
            Result.success(provider)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to load plugin ${file.name}", t)
            Result.failure(t)
        }
    }

    /**
     * Re-loads every previously-installed plugin. [PathClassLoader] instances don't
     * survive a process restart, so [APIHolder.allProviders] starts empty every app
     * launch - call this once at startup (see SplashActivity) the same way
     * CatalogSyncManager.sync() is, so search results are available without the user
     * having to reinstall anything.
     */
    fun reloadInstalledPlugins(context: Context) {
        InstalledPluginStore.load(context).forEach { installed ->
            loadPlugin(context, File(installed.filePath))
        }
    }

    fun findProvider(name: String): MainAPI? =
        APIHolder.allProviders.firstOrNull { it.name.equals(name, ignoreCase = true) }
}
