package com.mahdiridoy.iptvapp.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mahdiridoy.iptvapp.data.db.FavoriteEntity
import com.mahdiridoy.iptvapp.data.db.HistoryEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

/**
 * Shared favorite-toggle and watch-start actions for the Movies/Series detail
 * screens (and, later, the player). Kept separate from [com.mahdiridoy.iptvapp.favorites.FavoritesViewModel]
 * and [com.mahdiridoy.iptvapp.history.HistoryViewModel], which own the list
 * screens for those two sections - this one only performs single-item writes.
 */
class LibraryActionsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = LibraryRepository.getInstance(application)

    fun isFavorite(contentId: String): Flow<Boolean> = repository.isFavorite(contentId)

    fun setFavorite(isFavorite: Boolean, entity: FavoriteEntity) {
        viewModelScope.launch {
            if (isFavorite) repository.addFavorite(entity) else repository.removeFavorite(entity.contentId)
        }
    }

    /**
     * Records that playback started. Milestone 4 (unified player) will update this
     * same row with real resume position/duration as playback progresses - for now
     * this just makes the History screen non-empty from the moment someone hits Play.
     */
    fun recordWatchStart(entity: HistoryEntity) {
        viewModelScope.launch { repository.recordProgress(entity) }
    }
}
