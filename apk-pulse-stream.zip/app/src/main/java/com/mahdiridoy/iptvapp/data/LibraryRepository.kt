package com.mahdiridoy.iptvapp.data

import android.content.Context
import com.mahdiridoy.iptvapp.data.db.AppDatabase
import com.mahdiridoy.iptvapp.data.db.FavoriteEntity
import com.mahdiridoy.iptvapp.data.db.HistoryEntity
import kotlinx.coroutines.flow.Flow

/**
 * Single entry point for Favorites/History/Continue-Watching data, used by every
 * section (Live TV, Movies, Series) so none of them talk to Room directly.
 */
class LibraryRepository(context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val favoriteDao = db.favoriteDao()
    private val historyDao = db.historyDao()

    fun observeFavorites(): Flow<List<FavoriteEntity>> = favoriteDao.observeAll()

    fun isFavorite(contentId: String): Flow<Boolean> = favoriteDao.isFavorite(contentId)

    suspend fun addFavorite(favorite: FavoriteEntity) = favoriteDao.add(favorite)

    suspend fun removeFavorite(contentId: String) = favoriteDao.removeById(contentId)

    fun observeHistory(): Flow<List<HistoryEntity>> = historyDao.observeAll()

    /** One-shot lookup used to resume playback from where it left off. */
    suspend fun getHistoryEntry(contentId: String): HistoryEntity? = historyDao.getById(contentId)

    fun observeContinueWatching(): Flow<List<HistoryEntity>> = historyDao.observeContinueWatching()

    suspend fun recordProgress(entry: HistoryEntity) = historyDao.upsert(entry)

    /** Partial update from the player's periodic progress writer - keeps title/poster/type. */
    suspend fun updateProgress(contentId: String, positionMs: Long, durationMs: Long) =
        historyDao.updateProgress(contentId, positionMs, durationMs, System.currentTimeMillis())

    suspend fun removeHistoryEntry(contentId: String) = historyDao.removeById(contentId)

    suspend fun clearHistory() = historyDao.clearAll()

    companion object {
        @Volatile
        private var instance: LibraryRepository? = null

        fun getInstance(context: Context): LibraryRepository =
            instance ?: synchronized(this) {
                instance ?: LibraryRepository(context.applicationContext).also { instance = it }
            }
    }
}
