package com.mahdiridoy.iptvapp.catalog.db

import androidx.room.ColumnInfo
import androidx.room.DatabaseView
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * One playable movie, one row per M3U entry that doesn't match the SxxEyy episode
 * pattern (see [com.mahdiridoy.iptvapp.catalog.CatalogSyncManager]). [id] is the
 * entry's stream URL - stable across syncs as long as the underlying link doesn't
 * change, which is what upserts key off.
 */
@Entity(
    tableName = "movies",
    indices = [Index("title"), Index("group_name")]
)
data class MovieRow(
    @PrimaryKey val id: String,
    val title: String,
    val logo: String?,
    @ColumnInfo(name = "group_name") val groupName: String,
    val url: String,
    @ColumnInfo(name = "tvg_id") val tvgId: String?,
    // Sync bookkeeping, not shown anywhere - see deleteStaleMovies() in CatalogDao.
    @ColumnInfo(name = "last_synced_at") val lastSyncedAt: Long
)

/**
 * One episode of one show. [showTitle] is everything before the SxxEyy marker in the
 * M3U entry's title - all episodes sharing the same [showTitle] are treated as one
 * series in the UI (see the `series_shows` aggregation in [BrowseTileRow]).
 */
@Entity(
    tableName = "series_episodes",
    indices = [Index("show_title"), Index("group_name"), Index("season")]
)
data class SeriesEpisodeRow(
    @PrimaryKey val id: String,
    val title: String,
    val logo: String?,
    @ColumnInfo(name = "group_name") val groupName: String,
    val url: String,
    @ColumnInfo(name = "show_title") val showTitle: String,
    val season: Int,
    val episode: Int,
    @ColumnInfo(name = "last_synced_at") val lastSyncedAt: Long
)

/**
 * One row per grid tile: every movie, plus one aggregated row per distinct show
 * (episode count instead of a real row-per-episode) - this is what the Movies &
 * Series grid actually pages through, so a series with 300 episodes still only ever
 * costs one row in the paged result set, same as a single movie.
 *
 * Deliberately a single self-contained view (not built from another view) - Room's
 * handling of view-referencing-view creation order isn't something worth risking here
 * when a flat UNION ALL over the two base tables does the same job.
 */
@DatabaseView(
    viewName = "browse_tiles",
    value = """
        SELECT id, title, logo, group_name, 'MOVIE' AS type, 1 AS episodeCount
        FROM movies
        UNION ALL
        SELECT show_title AS id, show_title AS title, MIN(logo) AS logo, group_name,
               'SERIES' AS type, COUNT(*) AS episodeCount
        FROM series_episodes
        GROUP BY show_title, group_name
    """
)
data class BrowseTileRow(
    val id: String,
    val title: String,
    val logo: String?,
    @ColumnInfo(name = "group_name") val groupName: String,
    val type: String,
    val episodeCount: Int
)
