package com.mahdiridoy.iptvapp.movies

/**
 * A built-in content repository. Each repo points at a JSON manifest you host
 * (e.g. on GitHub, same pattern as your M3U pipeline) listing movies/series and
 * their direct stream URLs. This keeps the repo list fixed inside the app instead
 * of letting users add their own, while still being easy for you to maintain.
 *
 * Manifest JSON format expected at `manifestUrl`:
 * [
 *   { "title": "Movie Name", "poster": "https://...jpg", "streamUrl": "https://...m3u8" },
 *   ...
 * ]
 */
data class Repo(
    val name: String,
    val manifestUrl: String
)

data class MovieItem(
    val title: String,
    val posterUrl: String?,
    val streamUrl: String,
    val description: String? = null,
    val isPlugin: Boolean = false,
    val repositoryName: String? = null,
    val providerId: String? = null,
    val isInstalled: Boolean = false
)
