package com.mahdiridoy.iptvapp.movies

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mahdiridoy.iptvapp.catalog.CatalogRepository
import com.mahdiridoy.iptvapp.catalog.ContentSummary
import com.mahdiridoy.iptvapp.catalog.PosterCard
import com.mahdiridoy.iptvapp.data.ContentType
import com.mahdiridoy.iptvapp.data.LibraryActionsViewModel
import com.mahdiridoy.iptvapp.data.db.FavoriteEntity
import kotlinx.coroutines.launch

/** A single directly-playable entry - one movie, or one episode of a series, and its stream URL. */
data class PlayableMovie(val summary: ContentSummary, val streamUrl: String)

/**
 * One tile in the grid: either a standalone movie (plays alone, swiping in the
 * player moves to other browsed items) or a whole series (plays every episode,
 * across every season, back to back - see [episodes]). Whether an M3U entry
 * becomes one or the other is entirely up to [CatalogRepository]'s SxxEyy
 * detection - nothing here needs to change when the M3U's line-up changes,
 * new shows/seasons/episodes just show up next time it's fetched.
 */
private sealed class BrowseTile {
    abstract val summary: ContentSummary
    data class MovieTile(override val summary: ContentSummary, val streamUrl: String) : BrowseTile()
    data class SeriesTile(override val summary: ContentSummary, val episodes: List<PlayableMovie>) : BrowseTile()
}

/**
 * Movies & Series, merged into one screen: a flat grid pulled straight from
 * the M3U catalog (see [CatalogRepository]'s M3U_CATALOG_URL), same idea as
 * Live TV's channel grid - no manual category browsing, tap a poster and it
 * plays immediately. A movie plays by itself; a series plays every episode,
 * in season/episode order, one after another (see [PlayerActivity]'s
 * auto-advance-on-STATE_ENDED) - update the M3U file and the line-up here
 * follows automatically, no app update needed.
 *
 * Swipe left from the left edge opens the nav drawer, swipe right from the
 * right edge focuses the search box (keyboard up, ready to type) - same
 * gesture directions as Live TV, implemented independently here since this
 * screen is pure Compose (no AndroidFragment interop to fight over touch
 * priority with, unlike Live TV). Search only ever filters [allTiles] -
 * Live TV channels are a completely separate screen/data source, so there's
 * no risk of the two search boxes' results bleeding into each other.
 * Pulling down from the top refreshes the M3U catalog fresh (bypasses the
 * process-lifetime cache - see [CatalogRepository.fetchAllMovieCategories]).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoviesSeriesScreen(
    onPlay: (List<PlayableMovie>, startIndex: Int) -> Unit,
    onOpenDrawerRequested: () -> Unit,
    modifier: Modifier = Modifier,
    libraryViewModel: LibraryActionsViewModel = viewModel()
) {
    var allTiles by remember { mutableStateOf<List<BrowseTile>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var refreshing by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val swipeThresholdPx = with(density) { 48.dp.toPx() }
    val searchFocusRequester = remember { FocusRequester() }

    suspend fun load(forceRefresh: Boolean) {
        val movieCategories = runCatching { CatalogRepository.fetchAllMovieCategories(forceRefresh) }.getOrDefault(emptyList())
        val seriesCategories = runCatching { CatalogRepository.fetchAllSeriesCategories(forceRefresh) }.getOrDefault(emptyList())

        val movieTiles = movieCategories.flatMap { it.items }.mapNotNull { detail ->
            detail.qualities.firstOrNull()?.let { quality ->
                BrowseTile.MovieTile(detail.summary, quality.url)
            }
        }
        val seriesTiles = seriesCategories.flatMap { it.items }.mapNotNull { series ->
            // Every episode, every season, in watch order - what makes the whole show
            // auto-play start to finish once you tap it.
            val episodes = series.seasons
                .sortedBy { it.seasonNumber }
                .flatMap { season -> season.episodes.sortedBy { it.episodeNumber } }
                .mapNotNull { episode ->
                    episode.qualities.firstOrNull()?.let { quality ->
                        PlayableMovie(
                            summary = ContentSummary(
                                id = episode.id,
                                title = "${series.summary.title} - ${episode.title}",
                                posterUrl = episode.posterUrl ?: series.summary.posterUrl,
                                backdropUrl = series.summary.backdropUrl,
                                description = episode.description,
                                year = series.summary.year,
                                type = ContentType.EPISODE
                            ),
                            streamUrl = quality.url
                        )
                    }
                }
            if (episodes.isEmpty()) null else BrowseTile.SeriesTile(series.summary, episodes)
        }

        allTiles = movieTiles + seriesTiles
    }

    LaunchedEffect(Unit) {
        load(forceRefresh = false)
        loading = false
    }

    val filtered = remember(allTiles, query) {
        if (query.isBlank()) allTiles else allTiles.filter { it.summary.title.contains(query, ignoreCase = true) }
    }
    val allMovieTiles = remember(filtered) { filtered.filterIsInstance<BrowseTile.MovieTile>() }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search movies & series") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .focusRequester(searchFocusRequester)
            )
            PullToRefreshBox(
                isRefreshing = refreshing,
                onRefresh = {
                    scope.launch {
                        refreshing = true
                        load(forceRefresh = true)
                        refreshing = false
                    }
                },
                modifier = Modifier.fillMaxSize()
            ) {
                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    filtered.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No movies or series found.", style = MaterialTheme.typography.bodyMedium)
                    }
                    else -> LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 120.dp),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filtered, key = { it.summary.id }) { tile ->
                            MoviesSeriesTile(
                                tile = tile,
                                onClick = {
                                    when (tile) {
                                        is BrowseTile.MovieTile -> {
                                            // Swiping in the player moves through every other browsed
                                            // movie, same as before - a series click below doesn't mix
                                            // into this list, it gets its own dedicated episode queue.
                                            val startIndex = allMovieTiles.indexOfFirst { it.summary.id == tile.summary.id }
                                                .coerceAtLeast(0)
                                            onPlay(allMovieTiles.map { PlayableMovie(it.summary, it.streamUrl) }, startIndex)
                                        }
                                        is BrowseTile.SeriesTile -> onPlay(tile.episodes, 0)
                                    }
                                },
                                libraryViewModel = libraryViewModel
                            )
                        }
                    }
                }
            }
        }

        // Left-edge swipe -> open drawer. Same raw-distance technique proven on Live
        // TV's edges, safe to use directly in Compose here since there's no embedded
        // AndroidFragment underneath competing for touch priority on this screen.
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .fillMaxHeight()
                .width(24.dp)
                .pointerInput(Unit) {
                    var totalDrag = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { totalDrag = 0f },
                        onHorizontalDrag = { _, dragAmount ->
                            totalDrag += dragAmount
                            if (totalDrag > swipeThresholdPx) onOpenDrawerRequested()
                        }
                    )
                }
        )

        // Right-edge swipe -> focus the search box (keyboard up, ready to type). No
        // separate slide-in panel needed here - the search field's always visible at
        // the top already, this just jumps straight to it.
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(24.dp)
                .pointerInput(Unit) {
                    var totalDrag = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { totalDrag = 0f },
                        onHorizontalDrag = { _, dragAmount ->
                            totalDrag += dragAmount
                            if (totalDrag < -swipeThresholdPx) searchFocusRequester.requestFocus()
                        }
                    )
                }
        )
    }
}

@Composable
private fun MoviesSeriesTile(
    tile: BrowseTile,
    onClick: () -> Unit,
    libraryViewModel: LibraryActionsViewModel
) {
    val isFavorite by libraryViewModel.isFavorite(tile.summary.id).collectAsState(initial = false)
    Box {
        PosterCard(summary = tile.summary, onClick = onClick)
        IconButton(
            onClick = {
                val streamUrl = when (tile) {
                    is BrowseTile.MovieTile -> tile.streamUrl
                    is BrowseTile.SeriesTile -> tile.episodes.firstOrNull()?.streamUrl.orEmpty()
                }
                val type = if (tile is BrowseTile.SeriesTile) ContentType.SERIES else ContentType.MOVIE
                libraryViewModel.setFavorite(
                    !isFavorite,
                    FavoriteEntity(
                        contentId = tile.summary.id,
                        title = tile.summary.title,
                        posterUrl = tile.summary.posterUrl,
                        type = type,
                        streamUrl = streamUrl,
                        addedAtMs = System.currentTimeMillis()
                    )
                )
            },
            modifier = Modifier.align(Alignment.TopEnd)
        ) {
            Icon(
                if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = "Toggle favorite",
                tint = Color.White
            )
        }
    }
}
