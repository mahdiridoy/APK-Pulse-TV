package com.mahdiridoy.iptvapp.movies

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import androidx.paging.compose.itemKey
import com.mahdiridoy.iptvapp.catalog.ContentSummary
import com.mahdiridoy.iptvapp.catalog.PosterCard
import com.mahdiridoy.iptvapp.catalog.db.BrowseTileRow
import com.mahdiridoy.iptvapp.data.ContentType
import com.mahdiridoy.iptvapp.data.LibraryActionsViewModel
import com.mahdiridoy.iptvapp.data.db.FavoriteEntity

/**
 * Movies & Series, merged into one screen, paged straight out of Room instead of held
 * as one in-memory list - see [MoviesSeriesViewModel] and
 * [com.mahdiridoy.iptvapp.catalog.CatalogSyncManager]. A movie plays by itself; a
 * series plays every episode in order, one after another (see [onPlay] and
 * [com.mahdiridoy.iptvapp.catalog.CatalogPlayback]) - update the M3U file and the
 * line-up here follows automatically, no app update needed.
 *
 * Swipe left from the left edge opens the nav drawer, swipe right from the right edge
 * focuses the search box (keyboard up, ready to type) - same gesture directions as
 * Live TV, implemented independently here since this screen is pure Compose (no
 * AndroidFragment interop to fight over touch priority with, unlike Live TV). Search
 * only ever filters this screen's own paging source - Live TV channels are a
 * completely separate screen/data source, so there's no risk of the two search boxes'
 * results bleeding into each other. Pulling down from the top re-syncs the catalog
 * from the network (bypassing the "unchanged" ETag check).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoviesSeriesScreen(
    onPlay: (id: String, title: String, type: ContentType) -> Unit,
    onOpenDrawerRequested: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: MoviesSeriesViewModel = viewModel(),
    libraryViewModel: LibraryActionsViewModel = viewModel()
) {
    val pagedTiles = viewModel.pagedTiles.collectAsLazyPagingItems()
    val query by viewModel.query.collectAsState()
    var refreshing by remember { mutableStateOf(false) }
    val density = LocalDensity.current
    val swipeThresholdPx = with(density) { 48.dp.toPx() }
    val searchFocusRequester = remember { FocusRequester() }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.setQuery(it) },
                label = { Text("Search movies & series") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .focusRequester(searchFocusRequester)
            )
            PullToRefreshBox(
                isRefreshing = refreshing,
                onRefresh = {
                    refreshing = true
                    viewModel.refreshFromNetwork()
                },
                modifier = Modifier.fillMaxSize()
            ) {
                // Paging3's own loadState, not a locally-tracked boolean - this reflects
                // what the PagingSource is actually doing, including a search query's
                // own fresh load.
                LaunchedEffect(pagedTiles.loadState.refresh) {
                    if (pagedTiles.loadState.refresh !is LoadState.Loading) {
                        refreshing = false
                    }
                }
                when {
                    pagedTiles.loadState.refresh is LoadState.Loading && pagedTiles.itemCount == 0 -> {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    }
                    pagedTiles.itemCount == 0 -> {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                if (query.isBlank()) {
                                    "No movies or series yet - still syncing in the background, check back shortly."
                                } else {
                                    "No matches for \"$query\"."
                                },
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                    else -> LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 120.dp),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(
                            count = pagedTiles.itemCount,
                            key = pagedTiles.itemKey { it.id }
                        ) { index ->
                            val tile = pagedTiles[index] ?: return@items
                            MoviesSeriesTile(
                                tile = tile,
                                onClick = {
                                    val type = if (tile.type == "SERIES") ContentType.SERIES else ContentType.MOVIE
                                    onPlay(tile.id, tile.title, type)
                                },
                                libraryViewModel = libraryViewModel
                            )
                        }
                    }
                }
            }
        }

        // Left-edge swipe -> open drawer. Same raw-distance technique proven on Live
        // TV's edges, safe to use directly in Compose here since there's no embedded
        // AndroidFragment underneath competing for touch priority on this screen.
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .fillMaxHeight()
                .width(24.dp)
                .pointerInput(Unit) {
                    var totalDrag = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { totalDrag = 0f },
                        onHorizontalDrag = { _, dragAmount ->
                            totalDrag += dragAmount
                            if (totalDrag > swipeThresholdPx) onOpenDrawerRequested()
                        }
                    )
                }
        )

        // Right-edge swipe -> focus the search box (keyboard up, ready to type). No
        // separate slide-in panel needed here - the search field's always visible at
        // the top already, this just jumps straight to it.
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(24.dp)
                .pointerInput(Unit) {
                    var totalDrag = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { totalDrag = 0f },
                        onHorizontalDrag = { _, dragAmount ->
                            totalDrag += dragAmount
                            if (totalDrag < -swipeThresholdPx) searchFocusRequester.requestFocus()
                        }
                    )
                }
        )
    }
}

@Composable
private fun MoviesSeriesTile(
    tile: BrowseTileRow,
    onClick: () -> Unit,
    libraryViewModel: LibraryActionsViewModel
) {
    val isFavorite by libraryViewModel.isFavorite(tile.id).collectAsState(initial = false)
    val summary = remember(tile) {
        ContentSummary(
            id = tile.id,
            title = tile.title,
            posterUrl = tile.logo,
            backdropUrl = tile.logo,
            description = null,
            year = null,
            type = if (tile.type == "SERIES") ContentType.SERIES else ContentType.MOVIE
        )
    }
    Box {
        PosterCard(summary = summary, onClick = onClick)
        IconButton(
            onClick = {
                libraryViewModel.setFavorite(
                    !isFavorite,
                    FavoriteEntity(
                        contentId = tile.id,
                        title = tile.title,
                        posterUrl = tile.logo,
                        type = summary.type,
                        // For a series, tile.id is the show title, not a real stream URL -
                        // harmless: CatalogPlayback looks the actual episode list up fresh
                        // from Room by (id, title, type) rather than trusting this field for
                        // MOVIE/SERIES types. Only Live TV's favorite playback still reads
                        // streamUrl directly. Kept non-blank since the column isn't nullable.
                        streamUrl = tile.id,
                        addedAtMs = System.currentTimeMillis()
                    )
                )
            },
            modifier = Modifier.align(Alignment.TopEnd)
        ) {
            Icon(
                if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = "Toggle favorite",
                tint = Color.White
            )
        }
    }
}
