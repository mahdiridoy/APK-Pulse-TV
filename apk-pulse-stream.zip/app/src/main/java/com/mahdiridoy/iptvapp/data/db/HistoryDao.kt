package com.mahdiridoy.iptvapp.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {

    @Query("SELECT * FROM history WHERE contentId = :contentId LIMIT 1")
    suspend fun getById(contentId: String): HistoryEntity?

    @Query("SELECT * FROM history ORDER BY lastWatchedAtMs DESC")
    fun observeAll(): Flow<List<HistoryEntity>>

    @Query(
        "SELECT * FROM history WHERE positionMs > 0 AND positionMs < (durationMs * 0.95) " +
            "AND durationMs > 0 ORDER BY lastWatchedAtMs DESC"
    )
    fun observeContinueWatching(): Flow<List<HistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: HistoryEntity)

    /** Used by the player's periodic progress writer - leaves title/poster/type alone. */
    @Query(
        "UPDATE history SET positionMs = :positionMs, durationMs = :durationMs, " +
            "lastWatchedAtMs = :lastWatchedAtMs WHERE contentId = :contentId"
    )
    suspend fun updateProgress(contentId: String, positionMs: Long, durationMs: Long, lastWatchedAtMs: Long)

    @Query("DELETE FROM history WHERE contentId = :contentId")
    suspend fun removeById(contentId: String)

    @Query("DELETE FROM history")
    suspend fun clearAll()
}
