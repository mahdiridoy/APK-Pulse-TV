package com.mahdiridoy.iptvapp.core.theme

import androidx.compose.ui.graphics.Color

// Pulled from the existing values/colors.xml so the Compose screens match the
// Views-based ones (Live TV, Player) pixel-for-pixel during the migration.
val PulseBackground = Color(0xFF0D0D12)
val PulseSurface = Color(0xFF1E1E29)
val PulseNavRail = Color(0xFF16161F)
val PulseAccent = Color(0xFFFF5A1F)
val PulseOnDark = Color(0xFFEAEAEA)
