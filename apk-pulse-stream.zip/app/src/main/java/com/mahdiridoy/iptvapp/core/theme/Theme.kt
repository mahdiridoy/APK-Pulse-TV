package com.mahdiridoy.iptvapp.core.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

// Pulse Stream is dark-themed only by design (matches the existing Views UI) -
// no light color scheme branch, intentionally.
private val PulseColorScheme = darkColorScheme(
    primary = PulseAccent,
    onPrimary = PulseOnDark,
    secondary = PulseAccent,
    background = PulseBackground,
    onBackground = PulseOnDark,
    surface = PulseSurface,
    onSurface = PulseOnDark,
    surfaceVariant = PulseNavRail,
)

@Composable
fun PulseStreamTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PulseColorScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
