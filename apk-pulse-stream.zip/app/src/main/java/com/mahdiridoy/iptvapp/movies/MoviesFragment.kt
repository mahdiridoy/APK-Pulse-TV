package com.mahdiridoy.iptvapp.movies

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.mahdiridoy.iptvapp.SearchableFragment
import com.mahdiridoy.iptvapp.databinding.FragmentMoviesBinding
import com.mahdiridoy.iptvapp.player.PlaybackQueue
import com.mahdiridoy.iptvapp.player.PlayerActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MoviesFragment : Fragment(), SearchableFragment {

    private var _binding: FragmentMoviesBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: MovieItemAdapter
    private lateinit var searchAdapter: MovieItemAdapter
    private var currentItems: List<MovieItem> = emptyList()
    private var searchVisible = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMoviesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val openPlayer = openPlayer@{ list: List<MovieItem>, index: Int ->
            val item = list.getOrNull(index)
            if (item?.isPlugin == true) {
                viewLifecycleOwner.lifecycleScope.launch {
                    val installed = withContext(Dispatchers.IO) {
                        RepoRepository.installPlugin(requireContext(), item)
                    }
                    val updatedItems = currentItems.map { currentItem ->
                        if (currentItem.title == item.title && currentItem.streamUrl == item.streamUrl) {
                            currentItem.copy(isInstalled = installed)
                        } else {
                            currentItem
                        }
                    }
                    currentItems = updatedItems
                    adapter.updateData(updatedItems)
                    val message = if (installed) {
                        "${item.title} was installed as a provider package."
                    } else {
                        "${item.title} is available from the repo but could not be installed yet."
                    }
                    Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
                }
                return@openPlayer
            }
            if (item == null || item.streamUrl.isBlank()) {
                Toast.makeText(requireContext(), "No playable stream was found for this item.", Toast.LENGTH_SHORT).show()
                return@openPlayer
            }
            PlaybackQueue.set(list.map { it.title }, list.map { it.streamUrl }, index)
            startActivity(Intent(requireContext(), PlayerActivity::class.java))
        }

        adapter = MovieItemAdapter(emptyList()) { item ->
            val index = currentItems.indexOf(item).coerceAtLeast(0)
            openPlayer(currentItems, index)
        }

        val spanCount = if (resources.configuration.screenWidthDp > 600) 5 else 3
        binding.movieGrid.layoutManager = GridLayoutManager(requireContext(), spanCount)
        binding.movieGrid.adapter = adapter

        buildRepoButtons()
        setupSearch(openPlayer)

        RepoRegistry.repos.firstOrNull()?.let { loadRepo(it) }
    }

    private fun buildRepoButtons() {
        binding.repoButtonRow.removeAllViews()
        RepoRegistry.repos.forEach { repo ->
            val button = Button(requireContext()).apply {
                text = repo.name
                isFocusable = true
                setOnClickListener { loadRepo(repo) }
            }
            binding.repoButtonRow.addView(button)
        }
    }

    private fun loadRepo(repo: Repo) {
        binding.moviesEmptyState.visibility = View.GONE
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val items = withContext(Dispatchers.IO) { RepoRepository.fetchItems(requireContext(), repo) }
                currentItems = items
                adapter.updateData(items)
                binding.moviesEmptyState.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Couldn't load ${repo.name}: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                binding.moviesEmptyState.visibility = View.VISIBLE
            }
        }
    }

    // ---- Movie/series search: scoped to the currently loaded repo's items only ----

    private fun setupSearch(openPlayer: (List<MovieItem>, Int) -> Unit) {
        var filtered: List<MovieItem> = emptyList()
        searchAdapter = MovieItemAdapter(emptyList()) { item ->
            val index = filtered.indexOf(item).coerceAtLeast(0)
            openPlayer(filtered, index)
        }
        binding.searchResults.layoutManager = LinearLayoutManager(requireContext())
        binding.searchResults.adapter = searchAdapter
        binding.searchClose.setOnClickListener { closeSearch() }

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                val query = s?.toString()?.trim().orEmpty()
                filtered = if (query.isEmpty()) emptyList()
                else currentItems.filter {
                    it.title.contains(query, ignoreCase = true) ||
                        it.description?.contains(query, ignoreCase = true) == true
                }
                searchAdapter.updateData(filtered)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun openSearch() {
        if (searchVisible) return
        searchVisible = true
        binding.searchPanel.visibility = View.VISIBLE
        binding.searchPanel.animate().translationX(0f).setDuration(200).start()
        binding.searchInput.requestFocus()
    }

    override fun closeSearch() {
        if (!searchVisible) return
        searchVisible = false
        binding.searchPanel.animate()
            .translationX(binding.searchPanel.width.toFloat())
            .setDuration(200)
            .withEndAction { binding.searchPanel.visibility = View.INVISIBLE }
            .start()
        binding.searchInput.setText("")
    }

    override fun isSearchOpen(): Boolean = searchVisible

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
