package com.mahdiridoy.iptvapp.catalog

import android.content.Context
import com.mahdiridoy.iptvapp.catalog.db.CatalogDatabase
import com.mahdiridoy.iptvapp.catalog.db.MovieRow
import com.mahdiridoy.iptvapp.catalog.db.SeriesEpisodeRow
import com.mahdiridoy.iptvapp.livetv.M3uParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * Keeps [CatalogDatabase] in sync with the Movies & Series M3U - see the module doc on
 * [sync] for the full pipeline. The UI never talks to the network or does any parsing
 * itself; it only ever reads from Room (via [com.mahdiridoy.iptvapp.catalog.db.CatalogDao]'s
 * PagingSource queries), which is what makes a 130k+ row catalog open instantly on every
 * launch after the first.
 */
object CatalogSyncManager {

    /** Single, permanent M3U source for both Movies and Series. */
    const val M3U_CATALOG_URL =
        "https://huggingface.co/datasets/mahdirid/ridoymovieserver/resolve/main/ridoymovieserver.m3u"

    private const val PREFS_NAME = "catalog_sync"
    private const val KEY_ETAG = "etag"
    private const val KEY_LAST_MODIFIED = "last_modified"

    // Large enough to keep transaction overhead low against 130k+ rows, small enough
    // that memory use stays flat regardless of total file size - this list is reused
    // (cleared, not reallocated) for every batch rather than growing without bound.
    private const val BATCH_SIZE = 1000

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    /**
     * Same show-detection rule as before: a title carrying a SxxEyy marker is an
     * episode (group 1 = show title, group 2 = season, group 3 = episode, group 4 =
     * whatever trails the marker, usually the episode's own title); anything else is a
     * movie. Nothing about future M3U updates needs this to change - new shows/seasons/
     * episodes just get classified the same way automatically.
     */
    private val seriesEpisodePattern = Regex("""(?i)^(.*?)[\s._-]*S(\d{1,2})\s*E(\d{1,3})\b[\s._-]*(.*)$""")

    /**
     * Full pipeline, run entirely on [Dispatchers.IO]:
     *
     * 1. Conditional GET - sends the ETag/Last-Modified from the last successful sync
     *    (if any) as If-None-Match/If-Modified-Since. A 304 response means the file
     *    hasn't changed at all, so the whole rest of this is skipped - no download, no
     *    parsing, no database writes. This is what "only redownload when the playlist
     *    changes" actually means at the HTTP level.
     * 2. If the file DID change (200 response): stream the response body through a
     *    BufferedReader's line sequence - at no point does the full ~38MB response
     *    exist as one String or List in memory, only whatever's in the current 1000-row
     *    batch. GZIP is handled transparently by OkHttp already (it requests and
     *    decodes it automatically whenever the server offers it, with no extra code
     *    needed here) so this is already getting that benefit for free.
     * 3. Each line is classified as a movie or a series episode (see
     *    [seriesEpisodePattern]) and appended to the matching in-flight batch; once a
     *    batch hits [BATCH_SIZE] it's upserted into Room immediately and cleared, so the
     *    UI (reading the same tables live via Paging3) can start showing fresh rows
     *    while the rest of the file is still downloading.
     * 4. Once the stream ends, any leftover partial batches are flushed, then rows not
     *    touched by this pass (i.e. genuinely removed from the remote file) are deleted.
     *    This is a mark-and-sweep replace rather than a literal file-level swap: readers
     *    never see an empty or partially-cleared table at any point, existing rows are
     *    updated in place, and the end state matches the new file exactly either way.
     * 5. The new ETag/Last-Modified are saved for next time.
     *
     * Safe to call from anywhere, anytime - it's a no-op background refresh unless
     * [forceRefresh] is set or the remote file has actually changed.
     */
    suspend fun sync(context: Context, forceRefresh: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val dao = CatalogDatabase.getInstance(context).catalogDao()

        val requestBuilder = Request.Builder().url(M3U_CATALOG_URL)
        if (!forceRefresh) {
            prefs.getString(KEY_ETAG, null)?.let { requestBuilder.header("If-None-Match", it) }
            prefs.getString(KEY_LAST_MODIFIED, null)?.let { requestBuilder.header("If-Modified-Since", it) }
        }

        val response = try {
            client.newCall(requestBuilder.build()).execute()
        } catch (e: IOException) {
            return@withContext false
        }

        response.use { resp ->
            if (resp.code == 304) {
                // Not modified - what's already in Room is current, nothing to do.
                return@withContext true
            }
            if (!resp.isSuccessful) return@withContext false

            val body = resp.body ?: return@withContext false
            val syncStartedAt = System.currentTimeMillis()

            val movieBatch = ArrayList<MovieRow>(BATCH_SIZE)
            val episodeBatch = ArrayList<SeriesEpisodeRow>(BATCH_SIZE)

            InputStreamReader(body.byteStream()).buffered().use { reader ->
                M3uParser.streamEntries(reader.lineSequence()) { info, streamUrl ->
                    val match = seriesEpisodePattern.find(info.name)
                    if (match == null) {
                        movieBatch.add(
                            MovieRow(
                                id = streamUrl,
                                title = info.name,
                                logo = info.logoUrl,
                                groupName = info.group,
                                url = streamUrl,
                                tvgId = info.tvgId,
                                lastSyncedAt = syncStartedAt
                            )
                        )
                        if (movieBatch.size >= BATCH_SIZE) {
                            // Non-suspend on purpose - see the comment on upsertMoviesBlocking
                            // in CatalogDao. We're already on Dispatchers.IO for this whole
                            // function, so a direct blocking call here is correct.
                            dao.upsertMoviesBlocking(ArrayList(movieBatch))
                            movieBatch.clear()
                        }
                    } else {
                        val showTitle = match.groupValues[1].trim(' ', '-', '_', '.').ifBlank { info.name }
                        val season = match.groupValues[2].toIntOrNull() ?: 1
                        val episodeNumber = match.groupValues[3].toIntOrNull() ?: 0
                        episodeBatch.add(
                            SeriesEpisodeRow(
                                id = streamUrl,
                                title = match.groupValues[4].trim(' ', '-', '_', '.', ':')
                                    .ifBlank { "Episode $episodeNumber" },
                                logo = info.logoUrl,
                                groupName = info.group,
                                url = streamUrl,
                                showTitle = showTitle,
                                season = season,
                                episode = episodeNumber,
                                lastSyncedAt = syncStartedAt
                            )
                        )
                        if (episodeBatch.size >= BATCH_SIZE) {
                            dao.upsertEpisodesBlocking(ArrayList(episodeBatch))
                            episodeBatch.clear()
                        }
                    }
                }
            }
            if (movieBatch.isNotEmpty()) dao.upsertMovies(movieBatch)
            if (episodeBatch.isNotEmpty()) dao.upsertEpisodes(episodeBatch)

            dao.deleteStaleMovies(syncStartedAt)
            dao.deleteStaleEpisodes(syncStartedAt)

            val editor = prefs.edit()
            resp.header("ETag")?.let { editor.putString(KEY_ETAG, it) }
            resp.header("Last-Modified")?.let { editor.putString(KEY_LAST_MODIFIED, it) }
            editor.apply()
        }
        true
    }
}
