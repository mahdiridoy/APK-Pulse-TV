package com.mahdiridoy.iptvapp.history

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mahdiridoy.iptvapp.data.db.HistoryEntity

@Composable
fun HistoryScreen(
    modifier: Modifier = Modifier,
    viewModel: HistoryViewModel = viewModel(),
    onHistoryClick: (HistoryEntity) -> Unit = {}
) {
    val history by viewModel.history.collectAsState()

    if (history.isEmpty()) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("No watch history yet", style = MaterialTheme.typography.titleMedium)
                Text(
                    "What you watch will show up here once playback is wired to it.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        return
    }

    Column(modifier = modifier.fillMaxSize()) {
        TextButton(
            onClick = { viewModel.clearAll() },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
        ) {
            Text("Clear all")
        }
        LazyColumn(modifier = Modifier.fillMaxSize().padding(vertical = 8.dp)) {
            items(history, key = { it.contentId }) { entry ->
                val progressLabel = if (entry.durationMs > 0 && entry.positionMs > 0) {
                    val percent = (entry.positionMs * 100 / entry.durationMs).coerceIn(0, 100)
                    "${entry.type.name} - $percent% watched"
                } else {
                    entry.type.name
                }
                ListItem(
                    headlineContent = { Text(entry.title) },
                    supportingContent = { Text(progressLabel) },
                    trailingContent = {
                        IconButton(onClick = { viewModel.removeEntry(entry.contentId) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Remove from history")
                        }
                    },
                    modifier = Modifier.clickable { onHistoryClick(entry) }
                )
            }
        }
    }
}
