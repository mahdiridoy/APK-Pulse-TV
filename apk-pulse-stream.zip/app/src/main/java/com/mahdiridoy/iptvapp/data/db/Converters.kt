package com.mahdiridoy.iptvapp.data.db

import androidx.room.TypeConverter
import com.mahdiridoy.iptvapp.data.ContentType

class Converters {
    @TypeConverter
    fun fromContentType(type: ContentType): String = type.name

    @TypeConverter
    fun toContentType(value: String): ContentType =
        runCatching { ContentType.valueOf(value) }.getOrDefault(ContentType.MOVIE)
}
