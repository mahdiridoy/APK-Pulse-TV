package com.mahdiridoy.iptvapp.movies

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class InstalledProvider(
    val id: String,
    val title: String,
    val repositoryName: String?,
    val providerId: String?,
    val packagePath: String,
    val downloadUrl: String,
    val qualities: List<com.mahdiridoy.iptvapp.catalog.Quality> = emptyList(),
    val installedAtMs: Long
)

object ProviderRegistry {
    private const val STORE_FILE = "installed_providers.json"

    fun load(context: Context): List<InstalledProvider> {
        val file = File(context.filesDir, STORE_FILE)
        if (!file.exists()) return emptyList()

        return runCatching {
            val array = JSONArray(file.readText(Charsets.UTF_8))
            (0 until array.length()).mapNotNull { index ->
                val obj = array.optJSONObject(index) ?: return@mapNotNull null
                InstalledProvider(
                    id = obj.optString("id").takeIf { it.isNotBlank() } ?: obj.optString("providerId", obj.optString("title")),
                    title = obj.optString("title").ifBlank { "Provider" },
                    repositoryName = obj.optString("repositoryName").takeIf { it.isNotBlank() },
                    providerId = obj.optString("providerId").takeIf { it.isNotBlank() },
                    packagePath = obj.optString("packagePath"),
                    downloadUrl = obj.optString("downloadUrl"),
                    qualities = parseQualities(obj.optJSONArray("qualities")),
                    installedAtMs = obj.optLong("installedAtMs", System.currentTimeMillis())
                )
            }
        }.getOrDefault(emptyList())
    }

    fun save(context: Context, providers: List<InstalledProvider>) {
        val file = File(context.filesDir, STORE_FILE)
        val array = JSONArray()
        providers.forEach { provider ->
            array.put(JSONObject().apply {
                put("id", provider.id)
                put("title", provider.title)
                put("repositoryName", provider.repositoryName)
                put("providerId", provider.providerId)
                put("packagePath", provider.packagePath)
                put("downloadUrl", provider.downloadUrl)
                put("qualities", JSONArray().apply {
                    provider.qualities.forEach { quality ->
                        put(JSONObject().apply {
                            put("label", quality.label)
                            put("url", quality.url)
                        })
                    }
                })
                put("installedAtMs", provider.installedAtMs)
            })
        }
        file.writeText(array.toString(), Charsets.UTF_8)
    }

    fun addOrUpdate(context: Context, provider: InstalledProvider) {
        val providers = (load(context) + provider)
            .distinctBy { it.id }
            .sortedByDescending { it.installedAtMs }
        save(context, providers)
    }

    fun isInstalled(context: Context, providerId: String?, title: String, packagePath: String): Boolean {
        val normalized = providerId ?: title
        return load(context).any { installed ->
            installed.id == normalized || installed.providerId == normalized || installed.packagePath == packagePath
        }
    }

    fun providerKey(title: String, repositoryName: String?, providerId: String?): String {
        val base = listOf(providerId, title, repositoryName).filterNotNull().joinToString("|")
        return base.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').ifBlank { "provider" }
    }

    private fun parseQualities(array: JSONArray?): List<com.mahdiridoy.iptvapp.catalog.Quality> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            val obj = array.optJSONObject(index) ?: return@mapNotNull null
            val url = obj.optString("url").ifBlank { return@mapNotNull null }
            com.mahdiridoy.iptvapp.catalog.Quality(
                label = obj.optString("label", "Default"),
                url = url
            )
        }
    }
}
