package com.mahdiridoy.iptvapp.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mahdiridoy.iptvapp.update.DriveUpdateChecker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface UpdateCheckState {
    data object Idle : UpdateCheckState
    data object Checking : UpdateCheckState
    data class Available(val versionLabel: String, val apkUrl: String) : UpdateCheckState
    data class NotAvailable(val reason: String) : UpdateCheckState
}

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val _updateCheckState = MutableStateFlow<UpdateCheckState>(UpdateCheckState.Idle)
    val updateCheckState: StateFlow<UpdateCheckState> = _updateCheckState.asStateFlow()

    fun checkForUpdate() {
        _updateCheckState.value = UpdateCheckState.Checking
        viewModelScope.launch {
            val (info, reason) = withContext(Dispatchers.IO) {
                DriveUpdateChecker.checkForUpdateVerbose()
            }
            _updateCheckState.value = if (info != null) {
                UpdateCheckState.Available(info.version, info.downloadUrl)
            } else {
                UpdateCheckState.NotAvailable(reason)
            }
        }
    }

    fun dismissUpdateCheck() {
        _updateCheckState.value = UpdateCheckState.Idle
    }
}
