package com.mahdiridoy.iptvapp.plugins

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * What actually needs remembering between launches for a CloudStream plugin: just
 * where its downloaded `.cs3` sits on disk, so [CloudStreamPluginManager] can reload
 * it on the next app start. Everything else (its provider name, what it can play) is
 * discovered live from the plugin itself once loaded - not worth persisting or letting
 * go stale.
 *
 * Replaces the old `ProviderRegistry`/`InstalledProvider` model, which stored a single
 * fabricated "downloadUrl" per provider as if a whole CloudStream plugin were one
 * direct video link - that assumption is what made Movies & Series never load
 * anything real; see MoviesSeriesViewModel's doc comment.
 */
data class InstalledPlugin(
    val name: String,
    val repositoryName: String?,
    val filePath: String,
    val installedAtMs: Long
)

object InstalledPluginStore {
    private const val STORE_FILE = "installed_cs3_plugins.json"

    fun load(context: Context): List<InstalledPlugin> {
        val file = File(context.filesDir, STORE_FILE)
        if (!file.exists()) return emptyList()
        return runCatching {
            val array = JSONArray(file.readText(Charsets.UTF_8))
            (0 until array.length()).mapNotNull { index ->
                val obj = array.optJSONObject(index) ?: return@mapNotNull null
                val filePath = obj.optString("filePath").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                InstalledPlugin(
                    name = obj.optString("name", "Plugin"),
                    repositoryName = obj.optString("repositoryName").takeIf { it.isNotBlank() },
                    filePath = filePath,
                    installedAtMs = obj.optLong("installedAtMs", System.currentTimeMillis())
                )
            }
        }.getOrDefault(emptyList())
    }

    fun addOrUpdate(context: Context, plugin: InstalledPlugin) {
        val updated = (load(context).filterNot { it.filePath == plugin.filePath } + plugin)
        save(context, updated)
    }

    private fun save(context: Context, plugins: List<InstalledPlugin>) {
        val array = JSONArray()
        plugins.forEach { plugin ->
            array.put(JSONObject().apply {
                put("name", plugin.name)
                put("repositoryName", plugin.repositoryName)
                put("filePath", plugin.filePath)
                put("installedAtMs", plugin.installedAtMs)
            })
        }
        File(context.filesDir, STORE_FILE).writeText(array.toString(), Charsets.UTF_8)
    }
}
