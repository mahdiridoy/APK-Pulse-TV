package com.mahdiridoy.iptvapp.plugins

import com.lagradost.cloudstream3.APIHolder
import com.lagradost.cloudstream3.Episode
import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.MovieLoadResponse
import com.lagradost.cloudstream3.SearchResponse
import com.lagradost.cloudstream3.TvSeriesLoadResponse
import com.lagradost.cloudstream3.TvType
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.mahdiridoy.iptvapp.catalog.ContentSummary
import com.mahdiridoy.iptvapp.catalog.Quality
import com.mahdiridoy.iptvapp.data.ContentType
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

/** One search hit from a real installed plugin, kept alongside which [MainAPI] it came
 * from since playing it later needs to call back into that same provider. */
data class PluginSearchResult(
    val providerName: String,
    val response: SearchResponse
)

/** A resolved, playable episode from a plugin-backed series (episode title + the
 * `data` string its provider's loadLinks() expects). */
data class PluginEpisode(
    val title: String,
    val data: String
)

object CloudStreamBridge {

    fun toContentSummary(result: PluginSearchResult): ContentSummary {
        val r = result.response
        return ContentSummary(
            id = pluginResultId(result),
            title = r.name,
            posterUrl = r.posterUrl,
            backdropUrl = r.posterUrl,
            description = null,
            year = null,
            type = if (r.type == TvType.TvSeries || r.type == TvType.Anime) ContentType.SERIES else ContentType.MOVIE
        )
    }

    /** Encodes which provider + which result, so a UI id round-trips back to both
     * without a separate lookup table. */
    fun pluginResultId(result: PluginSearchResult): String =
        "cs3://${result.providerName}/${result.response.url}"

    fun parsePluginResultId(id: String): Pair<String, String>? {
        if (!id.startsWith("cs3://")) return null
        val rest = id.removePrefix("cs3://")
        val slash = rest.indexOf('/')
        if (slash <= 0) return null
        return rest.substring(0, slash) to rest.substring(slash + 1)
    }

    /**
     * Searches every currently-loaded plugin's provider concurrently. Only providers
     * already registered in [APIHolder.allProviders] (i.e. successfully loaded by
     * [CloudStreamPluginManager]) are queried - nothing here downloads or installs
     * anything.
     */
    suspend fun search(query: String): List<PluginSearchResult> = coroutineScope {
        val providers = APIHolder.allProviders.toList()
        val results = mutableListOf<PluginSearchResult>()
        val jobs = providers.map { provider ->
            launch {
                val hits = runCatching { provider.search(query) }.getOrNull().orEmpty()
                synchronized(results) {
                    results.addAll(hits.map { PluginSearchResult(provider.name, it) })
                }
            }
        }
        jobs.forEach { it.join() }
        results
    }

    /**
     * Resolves a movie search result down to playable [Quality] options (each
     * carrying whatever Referer/headers that specific link needs - see
     * PlaybackQueue.urlHeaders / PlayerActivity). Returns an empty list if the
     * provider's loadLinks() never calls its callback (dead/removed source).
     */
    suspend fun resolveMovieQualities(result: PluginSearchResult): List<Quality> {
        val provider = CloudStreamPluginManager.findProvider(result.providerName) ?: return emptyList()
        val loadResponse = runCatching { provider.load(result.response.url) }.getOrNull() ?: return emptyList()
        val dataUrl = (loadResponse as? MovieLoadResponse)?.dataUrl ?: return emptyList()
        return resolveLinks(provider, dataUrl)
    }

    /** Same idea, for a series: every episode plus the `data` string its provider's
     * loadLinks() needs, in show order. */
    suspend fun resolveSeriesEpisodes(result: PluginSearchResult): List<PluginEpisode> {
        val provider = CloudStreamPluginManager.findProvider(result.providerName) ?: return emptyList()
        val loadResponse = runCatching { provider.load(result.response.url) }.getOrNull() ?: return emptyList()
        val episodes = (loadResponse as? TvSeriesLoadResponse)?.episodes ?: return emptyList()
        return episodes.map { ep: Episode ->
            val label = ep.name ?: buildString {
                ep.season?.let { append("S$it ") }
                ep.episode?.let { append("E$it") }
            }.ifBlank { "Episode" }
            PluginEpisode(title = label, data = ep.data)
        }
    }

    suspend fun resolveEpisodeQualities(providerName: String, episode: PluginEpisode): List<Quality> {
        val provider = CloudStreamPluginManager.findProvider(providerName) ?: return emptyList()
        return resolveLinks(provider, episode.data)
    }

    private suspend fun resolveLinks(provider: MainAPI, dataUrl: String): List<Quality> {
        val links = mutableListOf<ExtractorLink>()
        runCatching {
            provider.loadLinks(
                data = dataUrl,
                isCasting = false,
                subtitleCallback = { /* subtitles: not wired up yet */ },
                callback = { link -> synchronized(links) { links.add(link) } }
            )
        }
        // Highest quality first, so PlayerActivity's default (first) selection is the best one.
        return links.sortedByDescending { it.quality }.map { link ->
            Quality(
                label = link.name.ifBlank { "${link.quality}p" },
                url = link.url,
                headers = link.getAllHeaders()
            )
        }
    }
}
