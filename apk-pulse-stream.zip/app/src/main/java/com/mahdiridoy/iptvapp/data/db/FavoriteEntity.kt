package com.mahdiridoy.iptvapp.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mahdiridoy.iptvapp.data.ContentType

/**
 * A favorited channel, movie, or series.
 *
 * [contentId] is a stable identifier for the underlying content - for Live TV this
 * is the channel's stream URL, for Movies/Series it's the manifest item's stream
 * URL (or a series id once the Movies rebuild lands in a later milestone). Using
 * the same id scheme as [HistoryEntity] lets both tables be joined/looked-up
 * consistently from any section of the app.
 */
@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val contentId: String,
    val title: String,
    val posterUrl: String?,
    val type: ContentType,
    val streamUrl: String,
    val addedAtMs: Long
)
