package com.mahdiridoy.iptvapp.search

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Milestone 1 placeholder for a single, global search across Live TV/Movies/Series.
 *
 * Known temporary overlap: [com.mahdiridoy.iptvapp.livetv.LiveTvFragment] still has
 * its own in-screen search icon/panel (untouched, per "don't remove existing Live TV
 * functionality"). This tab and that panel both exist until the Live TV screen gets
 * folded into unified search in a later milestone - flagging it now, not fixing it
 * mid-milestone.
 */
@Composable
fun SearchScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Search", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Global search across Live TV, Movies and Series arrives once all three have real data.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
