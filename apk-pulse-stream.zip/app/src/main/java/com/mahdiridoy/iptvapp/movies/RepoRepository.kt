package com.mahdiridoy.iptvapp.movies

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

object RepoRepository {
    private const val CLOUDSTREAM_SCHEME = "cloudstreamrepo://"
    private val client = OkHttpClient()

    @Throws(IOException::class)
    fun fetchItems(context: Context, repo: Repo): List<MovieItem> {
        val manifestUrl = repo.manifestUrl
        return if (manifestUrl.startsWith(CLOUDSTREAM_SCHEME)) {
            fetchCloudStreamPlugins(context, manifestUrl.removePrefix(CLOUDSTREAM_SCHEME), repo.name)
        } else {
            val request = Request.Builder().url(manifestUrl).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Failed to fetch ${repo.name}: HTTP ${response.code}")
                }
                val body = response.body?.string() ?: "[]"
                parseSimpleManifest(body)
            }
        }
    }

    private fun fetchCloudStreamPlugins(context: Context, repoUrl: String, repoName: String): List<MovieItem> {
        val repoJson = fetchString(repoUrl)
        val root = JSONObject(repoJson)
        val pluginLists = root.optJSONArray("pluginLists") ?: JSONArray()
        val installDir = File(context.cacheDir, "cloudstream_plugins/${repoName.replace(Regex("[^A-Za-z0-9._-]+"), "_")}")
        installDir.mkdirs()

        val items = mutableListOf<MovieItem>()
        for (i in 0 until pluginLists.length()) {
            val listUrl = pluginLists.optString(i).takeIf { it.isNotBlank() } ?: continue
            val pluginListJson = fetchString(listUrl)
            val pluginEntries = JSONArray(pluginListJson)
            for (j in 0 until pluginEntries.length()) {
                val plugin = pluginEntries.optJSONObject(j) ?: continue
                val status = plugin.optInt("status", 0)
                if (status != 1) continue

                val title = plugin.optString("name", "Untitled Plugin")
                val description = plugin.optString("description").ifBlank { null }
                val iconUrl = plugin.optString("iconUrl").ifBlank { null }
                val externalUrl = plugin.optString("url").ifBlank { plugin.optString("jarUrl") }
                if (externalUrl.isBlank()) continue

                val tvTypes = plugin.optJSONArray("tvTypes") ?: JSONArray()
                val supportsMovieContent = (0 until tvTypes.length()).any { index ->
                    val type = tvTypes.optString(index)
                    type.equals("Movie", ignoreCase = true) ||
                        type.equals("TvSeries", ignoreCase = true) ||
                        type.equals("AnimeMovie", ignoreCase = true) ||
                        type.equals("All", ignoreCase = true)
                }
                if (!supportsMovieContent) continue

                val payload = JSONObject().apply {
                    put("name", title)
                    put("description", description ?: "CloudStream plugin")
                    put("iconUrl", iconUrl ?: "")
                    put("source", listUrl)
                    put("url", externalUrl)
                }
                File(installDir, "$title.json").writeText(payload.toString(), Charsets.UTF_8)

                items.add(
                    MovieItem(
                        title = title,
                        posterUrl = iconUrl,
                        streamUrl = externalUrl,
                        description = description,
                        isPlugin = true
                    )
                )
            }
        }
        return items
    }

    private fun fetchString(url: String): String {
        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Failed to fetch $url: HTTP ${response.code}")
            }
            return response.body?.string() ?: ""
        }
    }

    private fun parseSimpleManifest(json: String): List<MovieItem> {
        val array = JSONArray(json)
        val items = mutableListOf<MovieItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val streamUrl = obj.optString("streamUrl")
            if (streamUrl.isBlank()) continue
            items.add(
                MovieItem(
                    title = obj.optString("title", "Untitled"),
                    posterUrl = obj.optString("poster").ifBlank { null },
                    streamUrl = streamUrl,
                    description = obj.optString("description").ifBlank { null }
                )
            )
        }
        return items
    }
}
