package com.mahdiridoy.iptvapp.movies

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.URLConnection
import java.util.zip.ZipFile

object RepoRepository {
    private const val CLOUDSTREAM_SCHEME = "cloudstreamrepo://"
    private val client = OkHttpClient()

    fun normalizeUrl(rawUrl: String): String {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty() || trimmed.contains("://")) return trimmed
        return if (trimmed.startsWith("raw.githubusercontent.com/") || trimmed.startsWith("github.com/")) {
            "https://$trimmed"
        } else {
            "https://$trimmed"
        }
    }

    @Throws(IOException::class)
    fun fetchItems(context: Context, repo: Repo): List<MovieItem> {
        val manifestUrl = repo.manifestUrl
        return if (manifestUrl.startsWith(CLOUDSTREAM_SCHEME)) {
            fetchCloudStreamPlugins(context, manifestUrl.removePrefix(CLOUDSTREAM_SCHEME), repo.name)
        } else if (looksLikeArchiveUrl(manifestUrl)) {
            fetchPackageItems(context, manifestUrl, repo.name)
        } else {
            val request = Request.Builder().url(normalizeUrl(manifestUrl)).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Failed to fetch ${repo.name}: HTTP ${response.code}")
                }
                val body = response.body?.string() ?: "[]"
                parseSimpleManifest(body)
            }
        }
    }

    private fun fetchCloudStreamPlugins(context: Context, repoUrl: String, repoName: String): List<MovieItem> {
        val repoJson = fetchString(repoUrl)
        val root = JSONObject(repoJson)
        val pluginLists = root.optJSONArray("pluginLists") ?: JSONArray()
        val installDir = File(context.cacheDir, "cloudstream_plugins/${repoName.replace(Regex("[^A-Za-z0-9._-]+"), "_")}")
        installDir.mkdirs()

        val items = mutableListOf<MovieItem>()
        for (i in 0 until pluginLists.length()) {
            val listUrl = pluginLists.optString(i).takeIf { it.isNotBlank() } ?: continue
            val pluginEntries = parsePluginEntries(fetchString(listUrl))
            for (plugin in pluginEntries) {
                val status = plugin.optInt("status", 1)
                if (status == 0) continue

                val title = plugin.optString("name", "Untitled Plugin").takeIf { it.isNotBlank() } ?: continue
                val description = plugin.optString("description").ifBlank { null }
                val iconUrl = plugin.optString("iconUrl").ifBlank { null }
                val externalUrl = plugin.optString("url").ifBlank { plugin.optString("jarUrl") }
                if (externalUrl.isBlank()) continue

                val tvTypes = plugin.optJSONArray("tvTypes") ?: JSONArray()
                val tvTypeText = buildString {
                    for (index in 0 until tvTypes.length()) {
                        if (index > 0) append('|')
                        append(tvTypes.optString(index))
                    }
                }
                val supportsMovieContent = tvTypeText.isBlank() ||
                    tvTypeText.contains("Movie", ignoreCase = true) ||
                    tvTypeText.contains("TvSeries", ignoreCase = true) ||
                    tvTypeText.contains("AnimeMovie", ignoreCase = true) ||
                    tvTypeText.contains("Anime", ignoreCase = true) ||
                    tvTypeText.contains("Cartoon", ignoreCase = true) ||
                    tvTypeText.contains("All", ignoreCase = true)
                if (!supportsMovieContent) continue

                val payload = JSONObject().apply {
                    put("name", title)
                    put("description", description ?: "CloudStream plugin")
                    put("iconUrl", iconUrl ?: "")
                    put("source", listUrl)
                    put("url", externalUrl)
                }
                File(installDir, "$title.json").writeText(payload.toString(), Charsets.UTF_8)

                val providerId = plugin.optString("internalName", title)
                val installed = ProviderRegistry.isInstalled(context, providerId, title, externalUrl)
                items.add(
                    MovieItem(
                        title = title,
                        posterUrl = iconUrl,
                        streamUrl = externalUrl,
                        description = description,
                        isPlugin = true,
                        repositoryName = repoName,
                        providerId = providerId,
                        isInstalled = installed
                    )
                )
            }
        }
        return items
    }

    private fun parsePluginEntries(jsonText: String): List<JSONObject> {
        val trimmed = jsonText.trim()
        if (trimmed.isEmpty()) return emptyList()

        return try {
            val array = JSONArray(trimmed)
            (0 until array.length()).mapNotNull { index -> array.optJSONObject(index) }
        } catch (_: Exception) {
            val root = JSONObject(trimmed)
            val possibleArrays = listOf("plugins", "pluginList", "pluginLists", "items", "entries")
            val array = possibleArrays.firstNotNullOfOrNull { key ->
                root.optJSONArray(key)
            }
            if (array != null) {
                (0 until array.length()).mapNotNull { index -> array.optJSONObject(index) }
            } else {
                listOf(root).filter { it.length() > 0 }
            }
        }
    }

    /**
     * Downloads a `.cs3` and actually loads it as a real CloudStream plugin (see
     * [com.mahdiridoy.iptvapp.plugins.CloudStreamPluginManager]) - previously this
     * just downloaded the file and recorded its own URL as a fake "stream", which is
     * why nothing played (see MoviesSeriesViewModel's doc comment for the full story).
     */
    suspend fun installPlugin(context: Context, item: MovieItem): Boolean {
        if (!item.isPlugin || item.streamUrl.isBlank()) return false

        val installDir = File(context.filesDir, "cloudstream_plugins/${sanitizeFileName(item.repositoryName ?: "repo")}")
        installDir.mkdirs()

        val outputFile = File(installDir, buildPluginInstallFileName(item.title, item.streamUrl))
        if (!(outputFile.exists() && outputFile.length() > 0L)) {
            val downloaded = try {
                val request = Request.Builder().url(normalizeUrl(item.streamUrl)).build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IOException("Failed to download ${item.title}: HTTP ${response.code}")
                    }
                    response.body?.byteStream()?.use { input ->
                        outputFile.outputStream().use { output -> input.copyTo(output) }
                    }
                }
                outputFile.exists() && outputFile.length() > 0L
            } catch (_: Exception) {
                false
            }
            if (!downloaded) return false
        }

        val loadResult = com.mahdiridoy.iptvapp.plugins.CloudStreamPluginManager.loadPlugin(context, outputFile)
        if (loadResult.isFailure) return false

        com.mahdiridoy.iptvapp.plugins.InstalledPluginStore.addOrUpdate(
            context,
            com.mahdiridoy.iptvapp.plugins.InstalledPlugin(
                name = loadResult.getOrNull()?.name ?: item.title,
                repositoryName = item.repositoryName,
                filePath = outputFile.absolutePath,
                installedAtMs = System.currentTimeMillis()
            )
        )
        return true
    }

    fun isPluginInstalled(context: Context, repoName: String?, title: String, url: String): Boolean {
        val installDir = File(context.filesDir, "cloudstream_plugins/${sanitizeFileName(repoName ?: "repo")}")
        if (!installDir.exists()) return false
        val candidate = File(installDir, buildPluginInstallFileName(title, url))
        return candidate.exists() && candidate.length() > 0L
    }

    fun buildPluginInstallFileName(title: String, url: String): String {
        val extension = URLConnection.guessContentTypeFromName(url.substringAfterLast('/'))
            ?.substringAfterLast('/')
            ?.takeIf { it.isNotBlank() }
            ?: url.substringAfterLast('.', "bin")
        val safeTitle = sanitizeFileName(title)
        return if (extension.isBlank() || extension == "bin") {
            "$safeTitle.cs3"
        } else {
            "$safeTitle.$extension"
        }
    }

    private fun sanitizeFileName(value: String): String {
        return value.trim().lowercase().replace(Regex("[^a-z0-9._-]+"), "_").trim('_').ifBlank { "provider" }
    }

    private fun fetchString(url: String): String {
        val request = Request.Builder().url(normalizeUrl(url)).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Failed to fetch $url: HTTP ${response.code}")
            }
            return response.body?.string() ?: ""
        }
    }

    private fun fetchPackageItems(context: Context, sourceUrl: String, repoName: String): List<MovieItem> {
        val archiveFile = downloadPackage(context, sourceUrl, repoName)
        return readPackageItems(archiveFile, repoName, sourceUrl)
    }

    fun readPackageItems(packageFile: File, repoName: String, sourceUrl: String? = null): List<MovieItem> {
        if (!packageFile.exists() || packageFile.length() <= 0L) return emptyList()
        return runCatching {
            ZipFile(packageFile).use { archive ->
                val manifestEntry = archive.entries().asSequence()
                    .filterNot { it.isDirectory }
                    .firstOrNull { entry ->
                        entry.name.equals("manifest.json", ignoreCase = true) ||
                            entry.name.endsWith("/manifest.json", ignoreCase = true) ||
                            entry.name.contains("manifest", ignoreCase = true)
                    } ?: archive.entries().asSequence()
                    .filterNot { it.isDirectory }
                    .firstOrNull { entry -> entry.name.lowercase().endsWith(".json") }
                    ?: return emptyList()

                archive.getInputStream(manifestEntry).bufferedReader(Charsets.UTF_8).use { reader ->
                    parsePackageManifest(reader.readText(), repoName, sourceUrl ?: packageFile.name)
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun downloadPackage(context: Context, sourceUrl: String, repoName: String): File {
        val archiveName = sourceUrl.substringAfterLast('/').substringBefore('?').takeIf { it.isNotBlank() } ?: "provider.cs3"
        val packageFile = File(context.cacheDir, "repo_packages/${sanitizeFileName(repoName)}/$archiveName")
        packageFile.parentFile?.mkdirs()
        if (packageFile.exists() && packageFile.length() > 0L) return packageFile

        val request = Request.Builder().url(normalizeUrl(sourceUrl)).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Failed to fetch package $sourceUrl: HTTP ${response.code}")
            }
            response.body?.byteStream()?.use { input ->
                packageFile.outputStream().use { output -> input.copyTo(output) }
            }
        }
        return packageFile
    }

    private fun parsePackageManifest(jsonText: String, repoName: String, sourceUrl: String): List<MovieItem> {
        val trimmed = jsonText.trim()
        if (trimmed.isEmpty()) return emptyList()

        return runCatching {
            val root = if (trimmed.startsWith("[")) JSONArray(trimmed) else JSONObject(trimmed)
            val items = mutableListOf<MovieItem>()
            val seenTitles = mutableSetOf<String>()
            collectPackageEntries(root, items, repoName, sourceUrl, seenTitles)
            items
        }.getOrDefault(emptyList())
    }

    private fun collectPackageEntries(
        node: Any?,
        items: MutableList<MovieItem>,
        repoName: String,
        sourceUrl: String,
        seenTitles: MutableSet<String>
    ) {
        when (node) {
            is JSONObject -> {
                val entry = buildPackageEntry(node, repoName, sourceUrl)
                if (entry != null) {
                    val normalizedTitle = entry.title.lowercase()
                    if (normalizedTitle !in seenTitles) {
                        items.add(entry)
                        seenTitles.add(normalizedTitle)
                    }
                }
                val keys = node.keys()
                while (keys.hasNext()) {
                    collectPackageEntries(node.get(keys.next()), items, repoName, sourceUrl, seenTitles)
                }
            }
            is JSONArray -> {
                for (index in 0 until node.length()) {
                    collectPackageEntries(node.get(index), items, repoName, sourceUrl, seenTitles)
                }
            }
        }
    }

    private fun buildPackageEntry(obj: JSONObject, repoName: String, sourceUrl: String): MovieItem? {
        val title = listOf("title", "name")
            .firstNotNullOfOrNull { key -> obj.optString(key).takeIf { it.isNotBlank() } }
            ?: return null

        val streamUrl = listOf("streamUrl", "url", "link", "playUrl", "videoUrl", "source", "file")
            .firstNotNullOfOrNull { key -> obj.optString(key).takeIf { it.isNotBlank() } }
            ?: return null

        val posterUrl = listOf("poster", "posterUrl", "image", "cover", "banner", "icon", "iconUrl")
            .firstNotNullOfOrNull { key -> obj.optString(key).takeIf { it.isNotBlank() } }

        val description = listOf("description", "overview", "plot", "summary")
            .firstNotNullOfOrNull { key -> obj.optString(key).takeIf { it.isNotBlank() } }

        return MovieItem(
            title = title,
            posterUrl = posterUrl,
            streamUrl = streamUrl,
            description = description,
            isPlugin = true,
            repositoryName = repoName,
            providerId = obj.optString("providerId").ifBlank { title },
            isInstalled = false
        ).also {
            if (sourceUrl.isNotBlank()) {
                // Keep the original package source for later inspection if needed.
            }
        }
    }

    private fun looksLikeArchiveUrl(url: String): Boolean {
        val normalized = url.lowercase()
        return normalized.endsWith(".cs3") || normalized.endsWith(".zip") || normalized.endsWith(".jar")
    }

    private fun parseSimpleManifest(json: String): List<MovieItem> {
        val array = JSONArray(json)
        val items = mutableListOf<MovieItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val streamUrl = obj.optString("streamUrl")
            if (streamUrl.isBlank()) continue
            items.add(
                MovieItem(
                    title = obj.optString("title", "Untitled"),
                    posterUrl = obj.optString("poster").ifBlank { null },
                    streamUrl = streamUrl,
                    description = obj.optString("description").ifBlank { null }
                )
            )
        }
        return items
    }
}
