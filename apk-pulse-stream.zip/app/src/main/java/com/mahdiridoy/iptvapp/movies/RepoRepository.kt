package com.mahdiridoy.iptvapp.movies

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.URLConnection

object RepoRepository {
    private const val CLOUDSTREAM_SCHEME = "cloudstreamrepo://"
    private val client = OkHttpClient()

    fun normalizeUrl(rawUrl: String): String {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty() || trimmed.contains("://")) return trimmed
        return if (trimmed.startsWith("raw.githubusercontent.com/") || trimmed.startsWith("github.com/")) {
            "https://$trimmed"
        } else {
            "https://$trimmed"
        }
    }

    @Throws(IOException::class)
    fun fetchItems(context: Context, repo: Repo): List<MovieItem> {
        val manifestUrl = repo.manifestUrl
        return if (manifestUrl.startsWith(CLOUDSTREAM_SCHEME)) {
            fetchCloudStreamPlugins(context, manifestUrl.removePrefix(CLOUDSTREAM_SCHEME), repo.name)
        } else {
            val request = Request.Builder().url(normalizeUrl(manifestUrl)).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Failed to fetch ${repo.name}: HTTP ${response.code}")
                }
                val body = response.body?.string() ?: "[]"
                parseSimpleManifest(body)
            }
        }
    }

    private fun fetchCloudStreamPlugins(context: Context, repoUrl: String, repoName: String): List<MovieItem> {
        val repoJson = fetchString(repoUrl)
        val root = JSONObject(repoJson)
        val pluginLists = root.optJSONArray("pluginLists") ?: JSONArray()
        val installDir = File(context.cacheDir, "cloudstream_plugins/${repoName.replace(Regex("[^A-Za-z0-9._-]+"), "_")}")
        installDir.mkdirs()

        val items = mutableListOf<MovieItem>()
        for (i in 0 until pluginLists.length()) {
            val listUrl = pluginLists.optString(i).takeIf { it.isNotBlank() } ?: continue
            val pluginEntries = parsePluginEntries(fetchString(listUrl))
            for (plugin in pluginEntries) {
                val status = plugin.optInt("status", 1)
                if (status == 0) continue

                val title = plugin.optString("name", "Untitled Plugin").takeIf { it.isNotBlank() } ?: continue
                val description = plugin.optString("description").ifBlank { null }
                val iconUrl = plugin.optString("iconUrl").ifBlank { null }
                val externalUrl = plugin.optString("url").ifBlank { plugin.optString("jarUrl") }
                if (externalUrl.isBlank()) continue

                val tvTypes = plugin.optJSONArray("tvTypes") ?: JSONArray()
                val tvTypeText = buildString {
                    for (index in 0 until tvTypes.length()) {
                        if (index > 0) append('|')
                        append(tvTypes.optString(index))
                    }
                }
                val supportsMovieContent = tvTypeText.isBlank() ||
                    tvTypeText.contains("Movie", ignoreCase = true) ||
                    tvTypeText.contains("TvSeries", ignoreCase = true) ||
                    tvTypeText.contains("AnimeMovie", ignoreCase = true) ||
                    tvTypeText.contains("Anime", ignoreCase = true) ||
                    tvTypeText.contains("Cartoon", ignoreCase = true) ||
                    tvTypeText.contains("All", ignoreCase = true)
                if (!supportsMovieContent) continue

                val payload = JSONObject().apply {
                    put("name", title)
                    put("description", description ?: "CloudStream plugin")
                    put("iconUrl", iconUrl ?: "")
                    put("source", listUrl)
                    put("url", externalUrl)
                }
                File(installDir, "$title.json").writeText(payload.toString(), Charsets.UTF_8)

                val providerId = plugin.optString("internalName", title)
                val installed = ProviderRegistry.isInstalled(context, providerId, title, externalUrl)
                items.add(
                    MovieItem(
                        title = title,
                        posterUrl = iconUrl,
                        streamUrl = externalUrl,
                        description = description,
                        isPlugin = true,
                        repositoryName = repoName,
                        providerId = providerId,
                        isInstalled = installed
                    )
                )
            }
        }
        return items
    }

    private fun parsePluginEntries(jsonText: String): List<JSONObject> {
        val trimmed = jsonText.trim()
        if (trimmed.isEmpty()) return emptyList()

        return try {
            val array = JSONArray(trimmed)
            (0 until array.length()).mapNotNull { index -> array.optJSONObject(index) }
        } catch (_: Exception) {
            val root = JSONObject(trimmed)
            val possibleArrays = listOf("plugins", "pluginList", "pluginLists", "items", "entries")
            val array = possibleArrays.firstNotNullOfOrNull { key ->
                root.optJSONArray(key)
            }
            if (array != null) {
                (0 until array.length()).mapNotNull { index -> array.optJSONObject(index) }
            } else {
                listOf(root).filter { it.length() > 0 }
            }
        }
    }

    fun installPlugin(context: Context, item: MovieItem): Boolean {
        if (!item.isPlugin || item.streamUrl.isBlank()) return false

        val installDir = File(context.filesDir, "cloudstream_plugins/${sanitizeFileName(item.repositoryName ?: "repo")}")
        installDir.mkdirs()

        val outputFile = File(installDir, buildPluginInstallFileName(item.title, item.streamUrl))
        if (outputFile.exists() && outputFile.length() > 0L) {
            writePluginMetadata(context, installDir, item, outputFile)
            return true
        }

        return try {
            val request = Request.Builder().url(normalizeUrl(item.streamUrl)).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Failed to download ${item.title}: HTTP ${response.code}")
                }
                response.body?.byteStream()?.use { input ->
                    outputFile.outputStream().use { output -> input.copyTo(output) }
                }
            }
            writePluginMetadata(context, installDir, item, outputFile)
            outputFile.exists() && outputFile.length() > 0L
        } catch (_: Exception) {
            false
        }
    }

    fun isPluginInstalled(context: Context, repoName: String?, title: String, url: String): Boolean {
        val installDir = File(context.filesDir, "cloudstream_plugins/${sanitizeFileName(repoName ?: "repo")}")
        if (!installDir.exists()) return false
        val candidate = File(installDir, buildPluginInstallFileName(title, url))
        return candidate.exists() && candidate.length() > 0L
    }

    fun buildPluginInstallFileName(title: String, url: String): String {
        val extension = URLConnection.guessContentTypeFromName(url.substringAfterLast('/'))
            ?.substringAfterLast('/')
            ?.takeIf { it.isNotBlank() }
            ?: url.substringAfterLast('.', "bin")
        val safeTitle = sanitizeFileName(title)
        return if (extension.isBlank() || extension == "bin") {
            "$safeTitle.cs3"
        } else {
            "$safeTitle.$extension"
        }
    }

    private fun writePluginMetadata(context: Context, installDir: File, item: MovieItem, outputFile: File) {
        val metadataFile = File(installDir, "${outputFile.nameWithoutExtension}.json")
        val payload = JSONObject().apply {
            put("title", item.title)
            put("providerId", item.providerId ?: item.title)
            put("repository", item.repositoryName ?: "unknown")
            put("downloadUrl", item.streamUrl)
            put("qualities", JSONArray().apply {
                put(JSONObject().apply {
                    put("label", "Default")
                    put("url", item.streamUrl)
                })
            })
            put("installedAt", System.currentTimeMillis())
        }
        metadataFile.writeText(payload.toString(), Charsets.UTF_8)

        ProviderRegistry.addOrUpdate(
            context,
            InstalledProvider(
                id = ProviderRegistry.providerKey(item.title, item.repositoryName, item.providerId),
                title = item.title,
                repositoryName = item.repositoryName,
                providerId = item.providerId,
                packagePath = outputFile.absolutePath,
                downloadUrl = item.streamUrl,
                qualities = listOf(com.mahdiridoy.iptvapp.catalog.Quality("Default", item.streamUrl)),
                installedAtMs = System.currentTimeMillis()
            )
        )
    }

    private fun sanitizeFileName(value: String): String {
        return value.trim().lowercase().replace(Regex("[^a-z0-9._-]+"), "_").trim('_').ifBlank { "provider" }
    }

    private fun fetchString(url: String): String {
        val request = Request.Builder().url(normalizeUrl(url)).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Failed to fetch $url: HTTP ${response.code}")
            }
            return response.body?.string() ?: ""
        }
    }

    private fun parseSimpleManifest(json: String): List<MovieItem> {
        val array = JSONArray(json)
        val items = mutableListOf<MovieItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val streamUrl = obj.optString("streamUrl")
            if (streamUrl.isBlank()) continue
            items.add(
                MovieItem(
                    title = obj.optString("title", "Untitled"),
                    posterUrl = obj.optString("poster").ifBlank { null },
                    streamUrl = streamUrl,
                    description = obj.optString("description").ifBlank { null }
                )
            )
        }
        return items
    }
}
