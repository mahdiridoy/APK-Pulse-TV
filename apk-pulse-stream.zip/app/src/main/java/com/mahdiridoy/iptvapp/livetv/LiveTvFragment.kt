package com.mahdiridoy.iptvapp.livetv

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mahdiridoy.iptvapp.SearchableFragment
import com.mahdiridoy.iptvapp.data.ContentType
import com.mahdiridoy.iptvapp.data.LibraryRepository
import com.mahdiridoy.iptvapp.data.db.FavoriteEntity
import com.mahdiridoy.iptvapp.data.db.HistoryEntity
import com.mahdiridoy.iptvapp.databinding.FragmentLiveTvBinding
import com.mahdiridoy.iptvapp.player.PlaybackQueue
import com.mahdiridoy.iptvapp.player.PlayerActivity
import com.mahdiridoy.iptvapp.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LiveTvFragment : Fragment(), SearchableFragment {

    companion object {
        private const val SWIPE_THRESHOLD_PX = 80
    }

    /**
     * Tracks raw horizontal finger movement and fires once the total distance in
     * [direction] (-1 = leftward, +1 = rightward) crosses [SWIPE_THRESHOLD_PX] - fires
     * immediately as that happens, not on release, so it reacts the moment the swipe
     * is clearly a swipe rather than waiting for a fling-speed release. [onTap] fires
     * on ACTION_UP if the finger barely moved (a tap, not a swipe).
     */
    private class HorizontalSwipeListener(
        private val context: Context,
        private val direction: Int,
        private val onTap: (() -> Unit)? = null,
        private val onSwipe: () -> Unit
    ) : View.OnTouchListener {
        private var startX = 0f
        private var startY = 0f
        private var triggered = false
        private val tapSlopPx = android.view.ViewConfiguration.get(context).scaledTouchSlop

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.x
                    startY = event.y
                    triggered = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (triggered) return true
                    val deltaX = event.x - startX
                    val crossedThreshold = if (direction < 0) deltaX < -SWIPE_THRESHOLD_PX else deltaX > SWIPE_THRESHOLD_PX
                    if (crossedThreshold) {
                        triggered = true
                        onSwipe()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!triggered && onTap != null) {
                        val totalMove = kotlin.math.hypot((event.x - startX).toDouble(), (event.y - startY).toDouble())
                        if (totalMove < tapSlopPx) onTap.invoke()
                    }
                }
            }
            return true
        }
    }

    private var _binding: FragmentLiveTvBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: ChannelAdapter
    private lateinit var searchAdapter: ChannelAdapter
    private var allChannels: List<Channel> = emptyList()
    private var searchVisible = false
    private var favoriteUrls: Set<String> = emptySet()
    private var gridSpanCount = 3
    private var lastGridFocusPosition = RecyclerView.NO_POSITION

    /**
     * Set by PulseAppShell right after this fragment is created, so the grid's own
     * D-pad handling can ask the (Compose-side) drawer to open - the fragment has no
     * direct access to the drawer's state otherwise.
     */
    var onOpenDrawerRequested: (() -> Unit)? = null
    private var initialFocusRequested = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLiveTvBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val repository = LibraryRepository.getInstance(requireContext())

        // Milestone 4/5: queue channels with a stable contentId (their stream URL) so
        // Live TV feeds "recently watched" the same way Movies/Series feed History -
        // no resume position for live streams, just a last-watched timestamp.
        val openPlayer = { list: List<Channel>, index: Int ->
            val channel = list[index]
            PlaybackQueue.setWithDetails(
                titles = list.map { it.name },
                urls = list.map { it.streamUrl },
                startIndex = index,
                contentIds = list.map { it.streamUrl },
                qualityOptions = List(list.size) { emptyList() },
                startPositionMs = 0L
            )
            viewLifecycleOwner.lifecycleScope.launch {
                repository.recordProgress(
                    HistoryEntity(
                        contentId = channel.streamUrl,
                        title = channel.name,
                        posterUrl = channel.logoUrl,
                        type = ContentType.LIVE_TV,
                        streamUrl = channel.streamUrl,
                        positionMs = 0L,
                        durationMs = 0L,
                        lastWatchedAtMs = System.currentTimeMillis()
                    )
                )
            }
            startActivity(Intent(requireContext(), PlayerActivity::class.java))
        }

        val toggleFavorite = { channel: Channel ->
            viewLifecycleOwner.lifecycleScope.launch {
                if (channel.streamUrl in favoriteUrls) {
                    repository.removeFavorite(channel.streamUrl)
                } else {
                    repository.addFavorite(
                        FavoriteEntity(
                            contentId = channel.streamUrl,
                            title = channel.name,
                            posterUrl = channel.logoUrl,
                            type = ContentType.LIVE_TV,
                            streamUrl = channel.streamUrl,
                            addedAtMs = System.currentTimeMillis()
                        )
                    )
                }
            }
            Unit
        }

        adapter = ChannelAdapter(
            emptyList(),
            onClick = { channel ->
                val index = allChannels.indexOf(channel).coerceAtLeast(0)
                openPlayer(allChannels, index)
            },
            onFavoriteClick = toggleFavorite,
            onGridEdgeKey = { position, keyCode ->
                if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    val isRightEdge = (position % gridSpanCount) == gridSpanCount - 1 || position == adapter.itemCount - 1
                    if (isRightEdge) {
                        lastGridFocusPosition = position
                        openSearch()
                        true
                    } else {
                        false
                    }
                } else {
                    val isLeftEdge = (position % gridSpanCount) == 0
                    if (isLeftEdge) {
                        onOpenDrawerRequested?.invoke()
                        true
                    } else {
                        false
                    }
                }
            }
        )

        val spanCount = if (resources.configuration.screenWidthDp > 600) 5 else 3
        gridSpanCount = spanCount
        binding.channelGrid.layoutManager = GridLayoutManager(requireContext(), spanCount)
        binding.channelGrid.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadPlaylist() }

        setupSearch(openPlayer, toggleFavorite)
        observeFavorites(repository)
        loadPlaylist()
    }

    /** Keeps the heart icons on both grids in sync with Room, from any screen that changes them. */
    private fun observeFavorites(repository: LibraryRepository) {
        viewLifecycleOwner.lifecycleScope.launch {
            repository.observeFavorites().collect { favorites ->
                favoriteUrls = favorites.filter { it.type == ContentType.LIVE_TV }.map { it.contentId }.toSet()
                adapter.updateFavorites(favoriteUrls)
                searchAdapter.updateFavorites(favoriteUrls)
            }
        }
    }

    /**
     * Always re-fetches the M3U from your GitHub URL. Since you commit a fresh
     * playlist daily via your Tv pipeline, this keeps the app in sync every
     * time Live TV opens or on pull-to-refresh.
     */
    private fun loadPlaylist() {
        if (_binding == null) return
        binding.swipeRefresh.isRefreshing = true
        val url = Prefs.getPlaylistUrl(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val channels = withContext(Dispatchers.IO) { M3uParser.fetch(url) }
                allChannels = channels
                if (_binding == null) return@launch
                adapter.updateData(channels)
                adapter.updateFavorites(favoriteUrls)
                binding.emptyState.visibility = if (channels.isEmpty()) View.VISIBLE else View.GONE
                // One-time only: on later refreshes, don't yank focus away from wherever
                // the user has since navigated to. Compose's initial D-pad focus tends to
                // land on the top bar's menu icon (the only focusable thing up there),
                // which meant needing right-then-down just to reach the first channel -
                // landing here directly skips that entirely.
                if (!initialFocusRequested && channels.isNotEmpty()) {
                    initialFocusRequested = true
                    binding.channelGrid.post {
                        if (_binding != null) binding.channelGrid.requestFocus()
                    }
                }
            } catch (e: Exception) {
                if (_binding == null) return@launch
                Toast.makeText(
                    requireContext(),
                    "Couldn't load playlist: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                binding.emptyState.visibility = if (allChannels.isEmpty()) View.VISIBLE else View.GONE
            } finally {
                if (_binding != null) {
                    binding.swipeRefresh.isRefreshing = false
                }
            }
        }
    }

    // ---- Channel search: results are channels only, never movies/series ----

    private fun setupSearch(openPlayer: (List<Channel>, Int) -> Unit, toggleFavorite: (Channel) -> Unit) {
        var filtered: List<Channel> = emptyList()
        searchAdapter = ChannelAdapter(
            emptyList(),
            onClick = { channel ->
                val index = filtered.indexOf(channel).coerceAtLeast(0)
                openPlayer(filtered, index)
            },
            onFavoriteClick = toggleFavorite,
            // Single-column list - every item is "the left edge", so plain D-pad left
            // from anywhere in the results closes search, same as from the input/close
            // button. (See ChannelAdapter's onGridEdgeKey doc for why this can't just be
            // a key listener on binding.searchResults itself.)
            onGridEdgeKey = { _, keyCode ->
                if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                    closeSearch()
                    true
                } else {
                    false
                }
            }
        )
        binding.searchResults.layoutManager = LinearLayoutManager(requireContext())
        binding.searchResults.adapter = searchAdapter
        binding.searchClose.setOnClickListener { closeSearch() }

        // Touch: swipe left starting from the thin strip along the right edge opens
        // search, no visible button needed. Tracking raw finger movement (not
        // GestureDetector.onFling) on purpose - onFling only fires once the gesture
        // ends fast enough to count as a "fling", so a normal, deliberate swipe that
        // doesn't reach that velocity threshold was silently doing nothing. Tracking
        // the distance directly as the finger moves reacts to any swipe, fast or slow.
        binding.searchEdgeSwipeZone.setOnTouchListener(
            HorizontalSwipeListener(requireContext(), direction = -1) {
                lastGridFocusPosition = RecyclerView.NO_POSITION
                openSearch()
            }
        )

        // Mirror on the left: swipe right (direction = +1, dragging away from the left
        // edge) opens the nav drawer.
        binding.drawerEdgeSwipeZone.setOnTouchListener(
            HorizontalSwipeListener(requireContext(), direction = 1) {
                onOpenDrawerRequested?.invoke()
            }
        )

        // Touch: tapping the dimmed area outside the panel, or swiping the panel itself
        // back to the right, both close it. Same raw-distance approach, plus a tap
        // (negligible movement) also closes.
        val closeOnSwipeOrTap = HorizontalSwipeListener(requireContext(), direction = 1, onTap = { closeSearch() }) {
            closeSearch()
        }
        binding.searchScrim.setOnTouchListener(closeOnSwipeOrTap)
        binding.searchPanel.setOnTouchListener { view, event ->
            closeOnSwipeOrTap.onTouch(view, event)
            false
        }

        val closeOnDpadLeft = View.OnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                closeSearch()
                true
            } else {
                false
            }
        }
        binding.searchInput.setOnKeyListener(closeOnDpadLeft)
        binding.searchClose.setOnKeyListener(closeOnDpadLeft)

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                val query = s?.toString()?.trim().orEmpty()
                filtered = if (query.isEmpty()) emptyList()
                else allChannels.filter { it.name.contains(query, ignoreCase = true) }
                searchAdapter.updateData(filtered)
                searchAdapter.updateFavorites(favoriteUrls)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun openSearch() {
        if (searchVisible) return
        searchVisible = true
        binding.searchScrim.visibility = View.VISIBLE
        binding.searchPanel.visibility = View.VISIBLE
        binding.searchPanel.animate().translationX(0f).setDuration(200).start()
        // Same bug as the left nav drawer had: the scrim blocks touch but never blocked
        // D-pad focus search, so with nothing focusable further right inside the panel,
        // pressing right again let focus jump straight past the scrim into the channel
        // grid behind it - which looked exactly like the panel "auto-hiding" on a single
        // right press, when really focus (and the input cursor) had just silently left
        // the panel entirely while it stayed visually open behind. Blocking descendant
        // focus on the grid while search is open closes that off completely.
        binding.channelGrid.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        // Posted rather than called immediately: requestFocus() on a view that just went
        // VISIBLE in this same frame can silently fail before layout has caught up.
        binding.searchInput.post { binding.searchInput.requestFocus() }
    }

    override fun closeSearch() {
        if (!searchVisible) return
        searchVisible = false
        binding.searchScrim.visibility = View.GONE
        binding.searchPanel.animate()
            .translationX(binding.searchPanel.width.toFloat())
            .setDuration(200)
            .withEndAction { binding.searchPanel.visibility = View.INVISIBLE }
            .start()
        binding.searchInput.setText("")
        // Restore BEFORE requesting focus back on the grid below - while blocked, the
        // grid can't take focus at all, including this.
        binding.channelGrid.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        // Land back on the exact channel that opened search, same row - not just
        // "somewhere in the grid" - so the remote picks up right where it left off.
        val position = lastGridFocusPosition
        if (position != RecyclerView.NO_POSITION) {
            binding.channelGrid.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus()
                ?: binding.channelGrid.requestFocus()
        } else {
            binding.channelGrid.requestFocus()
        }
    }

    override fun isSearchOpen(): Boolean = searchVisible

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
