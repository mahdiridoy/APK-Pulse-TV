package com.mahdiridoy.iptvapp.livetv

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mahdiridoy.iptvapp.SearchableFragment
import com.mahdiridoy.iptvapp.data.ContentType
import com.mahdiridoy.iptvapp.data.LibraryRepository
import com.mahdiridoy.iptvapp.data.db.FavoriteEntity
import com.mahdiridoy.iptvapp.data.db.HistoryEntity
import com.mahdiridoy.iptvapp.databinding.FragmentLiveTvBinding
import com.mahdiridoy.iptvapp.player.PlaybackQueue
import com.mahdiridoy.iptvapp.player.PlayerActivity
import com.mahdiridoy.iptvapp.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LiveTvFragment : Fragment(), SearchableFragment {

    private var _binding: FragmentLiveTvBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: ChannelAdapter
    private lateinit var searchAdapter: ChannelAdapter
    private var allChannels: List<Channel> = emptyList()
    private var searchVisible = false
    private var favoriteUrls: Set<String> = emptySet()
    private var gridSpanCount = 3
    private var lastGridFocusPosition = RecyclerView.NO_POSITION

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLiveTvBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val repository = LibraryRepository.getInstance(requireContext())

        // Milestone 4/5: queue channels with a stable contentId (their stream URL) so
        // Live TV feeds "recently watched" the same way Movies/Series feed History -
        // no resume position for live streams, just a last-watched timestamp.
        val openPlayer = { list: List<Channel>, index: Int ->
            val channel = list[index]
            PlaybackQueue.setWithDetails(
                titles = list.map { it.name },
                urls = list.map { it.streamUrl },
                startIndex = index,
                contentIds = list.map { it.streamUrl },
                qualityOptions = List(list.size) { emptyList() },
                startPositionMs = 0L
            )
            viewLifecycleOwner.lifecycleScope.launch {
                repository.recordProgress(
                    HistoryEntity(
                        contentId = channel.streamUrl,
                        title = channel.name,
                        posterUrl = channel.logoUrl,
                        type = ContentType.LIVE_TV,
                        streamUrl = channel.streamUrl,
                        positionMs = 0L,
                        durationMs = 0L,
                        lastWatchedAtMs = System.currentTimeMillis()
                    )
                )
            }
            startActivity(Intent(requireContext(), PlayerActivity::class.java))
        }

        val toggleFavorite = { channel: Channel ->
            viewLifecycleOwner.lifecycleScope.launch {
                if (channel.streamUrl in favoriteUrls) {
                    repository.removeFavorite(channel.streamUrl)
                } else {
                    repository.addFavorite(
                        FavoriteEntity(
                            contentId = channel.streamUrl,
                            title = channel.name,
                            posterUrl = channel.logoUrl,
                            type = ContentType.LIVE_TV,
                            streamUrl = channel.streamUrl,
                            addedAtMs = System.currentTimeMillis()
                        )
                    )
                }
            }
            Unit
        }

        adapter = ChannelAdapter(emptyList(), onClick = { channel ->
            val index = allChannels.indexOf(channel).coerceAtLeast(0)
            openPlayer(allChannels, index)
        }, onFavoriteClick = toggleFavorite)

        val spanCount = if (resources.configuration.screenWidthDp > 600) 5 else 3
        gridSpanCount = spanCount
        binding.channelGrid.layoutManager = GridLayoutManager(requireContext(), spanCount)
        binding.channelGrid.adapter = adapter

        // TV remote: reaching the right edge of the grid and pressing right again opens
        // search instead of just doing nothing - no separate "Search" nav entry needed,
        // and no dedicated search button to aim the D-pad at either. Left from inside the
        // search panel does the mirror action: close it and land back on that same channel.
        binding.channelGrid.setOnKeyListener { _, keyCode, event ->
            if (event.action != KeyEvent.ACTION_DOWN || keyCode != KeyEvent.KEYCODE_DPAD_RIGHT) {
                return@setOnKeyListener false
            }
            val focused = binding.channelGrid.focusedChild ?: return@setOnKeyListener false
            val position = binding.channelGrid.getChildAdapterPosition(focused)
            if (position == RecyclerView.NO_POSITION) return@setOnKeyListener false
            val isRightEdge = (position % gridSpanCount) == gridSpanCount - 1 || position == adapter.itemCount - 1
            if (isRightEdge) {
                lastGridFocusPosition = position
                openSearch()
                true
            } else {
                false
            }
        }

        binding.swipeRefresh.setOnRefreshListener { loadPlaylist() }

        setupSearch(openPlayer, toggleFavorite)
        observeFavorites(repository)
        loadPlaylist()
    }

    /** Keeps the heart icons on both grids in sync with Room, from any screen that changes them. */
    private fun observeFavorites(repository: LibraryRepository) {
        viewLifecycleOwner.lifecycleScope.launch {
            repository.observeFavorites().collect { favorites ->
                favoriteUrls = favorites.filter { it.type == ContentType.LIVE_TV }.map { it.contentId }.toSet()
                adapter.updateFavorites(favoriteUrls)
                searchAdapter.updateFavorites(favoriteUrls)
            }
        }
    }

    /**
     * Always re-fetches the M3U from your GitHub URL. Since you commit a fresh
     * playlist daily via your Tv pipeline, this keeps the app in sync every
     * time Live TV opens or on pull-to-refresh.
     */
    private fun loadPlaylist() {
        if (_binding == null) return
        binding.swipeRefresh.isRefreshing = true
        val url = Prefs.getPlaylistUrl(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val channels = withContext(Dispatchers.IO) { M3uParser.fetch(url) }
                allChannels = channels
                if (_binding == null) return@launch
                adapter.updateData(channels)
                adapter.updateFavorites(favoriteUrls)
                binding.emptyState.visibility = if (channels.isEmpty()) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                if (_binding == null) return@launch
                Toast.makeText(
                    requireContext(),
                    "Couldn't load playlist: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                binding.emptyState.visibility = if (allChannels.isEmpty()) View.VISIBLE else View.GONE
            } finally {
                if (_binding != null) {
                    binding.swipeRefresh.isRefreshing = false
                }
            }
        }
    }

    // ---- Channel search: results are channels only, never movies/series ----

    private fun setupSearch(openPlayer: (List<Channel>, Int) -> Unit, toggleFavorite: (Channel) -> Unit) {
        var filtered: List<Channel> = emptyList()
        searchAdapter = ChannelAdapter(emptyList(), onClick = { channel ->
            val index = filtered.indexOf(channel).coerceAtLeast(0)
            openPlayer(filtered, index)
        }, onFavoriteClick = toggleFavorite)
        binding.searchResults.layoutManager = LinearLayoutManager(requireContext())
        binding.searchResults.adapter = searchAdapter
        binding.searchClose.setOnClickListener { closeSearch() }
        binding.searchOpenButton.setOnClickListener {
            lastGridFocusPosition = RecyclerView.NO_POSITION
            openSearch()
        }

        val closeOnDpadLeft = View.OnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                closeSearch()
                true
            } else {
                false
            }
        }
        binding.searchInput.setOnKeyListener(closeOnDpadLeft)
        binding.searchResults.setOnKeyListener(closeOnDpadLeft)
        binding.searchClose.setOnKeyListener(closeOnDpadLeft)

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                val query = s?.toString()?.trim().orEmpty()
                filtered = if (query.isEmpty()) emptyList()
                else allChannels.filter { it.name.contains(query, ignoreCase = true) }
                searchAdapter.updateData(filtered)
                searchAdapter.updateFavorites(favoriteUrls)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun openSearch() {
        if (searchVisible) return
        searchVisible = true
        binding.searchPanel.visibility = View.VISIBLE
        binding.searchPanel.animate().translationX(0f).setDuration(200).start()
        binding.searchInput.requestFocus()
    }

    override fun closeSearch() {
        if (!searchVisible) return
        searchVisible = false
        binding.searchPanel.animate()
            .translationX(binding.searchPanel.width.toFloat())
            .setDuration(200)
            .withEndAction { binding.searchPanel.visibility = View.INVISIBLE }
            .start()
        binding.searchInput.setText("")
        // Land back on the exact channel that opened search, same row - not just
        // "somewhere in the grid" - so the remote picks up right where it left off.
        val position = lastGridFocusPosition
        if (position != RecyclerView.NO_POSITION) {
            binding.channelGrid.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus()
                ?: binding.channelGrid.requestFocus()
        } else {
            binding.channelGrid.requestFocus()
        }
    }

    override fun isSearchOpen(): Boolean = searchVisible

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
