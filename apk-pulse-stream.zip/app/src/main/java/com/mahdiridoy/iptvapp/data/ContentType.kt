package com.mahdiridoy.iptvapp.data

/**
 * What kind of content a favorite/history/resume entry points at. Stored as its
 * [name] string in Room (see [com.mahdiridoy.iptvapp.data.db.Converters]) so the
 * enum can gain new cases without a schema migration.
 */
enum class ContentType {
    LIVE_TV,
    MOVIE,
    SERIES,
    EPISODE
}
