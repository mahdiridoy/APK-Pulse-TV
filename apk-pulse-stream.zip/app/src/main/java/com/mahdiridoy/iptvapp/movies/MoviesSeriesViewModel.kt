package com.mahdiridoy.iptvapp.movies

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Loads the Movies & Series view directly from the configured repo manifests instead
 * of the older Room/M3U catalog path. The UI can still search/filter the list locally.
 */
class MoviesSeriesViewModel(application: Application) : AndroidViewModel(application) {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _repoItems = MutableStateFlow<List<MovieItem>>(emptyList())
    val repoItems: StateFlow<List<MovieItem>> = _repoItems.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        loadRepoItems()
    }

    fun setQuery(value: String) {
        _query.value = value
    }

    fun refreshFromNetwork() {
        loadRepoItems()
    }

    fun loadRepoItems() {
        viewModelScope.launch {
            _isLoading.value = true
            val items = withContext(Dispatchers.IO) {
                RepoRegistry.repos.flatMap { repo ->
                    runCatching { RepoRepository.fetchItems(getApplication(), repo) }.getOrDefault(emptyList())
                }
            }
            _repoItems.value = items
            _isLoading.value = false
        }
    }
}
