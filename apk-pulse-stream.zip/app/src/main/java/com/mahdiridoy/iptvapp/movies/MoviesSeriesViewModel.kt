package com.mahdiridoy.iptvapp.movies

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.mahdiridoy.iptvapp.catalog.CatalogSyncManager
import com.mahdiridoy.iptvapp.catalog.db.BrowseTileRow
import com.mahdiridoy.iptvapp.catalog.db.CatalogDatabase
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch

/**
 * Pages [BrowseTileRow]s straight out of Room - see [com.mahdiridoy.iptvapp.catalog.db.CatalogDao].
 * Nothing here ever loads the whole catalog into a List; Paging3 only ever keeps a
 * handful of pages in memory regardless of whether the table has 100 rows or 130,000.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class MoviesSeriesViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = CatalogDatabase.getInstance(application).catalogDao()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    fun setQuery(value: String) {
        _query.value = value
    }

    /** Re-syncs from the network (bypassing the "unchanged since last time" ETag check) - pull-to-refresh. */
    fun refreshFromNetwork() {
        viewModelScope.launch {
            CatalogSyncManager.sync(getApplication(), forceRefresh = true)
            // Room's PagingSource auto-invalidates as rows change during the sync
            // itself: this call isn't what makes new content appear, it's just
            // ensuring the grid's scroll position resets to a clean reload once the
            // sync call above returns, matching what a manual pull-to-refresh implies.
        }
    }

    val pagedTiles: Flow<PagingData<BrowseTileRow>> = _query
        .debounce(300)
        .distinctUntilChanged()
        .flatMapLatest { q ->
            Pager(
                config = PagingConfig(pageSize = 40, enablePlaceholders = false, prefetchDistance = 20),
                pagingSourceFactory = {
                    if (q.isBlank()) dao.pagingSource() else dao.searchPagingSource(q.trim())
                }
            ).flow
        }
        .cachedIn(viewModelScope)
}
