package com.mahdiridoy.iptvapp.movies

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.mahdiridoy.iptvapp.catalog.CatalogSyncManager
import com.mahdiridoy.iptvapp.catalog.db.BrowseTileRow
import com.mahdiridoy.iptvapp.catalog.db.CatalogDatabase
import com.mahdiridoy.iptvapp.plugins.CloudStreamBridge
import com.mahdiridoy.iptvapp.plugins.CloudStreamPluginManager
import com.mahdiridoy.iptvapp.plugins.PluginSearchResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch

/**
 * Movies & Series, paged straight out of Room (see [CatalogDatabase]/[CatalogSyncManager])
 * instead of held as one in-memory list - a 130k+ row catalog stays instant to open and
 * to search this way. [CatalogSyncManager.sync] itself runs from [com.mahdiridoy.iptvapp.splash.SplashActivity]
 * on every launch (conditional GET, so it's a no-op unless the remote M3U actually
 * changed); [refreshFromNetwork] here just lets pull-to-refresh force an immediate
 * re-check instead of waiting for the next app launch.
 *
 * This grid itself is deliberately NOT sourced from [RepoRegistry]/[RepoRepository] -
 * a `.cs3` is compiled CloudStream plugin bytecode, not a static movie list, so there's
 * no fixed catalog to page through the way there is for the M3U-backed Room table.
 * Search additionally queries any real, installed CloudStream plugin live (see
 * [pluginResults]/[CloudStreamPluginManager]/[CloudStreamBridge]) and merges its hits
 * in alongside the Room results.
 */
class MoviesSeriesViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = CatalogDatabase.getInstance(application).catalogDao()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _pluginResults = MutableStateFlow<List<PluginSearchResult>>(emptyList())
    val pluginResults: StateFlow<List<PluginSearchResult>> = _pluginResults.asStateFlow()

    val pagedItems: Flow<PagingData<BrowseTileRow>> = _query
        .debounce(300)
        .distinctUntilChanged()
        .flatMapLatest { q ->
            Pager(
                config = PagingConfig(pageSize = 40, enablePlaceholders = false),
                pagingSourceFactory = {
                    if (q.isBlank()) dao.pagingSource() else dao.searchPagingSource(q.trim())
                }
            ).flow
        }
        .cachedIn(viewModelScope)

    init {
        viewModelScope.launch {
            _query.debounce(300).distinctUntilChanged().collect { q ->
                _pluginResults.value = if (q.isBlank() || !CloudStreamPluginManager.isLoaded) {
                    emptyList()
                } else {
                    runCatching { CloudStreamBridge.search(q.trim()) }.getOrDefault(emptyList())
                }
            }
        }
    }

    fun setQuery(value: String) {
        _query.value = value
    }

    fun refreshFromNetwork() {
        viewModelScope.launch {
            _isSyncing.value = true
            runCatching { CatalogSyncManager.sync(getApplication(), forceRefresh = true) }
            _isSyncing.value = false
        }
    }
}
