package com.mahdiridoy.iptvapp.core.nav

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.fragment.compose.AndroidFragment
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import android.content.Intent
import com.mahdiridoy.iptvapp.R
import com.mahdiridoy.iptvapp.catalog.ContentSummary
import com.mahdiridoy.iptvapp.data.ContentType
import com.mahdiridoy.iptvapp.data.db.FavoriteEntity
import com.mahdiridoy.iptvapp.data.db.HistoryEntity
import com.mahdiridoy.iptvapp.favorites.FavoritesScreen
import com.mahdiridoy.iptvapp.history.HistoryScreen
import com.mahdiridoy.iptvapp.home.HomeScreen
import com.mahdiridoy.iptvapp.livetv.LiveTvFragment
import com.mahdiridoy.iptvapp.movies.MovieDetailScreen
import com.mahdiridoy.iptvapp.movies.MoviesSeriesScreen
import com.mahdiridoy.iptvapp.movies.MoviesViewModel
import com.mahdiridoy.iptvapp.player.PlaybackQueue
import com.mahdiridoy.iptvapp.player.PlayerActivity
import com.mahdiridoy.iptvapp.series.SeriesDetailScreen
import com.mahdiridoy.iptvapp.series.SeriesViewModel
import com.mahdiridoy.iptvapp.settings.SettingsScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Info needed to show the "update available" dialog, mirroring the old AlertDialog. */
data class UpdateDialogState(val versionLabel: String, val apkUrl: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PulseAppShell(
    updateDialogState: UpdateDialogState?,
    onUpdateNow: (apkUrl: String) -> Unit,
    onDismissUpdate: () -> Unit,
    onOpenTelegram: () -> Unit
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    // TV/D-pad fix: ModalNavigationDrawer's scrim only blocks touch, not D-pad focus
    // traversal - with nothing else stopping it, pressing DPAD_RIGHT (or DOWN/UP) from
    // the drawer used to let focus "leak" through to whatever channel was last focused
    // in the Live TV grid behind it, which visibly marked that channel and closed the
    // drawer at the same time (focus landing on the background content deactivates the
    // drawer). Two-part fix: (1) give the drawer's first item a FocusRequester and grab
    // focus the moment the drawer opens, so D-pad input actually starts inside it, and
    // (2) swallow every key event over the Scaffold content below while the drawer is
    // open, so D-pad presses can never reach the hidden grid until the drawer closes.
    val firstDrawerItemFocusRequester = remember { FocusRequester() }
    LaunchedEffect(drawerState.isOpen) {
        if (drawerState.isOpen) {
            // One attempt only, after a short settle delay - not a repeat loop. Repeating
            // requestFocus() over a window used to keep yanking focus back to item 0 even
            // after the user had already moved away with the D-pad, which looked exactly
            // like navigation/selection inside the drawer being broken. A brief delay
            // before the single attempt still covers the drawer sheet's first item not
            // having finished composing/attaching the instant the drawer opens, without
            // ever fighting input the user has already made.
            delay(50)
            firstDrawerItemFocusRequester.requestFocus()
        }
    }

    // Deferred from Milestone 1: BACK should close an open Live TV search panel before
    // doing anything else. The Fragment's search-open flag isn't Compose-observable state,
    // so this stays enabled always and checks it fresh on every actual back press instead
    // of trying to track it reactively - that's simpler and can't drift out of sync.
    var liveTvFragmentRef by remember { mutableStateOf<LiveTvFragment?>(null) }

    BackHandler(enabled = true) {
        val fragment = liveTvFragmentRef
        if (drawerState.isOpen) {
            // This was missing entirely - back never closed the drawer, it fell straight
            // through to popping the nav backstack (or exiting the app) instead, which is
            // exactly what would look and feel like the drawer being stuck open, especially
            // on a TV remote where back is the natural, expected way to dismiss any overlay.
            scope.launch { drawerState.close() }
        } else if (currentRoute == PulseDestination.LIVE_TV.route && fragment?.isSearchOpen() == true) {
            fragment.closeSearch()
        } else if (navController.previousBackStackEntry != null) {
            navController.popBackStack()
        } else {
            (context as? android.app.Activity)?.finish()
        }
    }

    // Created once here (not per nav entry) so a detail route reached directly from
    // Home - without visiting the Movies/Series screen first - can still look the
    // item up; scoping to a back-stack entry that may not exist yet would crash.
    val moviesViewModel: MoviesViewModel = viewModel()
    val seriesViewModel: SeriesViewModel = viewModel()

    // Shared by Home's Continue Watching row and the History screen - both just have a
    // HistoryEntity in hand (streamUrl + saved position), nothing left to look up.
    val resumeHistoryEntry: (HistoryEntity) -> Unit = { entry ->
        PlaybackQueue.setWithDetails(
            titles = listOf(entry.title),
            urls = listOf(entry.streamUrl),
            startIndex = 0,
            contentIds = listOf(entry.contentId),
            qualityOptions = listOf(emptyList()),
            startPositionMs = entry.positionMs
        )
        context.startActivity(Intent(context, PlayerActivity::class.java))
    }

    // Favorites screen: Live TV plays immediately; Movies/Series open their details page
    // (so quality selection / episode picking is still available, unlike a direct resume).
    val openFavorite: (FavoriteEntity) -> Unit = { favorite ->
        when (favorite.type) {
            ContentType.LIVE_TV -> {
                PlaybackQueue.setWithDetails(
                    titles = listOf(favorite.title),
                    urls = listOf(favorite.streamUrl),
                    startIndex = 0,
                    contentIds = listOf(favorite.contentId),
                    qualityOptions = listOf(emptyList()),
                    startPositionMs = 0L
                )
                context.startActivity(Intent(context, PlayerActivity::class.java))
            }
            ContentType.SERIES -> navController.navigate("series_detail/${favorite.contentId}")
            ContentType.MOVIE, ContentType.EPISODE -> navController.navigate("movie_detail/${favorite.contentId}")
        }
    }

    // History screen: a Live TV row has no meaningful saved position (it's live), so it
    // just plays now; Movies/Episodes resume from where they left off.
    val openHistoryEntry: (HistoryEntity) -> Unit = { entry ->
        if (entry.type == ContentType.LIVE_TV) {
            PlaybackQueue.setWithDetails(
                titles = listOf(entry.title),
                urls = listOf(entry.streamUrl),
                startIndex = 0,
                contentIds = listOf(entry.contentId),
                qualityOptions = listOf(emptyList()),
                startPositionMs = 0L
            )
            context.startActivity(Intent(context, PlayerActivity::class.java))
        } else {
            resumeHistoryEntry(entry)
        }
    }

    val density = LocalDensity.current
    val swipeThresholdPx = with(density) { 48.dp.toPx() }

    ModalNavigationDrawer(
        drawerState = drawerState,
        // Compose's built-in gesturesEnabled is all-or-nothing and, when true, its drag
        // detector spans the ENTIRE content width even while closed - competing with (and
        // beating) Live TV's own right-edge swipe-to-open-search no matter which way this
        // was set. Disabled permanently; both directions are handled manually below with
        // the same raw-distance approach already proven for Live TV's swipe (not a fling
        // velocity check, which routinely missed normal deliberate swipes).
        gesturesEnabled = false,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.pointerInput(Unit) {
                    var totalDrag = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { totalDrag = 0f },
                        onHorizontalDrag = { _, dragAmount ->
                            totalDrag += dragAmount
                            if (totalDrag < -swipeThresholdPx) {
                                scope.launch { drawerState.close() }
                            }
                        }
                    )
                }
            ) {
                Text(
                    stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(16.dp)
                )
                HorizontalDivider()
                LazyColumn(
                    // Single-column list: D-pad right from anywhere in it means "leave
                    // the drawer" - close it, same as tapping outside or swiping it away.
                    modifier = Modifier.onKeyEvent { keyEvent ->
                        if (keyEvent.type == KeyEventType.KeyDown && keyEvent.key == Key.DirectionRight) {
                            scope.launch { drawerState.close() }
                            true
                        } else {
                            false
                        }
                    }
                ) {
                    itemsIndexed(PulseDestination.entries) { index, destination ->
                        NavigationDrawerItem(
                            icon = { Icon(destination.icon, contentDescription = destination.label) },
                            label = { Text(destination.label) },
                            selected = currentRoute == destination.route,
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(destination.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            modifier = Modifier
                                .padding(horizontal = 8.dp)
                                .let { base ->
                                    if (index == 0) base.focusRequester(firstDrawerItemFocusRequester) else base
                                }
                        )
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                Text(
                    stringResource(R.string.nav_credit),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                )
                TextButton(onClick = onOpenTelegram, modifier = Modifier.padding(horizontal = 8.dp)) {
                    Text("Open Telegram channel")
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            PulseDestination.entries.firstOrNull { it.route == currentRoute }?.label
                                ?: stringResource(R.string.app_name)
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Open menu")
                        }
                    }
                )
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = PulseDestination.LIVE_TV.route,
                modifier = Modifier
                    .padding(padding)
                    // Swallow every key event here while the drawer is open so a D-pad
                    // press can't reach the Live TV grid (or anything else) underneath -
                    // see the comment above firstDrawerItemFocusRequester for why that
                    // mattered (it used to mark a channel and close the drawer at once).
                    .onPreviewKeyEvent { drawerState.isOpen }
            ) {
                composable(PulseDestination.HOME.route) {
                    HomeScreen(
                        onItemClick = { summary ->
                            val route = if (summary.type == ContentType.SERIES) "series_detail" else "movie_detail"
                            navController.navigate("$route/${summary.id}")
                        },
                        onResumeClick = resumeHistoryEntry
                    )
                }
                composable(PulseDestination.LIVE_TV.route) {
                    AndroidFragment<LiveTvFragment>(
                        modifier = Modifier.fillMaxSize(),
                        onUpdate = { fragment ->
                            liveTvFragmentRef = fragment
                            fragment.onOpenDrawerRequested = { scope.launch { drawerState.open() } }
                        }
                    )
                }
                composable(PulseDestination.MOVIES.route) {
                    MoviesSeriesScreen(
                        onOpenDrawerRequested = { scope.launch { drawerState.open() } },
                        onPlay = { items, startIndex ->
                            scope.launch {
                                val playing = items[startIndex]
                                val resumeMs = com.mahdiridoy.iptvapp.data.LibraryRepository
                                    .getInstance(context).getHistoryEntry(playing.summary.id)?.positionMs ?: 0L
                                com.mahdiridoy.iptvapp.data.LibraryRepository.getInstance(context).recordProgress(
                                    com.mahdiridoy.iptvapp.data.db.HistoryEntity(
                                        contentId = playing.summary.id,
                                        title = playing.summary.title,
                                        posterUrl = playing.summary.posterUrl,
                                        type = ContentType.MOVIE,
                                        streamUrl = playing.streamUrl,
                                        positionMs = resumeMs,
                                        durationMs = 0L,
                                        lastWatchedAtMs = System.currentTimeMillis()
                                    )
                                )
                                PlaybackQueue.setWithDetails(
                                    titles = items.map { it.summary.title },
                                    urls = items.map { it.streamUrl },
                                    startIndex = startIndex,
                                    contentIds = items.map { it.summary.id },
                                    qualityOptions = items.map { emptyList() },
                                    startPositionMs = resumeMs
                                )
                                context.startActivity(Intent(context, PlayerActivity::class.java))
                            }
                        }
                    )
                }
                composable(
                    "movie_detail/{id}",
                    arguments = listOf(navArgument("id") { type = NavType.StringType })
                ) { entry ->
                    val movieId = entry.arguments?.getString("id")
                    MovieDetailScreen(
                        detail = movieId?.let { moviesViewModel.findById(it) },
                        onPlay = { title, contentId, url, qualities ->
                            scope.launch {
                                val resumeMs = com.mahdiridoy.iptvapp.data.LibraryRepository
                                    .getInstance(context).getHistoryEntry(contentId)?.positionMs ?: 0L
                                PlaybackQueue.setWithDetails(
                                    titles = listOf(title),
                                    urls = listOf(url),
                                    startIndex = 0,
                                    contentIds = listOf(contentId),
                                    qualityOptions = listOf(qualities),
                                    startPositionMs = resumeMs
                                )
                                context.startActivity(Intent(context, PlayerActivity::class.java))
                            }
                        }
                    )
                }
                composable(
                    "series_detail/{id}",
                    arguments = listOf(navArgument("id") { type = NavType.StringType })
                ) { entry ->
                    val seriesId = entry.arguments?.getString("id")
                    SeriesDetailScreen(
                        detail = seriesId?.let { seriesViewModel.findById(it) },
                        onPlaySeason = { titles, contentIds, urls, qualityOptions, startIndex ->
                            scope.launch {
                                val startContentId = contentIds.getOrNull(startIndex)
                                val resumeMs = startContentId?.let {
                                    com.mahdiridoy.iptvapp.data.LibraryRepository
                                        .getInstance(context).getHistoryEntry(it)?.positionMs
                                } ?: 0L
                                PlaybackQueue.setWithDetails(
                                    titles = titles,
                                    urls = urls,
                                    startIndex = startIndex,
                                    contentIds = contentIds,
                                    qualityOptions = qualityOptions,
                                    startPositionMs = resumeMs
                                )
                                context.startActivity(Intent(context, PlayerActivity::class.java))
                            }
                        }
                    )
                }
                composable(PulseDestination.FAVORITES.route) {
                    FavoritesScreen(onFavoriteClick = openFavorite)
                }
                composable(PulseDestination.HISTORY.route) {
                    HistoryScreen(onHistoryClick = openHistoryEntry)
                }
                composable(PulseDestination.SETTINGS.route) { SettingsScreen() }
            }
        }
    }

    if (updateDialogState != null) {
        // Force update: no "Later" button, no tap-outside-to-dismiss, no back-press
        // dismiss - a new release means the app is unusable until the user updates.
        AlertDialog(
            onDismissRequest = { /* not dismissable - update is mandatory */ },
            properties = DialogProperties(
                dismissOnBackPress = false,
                dismissOnClickOutside = false
            ),
            title = { Text(stringResource(R.string.update_available_title)) },
            text = {
                Text(
                    stringResource(R.string.update_available_message) +
                        " (${updateDialogState.versionLabel})"
                )
            },
            confirmButton = {
                TextButton(onClick = { onUpdateNow(updateDialogState.apkUrl) }) {
                    Text(stringResource(R.string.update_now))
                }
            }
        )
    }
}
