package com.mahdiridoy.iptvapp

import android.app.Application
import com.mahdiridoy.iptvapp.crash.CrashHandler
import com.squareup.picasso.OkHttp3Downloader
import com.squareup.picasso.Picasso
import okhttp3.OkHttpClient

class IPTVApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler(CrashHandler(this))
        installPicasso()
    }

    /**
     * Many free IPTV logo CDNs hotlink-protect: a request with no User-Agent (Picasso's
     * default OkHttp client sends none) gets silently rejected, so Picasso falls back to
     * the placeholder for most channels - this is why logos looked "not loading" even
     * though the URLs themselves were fine. Sending a normal browser User-Agent on every
     * image request fixes that. Installed once here so every Picasso.get() call in the
     * app (ChannelAdapter, MovieItemAdapter) picks it up automatically.
     */
    private fun installPicasso() {
        val client = OkHttpClient.Builder()
            .addNetworkInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header(
                        "User-Agent",
                        "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) " +
                            "Chrome/124.0.0.0 Mobile Safari/537.36"
                    )
                    .build()
                chain.proceed(request)
            }
            .build()
        try {
            Picasso.setSingletonInstance(
                Picasso.Builder(this)
                    .downloader(OkHttp3Downloader(client))
                    .build()
            )
        } catch (e: IllegalStateException) {
            // setSingletonInstance() throws if something already asked for Picasso.get()
            // before this ran - shouldn't happen since this is the first thing Application
            // does, but never worth crashing the app over.
        }
    }
}
