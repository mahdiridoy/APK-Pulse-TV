package com.mahdiridoy.iptvapp

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.GifDecoder
import coil.decode.SvgDecoder
import com.mahdiridoy.iptvapp.crash.CrashHandler
import okhttp3.OkHttpClient

class IPTVApplication : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler(CrashHandler(this))
    }

    /**
     * Logo URLs coming out of a free M3U playlist are a grab bag: PNG, JPEG, WEBP, and a
     * fair number of SVG (which Android's own BitmapFactory can't decode at all - that
     * was silently failing every SVG logo no matter what headers were sent) plus the odd
     * animated GIF. Coil with the SVG/GIF decoders registered here handles all of them
     * through one path, used by both ChannelAdapter and MovieItemAdapter. The custom
     * OkHttpClient keeps the same browser User-Agent used for the actual video streams -
     * without it, most of these CDNs hotlink-block the request before it ever decodes
     * anything, image type or not.
     */
    override fun newImageLoader(): ImageLoader {
        val client = OkHttpClient.Builder()
            .addNetworkInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header(
                        "User-Agent",
                        "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) " +
                            "Chrome/124.0.0.0 Mobile Safari/537.36"
                    )
                    .build()
                chain.proceed(request)
            }
            .build()
        return ImageLoader.Builder(this)
            .okHttpClient(client)
            .components {
                add(SvgDecoder.Factory())
                add(GifDecoder.Factory())
            }
            .build()
    }
}
