package com.mahdiridoy.iptvapp.catalog

import com.mahdiridoy.iptvapp.data.ContentType

/** One selectable stream option for a movie or episode (e.g. "1080p", "720p").
 * [headers] carries any Referer/User-Agent a specific link needs to actually play -
 * mainly populated for CloudStream-plugin-sourced links (see CloudStreamBridge),
 * empty for M3U-catalog links which don't need per-item headers. */
data class Quality(
    val label: String,
    val url: String,
    val headers: Map<String, String> = emptyMap()
)

/**
 * The poster-card-sized fields shared by a movie and a series - what a
 * category row/grid needs to render before anything else is loaded.
 */
data class ContentSummary(
    val id: String,
    val title: String,
    val posterUrl: String?,
    val backdropUrl: String?,
    val description: String?,
    val year: Int?,
    val type: ContentType
)

/**
 * Full detail for a single movie: its summary plus playable quality options.
 * Manifests are a single static JSON file (GitHub raw, same hosting pattern as
 * the M3U pipeline), so this is fully populated straight from the category
 * fetch - no separate per-title detail request.
 */
data class MovieDetail(
    val summary: ContentSummary,
    val qualities: List<Quality>
)

data class Episode(
    val id: String,
    val episodeNumber: Int,
    val title: String,
    val description: String?,
    val posterUrl: String?,
    val qualities: List<Quality>
)

data class Season(
    val seasonNumber: Int,
    val episodes: List<Episode>
)

/** Full detail for a series: its summary plus every season/episode. */
data class SeriesDetail(
    val summary: ContentSummary,
    val seasons: List<Season>
)

/** A named row/section of movies within a Movies manifest, e.g. "Action". */
data class MovieCategory(
    val name: String,
    val items: List<MovieDetail>
)

/** A named row/section of series within a Series manifest, e.g. "Drama". */
data class SeriesCategory(
    val name: String,
    val items: List<SeriesDetail>
)

/** A manifest source, tagged with which section (Movies or Series) it feeds. */
data class ContentRepo(
    val name: String,
    val manifestUrl: String,
    val type: ContentType
)
