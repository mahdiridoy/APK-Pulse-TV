package com.mahdiridoy.iptvapp.series

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mahdiridoy.iptvapp.catalog.CatalogRepository
import com.mahdiridoy.iptvapp.catalog.SeriesCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface SeriesUiState {
    data object Loading : SeriesUiState
    data class Loaded(val categories: List<SeriesCategory>) : SeriesUiState
    data class Error(val message: String) : SeriesUiState
}

/**
 * Milestone 2: fetches and parses the real Series manifests (seasons/episodes
 * included). Deliberately not wired to a polished grid/details UI yet
 * (Milestone 3) - [SeriesUiState] only needs to prove the data layer works.
 */
class SeriesViewModel : ViewModel() {

    private val _uiState = MutableStateFlow<SeriesUiState>(SeriesUiState.Loading)
    val uiState: StateFlow<SeriesUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        _uiState.value = SeriesUiState.Loading
        viewModelScope.launch {
            _uiState.value = runCatching { CatalogRepository.fetchAllSeriesCategories() }
                .fold(
                    onSuccess = { SeriesUiState.Loaded(it) },
                    onFailure = { SeriesUiState.Error(it.message ?: "Failed to load series") }
                )
        }
    }

    /** Looks up a single series from whatever's already loaded - no separate network call. */
    fun findById(id: String): com.mahdiridoy.iptvapp.catalog.SeriesDetail? {
        val loaded = _uiState.value as? SeriesUiState.Loaded ?: return null
        return loaded.categories.flatMap { it.items }.firstOrNull { it.summary.id == id }
    }
}
