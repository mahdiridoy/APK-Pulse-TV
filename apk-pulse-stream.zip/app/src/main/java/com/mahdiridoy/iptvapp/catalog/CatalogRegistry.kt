package com.mahdiridoy.iptvapp.catalog

import com.mahdiridoy.iptvapp.data.ContentType

/**
 * Built-in, non-editable-by-user list of Movies & Series repositories.
 * Add your own repo manifest URLs here - no in-app "add repo" UI by design.
 *
 * Replaces [com.mahdiridoy.iptvapp.movies.RepoRegistry] (kept, unused, for
 * reference) now that manifests carry categories and, for series, seasons/
 * episodes - see [CatalogRepository] for the expected JSON shape.
 */
object CatalogRegistry {
    val repos: List<ContentRepo> = listOf(
        ContentRepo(
            name = "Sample Movies Repo",
            manifestUrl = "https://raw.githubusercontent.com/mahdiridoy/movie-repos/main/movies.json",
            type = ContentType.MOVIE
        ),
        ContentRepo(
            name = "Sample Series Repo",
            manifestUrl = "https://raw.githubusercontent.com/mahdiridoy/movie-repos/main/series.json",
            type = ContentType.SERIES
        )
        // Add more repos here, same pattern.
    )

    fun movieRepos(): List<ContentRepo> = repos.filter { it.type == ContentType.MOVIE }
    fun seriesRepos(): List<ContentRepo> = repos.filter { it.type == ContentType.SERIES }
}
