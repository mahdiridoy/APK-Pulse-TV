package com.mahdiridoy.iptvapp.catalog

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

private val posterWidth = 120.dp

/** A single poster-sized tile for a movie or series, used in [CategoryShelf] and grids. */
@Composable
fun PosterCard(summary: ContentSummary, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .width(posterWidth)
            .clickable(onClick = onClick)
    ) {
        if (summary.posterUrl != null) {
            AsyncImage(
                model = summary.posterUrl,
                contentDescription = summary.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(posterWidth)
                    .clip(RoundedCornerShape(8.dp))
            )
        } else {
            Box(
                modifier = Modifier
                    .width(posterWidth)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    summary.title,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.width(posterWidth - 16.dp)
                )
            }
        }
    }
}

/** A horizontally-scrolling shelf of posters under a category name - the Netflix-style "row". */
@Composable
fun CategoryShelf(
    name: String,
    items: List<ContentSummary>,
    onItemClick: (ContentSummary) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            name,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp)
        ) {
            items(items, key = { it.id }) { item ->
                PosterCard(summary = item, onClick = { onItemClick(item) })
            }
        }
    }
}
