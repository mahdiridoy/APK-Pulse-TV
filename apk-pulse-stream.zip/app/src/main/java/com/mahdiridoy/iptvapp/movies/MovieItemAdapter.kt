package com.mahdiridoy.iptvapp.movies

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.mahdiridoy.iptvapp.R
import com.mahdiridoy.iptvapp.databinding.ItemChannelBinding

class MovieItemAdapter(
    private var items: List<MovieItem>,
    private val onClick: (MovieItem) -> Unit
) : RecyclerView.Adapter<MovieItemAdapter.MovieViewHolder>() {

    inner class MovieViewHolder(val binding: ItemChannelBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val binding = ItemChannelBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return MovieViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val item = items[position]
        holder.binding.channelName.text = item.title
        if (!item.posterUrl.isNullOrBlank()) {
            holder.binding.channelLogo.load(item.posterUrl) {
                placeholder(R.drawable.ic_channel_placeholder)
                error(R.drawable.ic_channel_placeholder)
            }
        } else {
            holder.binding.channelLogo.setImageResource(R.drawable.ic_channel_placeholder)
        }

        val card = holder.binding.root
        card.isFocusable = true
        card.setOnClickListener { onClick(item) }
        card.setOnFocusChangeListener { view, hasFocus ->
            view.animate().scaleX(if (hasFocus) 1.1f else 1f)
                .scaleY(if (hasFocus) 1.1f else 1f)
                .setDuration(150)
                .start()
            holder.binding.focusBorder.visibility = if (hasFocus) View.VISIBLE else View.INVISIBLE
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<MovieItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
