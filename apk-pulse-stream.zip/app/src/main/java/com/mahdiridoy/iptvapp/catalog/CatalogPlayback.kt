package com.mahdiridoy.iptvapp.catalog

import android.content.Context
import android.content.Intent
import com.mahdiridoy.iptvapp.catalog.db.CatalogDatabase
import com.mahdiridoy.iptvapp.data.ContentType
import com.mahdiridoy.iptvapp.data.LibraryRepository
import com.mahdiridoy.iptvapp.data.db.HistoryEntity
import com.mahdiridoy.iptvapp.movies.ProviderRegistry
import com.mahdiridoy.iptvapp.movies.RepoRepository
import com.mahdiridoy.iptvapp.player.PlaybackQueue
import com.mahdiridoy.iptvapp.player.PlayerActivity

/**
 * Plays a catalog item straight from Room, from anywhere it can be tapped (the Movies
 * & Series grid, Home's featured row, or a Favorites/History entry) - one shared path
 * instead of duplicating this per screen. A movie plays alone; a series looks up every
 * episode for [title] (used as the show's grouping key throughout - see
 * [CatalogSyncManager]) and queues them all in order, same auto-play-through behavior
 * regardless of where the tap came from.
 */
object CatalogPlayback {

    suspend fun play(context: Context, id: String, title: String, type: ContentType) {
        val dao = CatalogDatabase.getInstance(context).catalogDao()
        val history = LibraryRepository.getInstance(context)

        val installedProvider = ProviderRegistry.load(context).firstOrNull { provider ->
            provider.providerId == id || provider.title == title || provider.id == id
        }

        val (titles, urls, contentIds, posterUrl) = if (type == ContentType.SERIES) {
            val episodes = dao.episodesForShow(title)
            if (episodes.isEmpty()) {
                val providerUrl = installedProvider?.downloadUrl
                if (providerUrl.isNullOrBlank()) return
                Quadruple(listOf(title), listOf(providerUrl), listOf(id), null)
            } else {
                Quadruple(
                    episodes.map { "$title - ${it.title}" },
                    episodes.map { it.url },
                    episodes.map { it.id },
                    episodes.firstOrNull()?.logo
                )
            }
        } else {
            val movie = dao.movieById(id)
            if (movie == null) {
                val providerUrl = installedProvider?.downloadUrl
                if (providerUrl.isNullOrBlank()) return
                Quadruple(listOf(title), listOf(providerUrl), listOf(id), null)
            } else {
                Quadruple(listOf(movie.title), listOf(movie.url), listOf(movie.id), movie.logo)
            }
        }

        val resumeMs = history.getHistoryEntry(contentIds.first())?.positionMs ?: 0L
        history.recordProgress(
            HistoryEntity(
                contentId = contentIds.first(),
                title = titles.first(),
                posterUrl = posterUrl,
                type = if (type == ContentType.SERIES) ContentType.EPISODE else ContentType.MOVIE,
                streamUrl = urls.first(),
                positionMs = resumeMs,
                durationMs = 0L,
                lastWatchedAtMs = System.currentTimeMillis()
            )
        )

        val qualityOptions = if (installedProvider != null && installedProvider.qualities.isNotEmpty()) {
            titles.map { installedProvider.qualities }
        } else {
            titles.map { emptyList() }
        }

        if (installedProvider != null && urls.size == 1 && urls.first().isNotBlank()) {
            val installOk = RepoRepository.installPlugin(context, com.mahdiridoy.iptvapp.movies.MovieItem(
                title = title,
                posterUrl = null,
                streamUrl = installedProvider.downloadUrl,
                description = null,
                isPlugin = true,
                repositoryName = installedProvider.repositoryName,
                providerId = installedProvider.providerId,
                isInstalled = true
            ))
            if (!installOk) {
                return
            }
        }

        PlaybackQueue.setWithDetails(
            titles = titles,
            urls = urls,
            startIndex = 0,
            contentIds = contentIds,
            qualityOptions = qualityOptions,
            startPositionMs = resumeMs
        )
        context.startActivity(Intent(context, PlayerActivity::class.java))
    }

    private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
