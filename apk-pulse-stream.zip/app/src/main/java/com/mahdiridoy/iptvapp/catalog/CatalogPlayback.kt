package com.mahdiridoy.iptvapp.catalog

import android.content.Context
import android.content.Intent
import com.mahdiridoy.iptvapp.catalog.db.CatalogDatabase
import com.mahdiridoy.iptvapp.data.ContentType
import com.mahdiridoy.iptvapp.data.LibraryRepository
import com.mahdiridoy.iptvapp.data.db.HistoryEntity
import com.mahdiridoy.iptvapp.player.PlaybackQueue
import com.mahdiridoy.iptvapp.player.PlayerActivity
import com.mahdiridoy.iptvapp.plugins.CloudStreamBridge
import com.mahdiridoy.iptvapp.plugins.PluginEpisode
import com.mahdiridoy.iptvapp.plugins.PluginSearchResult

/**
 * Plays a catalog item straight from Room, from anywhere it can be tapped (the Movies
 * & Series grid, Home's featured row, or a Favorites/History entry) - one shared path
 * instead of duplicating this per screen. A movie plays alone; a series looks up every
 * episode for [title] (used as the show's grouping key throughout - see
 * [CatalogSyncManager]) and queues them all in order, same auto-play-through behavior
 * regardless of where the tap came from.
 *
 * [playPluginMovie]/[playPluginEpisode] are a separate path for content found through
 * a real, installed CloudStream plugin (see [CloudStreamBridge]) - there's no Room
 * catalog entry to look up, so quality options are resolved live from the provider's
 * own loadLinks() instead.
 */
object CatalogPlayback {

    suspend fun play(context: Context, id: String, title: String, type: ContentType) {
        val dao = CatalogDatabase.getInstance(context).catalogDao()
        val history = LibraryRepository.getInstance(context)

        val (titles, urls, contentIds, posterUrl) = if (type == ContentType.SERIES) {
            val episodes = dao.episodesForShow(title)
            if (episodes.isEmpty()) return
            Quadruple(
                episodes.map { "$title - ${it.title}" },
                episodes.map { it.url },
                episodes.map { it.id },
                episodes.firstOrNull()?.logo
            )
        } else {
            val movie = dao.movieById(id) ?: return
            Quadruple(listOf(movie.title), listOf(movie.url), listOf(movie.id), movie.logo)
        }

        val resumeMs = history.getHistoryEntry(contentIds.first())?.positionMs ?: 0L
        history.recordProgress(
            HistoryEntity(
                contentId = contentIds.first(),
                title = titles.first(),
                posterUrl = posterUrl,
                type = if (type == ContentType.SERIES) ContentType.EPISODE else ContentType.MOVIE,
                streamUrl = urls.first(),
                positionMs = resumeMs,
                durationMs = 0L,
                lastWatchedAtMs = System.currentTimeMillis()
            )
        )

        PlaybackQueue.setWithDetails(
            titles = titles,
            urls = urls,
            startIndex = 0,
            contentIds = contentIds,
            qualityOptions = titles.map { emptyList() },
            startPositionMs = resumeMs
        )
        context.startActivity(Intent(context, PlayerActivity::class.java))
    }

    /**
     * Plays a movie found through a real, installed CloudStream plugin. Returns false
     * (nothing played) if the provider's extraction turned up no links, so the caller
     * can show an error instead of opening a blank player.
     */
    suspend fun playPluginMovie(context: Context, result: PluginSearchResult): Boolean {
        val qualities = CloudStreamBridge.resolveMovieQualities(result)
        if (qualities.isEmpty()) return false
        playResolvedQualities(context, result.response.name, qualities)
        return true
    }

    /** Same idea for one episode of a plugin-backed series - [providerName] +
     * [episode] identify which provider/episode to resolve. */
    suspend fun playPluginEpisode(
        context: Context,
        providerName: String,
        seriesTitle: String,
        episode: PluginEpisode
    ): Boolean {
        val qualities = CloudStreamBridge.resolveEpisodeQualities(providerName, episode)
        if (qualities.isEmpty()) return false
        playResolvedQualities(context, "$seriesTitle - ${episode.title}", qualities)
        return true
    }

    private fun playResolvedQualities(context: Context, title: String, qualities: List<Quality>) {
        val best = qualities.first()
        PlaybackQueue.setWithDetails(
            titles = listOf(title),
            urls = listOf(best.url),
            startIndex = 0,
            contentIds = listOf(null),
            qualityOptions = listOf(qualities),
            startPositionMs = 0L,
            urlHeaders = qualities.associate { it.url to it.headers }.filterValues { it.isNotEmpty() }
        )
        context.startActivity(Intent(context, PlayerActivity::class.java))
    }

    private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
