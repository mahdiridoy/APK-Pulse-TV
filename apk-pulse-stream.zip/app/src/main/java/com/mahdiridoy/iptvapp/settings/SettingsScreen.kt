package com.mahdiridoy.iptvapp.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mahdiridoy.iptvapp.update.UpdateManager
import kotlinx.coroutines.delay

@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier,
    viewModel: SettingsViewModel = viewModel()
) {
    val context = LocalContext.current
    val currentUrl by viewModel.playlistUrl.collectAsState()
    val saved by viewModel.saved.collectAsState()
    val updateCheckState by viewModel.updateCheckState.collectAsState()
    var urlField by remember(currentUrl) { mutableStateOf(currentUrl) }

    LaunchedEffect(saved) {
        if (saved) {
            delay(2_000)
            viewModel.clearSavedFlag()
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Live TV playlist", style = MaterialTheme.typography.titleMedium)
        Text(
            "The M3U/Xtream URL Live TV loads channels from.",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = urlField,
            onValueChange = { urlField = it },
            label = { Text("Playlist URL") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { viewModel.saveM3uUrl(urlField) }) {
            Text("Save")
        }
        if (saved) {
            Text(
                "Saved. New playlist loads next time Live TV refreshes.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        Text("App update", style = MaterialTheme.typography.titleMedium)
        val checkState = updateCheckState
        OutlinedButton(
            onClick = { viewModel.checkForUpdate() },
            enabled = checkState !is UpdateCheckState.Checking
        ) {
            Text(if (checkState is UpdateCheckState.Checking) "Checking…" else "Check for updates")
        }
        if (checkState is UpdateCheckState.NotAvailable) {
            Text(checkState.reason, style = MaterialTheme.typography.bodySmall)
        }
    }

    val available = (updateCheckState as? UpdateCheckState.Available)
    if (available != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissUpdateCheck() },
            title = { Text("Update available") },
            text = { Text("A new version is ready to install (${available.versionLabel}).") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.dismissUpdateCheck()
                    UpdateManager.downloadAndInstall(context, available.apkUrl)
                }) { Text("Update Now") }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissUpdateCheck() }) { Text("Later") }
            }
        )
    }
}
