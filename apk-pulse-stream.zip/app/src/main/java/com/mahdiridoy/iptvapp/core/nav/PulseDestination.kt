package com.mahdiridoy.iptvapp.core.nav

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Theaters
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * The app's seven top-level sections, in the order they appear in the nav
 * drawer. [route] is the [androidx.navigation.NavHost] route string.
 *
 * There's no standalone Search entry - it never had a real trigger wired to
 * it (the SearchableFragment plumbing in LiveTvFragment/MoviesFragment was
 * built but nothing ever called openSearch()), and a global search across
 * three different content types isn't that useful anyway. Instead each grid
 * (Live TV, Movies) reveals its own inline search panel when you D-pad past
 * the last column, or via the search icon on touch.
 */
enum class PulseDestination(val route: String, val label: String, val icon: ImageVector) {
    HOME("home", "Home", Icons.Filled.Home),
    LIVE_TV("live_tv", "Live TV", Icons.Filled.LiveTv),
    MOVIES("movies", "Movies", Icons.Filled.Movie),
    SERIES("series", "Series", Icons.Filled.Theaters),
    FAVORITES("favorites", "Favorites", Icons.Filled.Favorite),
    HISTORY("history", "History", Icons.Filled.History),
    SETTINGS("settings", "Settings", Icons.Filled.Settings)
}
