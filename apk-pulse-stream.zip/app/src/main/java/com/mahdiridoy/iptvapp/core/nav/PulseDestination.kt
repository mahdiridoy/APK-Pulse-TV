package com.mahdiridoy.iptvapp.core.nav

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * The app's six top-level sections, in the order they appear in the nav
 * drawer. [route] is the [androidx.navigation.NavHost] route string.
 *
 * Movies and Series used to be separate entries, each backed by its own JSON
 * repo system. Merged into one "Movies & Series" destination backed by
 * [com.mahdiridoy.iptvapp.movies.MoviesSeriesScreen], which browses directly
 * from an M3U playlist the same way Live TV does (see [[CatalogRepository]]'s
 * M3U_CATALOG_URL) - no separate category/detail-page browsing anymore, one
 * flat grid, tap to play immediately.
 *
 * There's no standalone Search entry either - it never had a real trigger
 * wired to it. Live TV reveals its own inline search panel when you D-pad
 * past the last column, or via swipe/edge gesture on touch.
 */
enum class PulseDestination(val route: String, val label: String, val icon: ImageVector) {
    HOME("home", "Home", Icons.Filled.Home),
    LIVE_TV("live_tv", "Live TV", Icons.Filled.LiveTv),
    MOVIES("movies", "Movies & Series", Icons.Filled.Movie),
    FAVORITES("favorites", "Favorites", Icons.Filled.Favorite),
    HISTORY("history", "History", Icons.Filled.History),
    SETTINGS("settings", "Settings", Icons.Filled.Settings)
}
