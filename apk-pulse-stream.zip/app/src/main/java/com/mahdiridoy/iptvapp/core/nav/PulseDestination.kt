package com.mahdiridoy.iptvapp.core.nav

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Theaters
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * The app's eight top-level sections, in the order they appear in the nav
 * drawer. [route] is the [androidx.navigation.NavHost] route string.
 */
enum class PulseDestination(val route: String, val label: String, val icon: ImageVector) {
    HOME("home", "Home", Icons.Filled.Home),
    LIVE_TV("live_tv", "Live TV", Icons.Filled.LiveTv),
    MOVIES("movies", "Movies", Icons.Filled.Movie),
    SERIES("series", "Series", Icons.Filled.Theaters),
    SEARCH("search", "Search", Icons.Filled.Search),
    FAVORITES("favorites", "Favorites", Icons.Filled.Favorite),
    HISTORY("history", "History", Icons.Filled.History),
    SETTINGS("settings", "Settings", Icons.Filled.Settings)
}
