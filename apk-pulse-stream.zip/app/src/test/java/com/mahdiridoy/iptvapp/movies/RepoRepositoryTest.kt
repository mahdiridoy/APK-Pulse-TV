package com.mahdiridoy.iptvapp.movies

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.util.zip.ZipOutputStream

class RepoRepositoryTest {
    @Test
    fun normalizeUrl_addsHttpsToRawGithubUrls() {
        val raw = "raw.githubusercontent.com/phisher98/cloudstream-extensions-phisher/refs/heads/builds/repo.json"
        val expected = "https://raw.githubusercontent.com/phisher98/cloudstream-extensions-phisher/refs/heads/builds/repo.json"

        assertEquals(expected, RepoRepository.normalizeUrl(raw))
    }

    @Test
    fun normalizeUrl_keepsExistingHttpsUrls() {
        val url = "https://example.com/repo.json"
        assertEquals(url, RepoRepository.normalizeUrl(url))
    }

    @Test
    fun buildPluginInstallFileName_usesSafeExtension() {
        val name = RepoRepository.buildPluginInstallFileName("My Test Provider", "https://example.com/providers/my_provider.cs3")
        assertEquals("my_test_provider.cs3", name)
    }

    @Test
    fun readPackageItems_parsesManifestFromArchive() {
        val tempDir = File.createTempFile("repo-package", "")
        tempDir.delete()
        tempDir.mkdirs()
        val archiveFile = File(tempDir, "moviebox.cs3")
        archiveFile.outputStream().use { output ->
            ZipOutputStream(output).use { zip ->
                zip.putNextEntry(java.util.zip.ZipEntry("manifest.json"))
                zip.write("""
                    {
                      "title": "MovieBox Sample",
                      "streamUrl": "https://example.com/movie.m3u8",
                      "description": "Sample from package"
                    }
                """.trimIndent().toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }

        val items = RepoRepository.readPackageItems(archiveFile, "MovieBox")

        assertEquals(1, items.size)
        assertEquals("MovieBox Sample", items.first().title)
        assertTrue(items.first().streamUrl.contains("movie.m3u8"))
    }

    @Test
    fun readPackageItems_parsesArrayManifestFromArchive() {
        val tempDir = File.createTempFile("repo-package-array", "")
        tempDir.delete()
        tempDir.mkdirs()
        val archiveFile = File(tempDir, "moviebox-array.cs3")
        archiveFile.outputStream().use { output ->
            ZipOutputStream(output).use { zip ->
                zip.putNextEntry(java.util.zip.ZipEntry("manifest.json"))
                zip.write("""
                    [
                      {
                        "title": "Array Manifest Item",
                        "streamUrl": "https://example.com/array.m3u8",
                        "description": "Array-based package"
                      }
                    ]
                """.trimIndent().toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }

        val items = RepoRepository.readPackageItems(archiveFile, "MovieBox")

        assertEquals(1, items.size)
        assertEquals("Array Manifest Item", items.first().title)
        assertTrue(items.first().streamUrl.contains("array.m3u8"))
    }
}
