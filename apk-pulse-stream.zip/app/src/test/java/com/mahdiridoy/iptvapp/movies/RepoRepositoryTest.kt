package com.mahdiridoy.iptvapp.movies

import org.junit.Assert.assertEquals
import org.junit.Test

class RepoRepositoryTest {
    @Test
    fun normalizeUrl_addsHttpsToRawGithubUrls() {
        val raw = "raw.githubusercontent.com/phisher98/cloudstream-extensions-phisher/refs/heads/builds/repo.json"
        val expected = "https://raw.githubusercontent.com/phisher98/cloudstream-extensions-phisher/refs/heads/builds/repo.json"

        assertEquals(expected, RepoRepository.normalizeUrl(raw))
    }

    @Test
    fun normalizeUrl_keepsExistingHttpsUrls() {
        val url = "https://example.com/repo.json"
        assertEquals(url, RepoRepository.normalizeUrl(url))
    }

    @Test
    fun buildPluginInstallFileName_usesSafeExtension() {
        val name = RepoRepository.buildPluginInstallFileName("My Test Provider", "https://example.com/providers/my_provider.cs3")
        assertEquals("my_test_provider.cs3", name)
    }
}
