import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    // NOT applying "org.jetbrains.kotlin.android" - AGP 9's built-in Kotlin support
    // means this now hard-fails the build ("The 'org.jetbrains.kotlin.android' plugin
    // is no longer required for Kotlin support since AGP 9.0") rather than just being
    // redundant. Kotlin support comes from com.android.application itself now; the
    // actual Kotlin version used is set via the buildscript classpath override in the
    // root build.gradle.kts instead. See the kotlin{} block below replacing
    // android{}'s old kotlinOptions{} for the same reason.
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.mahdiridoy.iptvapp"
    // CloudStream's own :library (see the CloudStream plugin engine below) requires
    // compileSdk 37 - confirmed directly from a real build's checkDebugAarMetadata
    // failure, not a guess: "Dependency ... requires ... version 37 or later ...
    // :app is currently compiled against android-36. Also, the maximum recommended
    // compile SDK version for Android Gradle plugin 8.5.0 is 34." 37 is also what
    // CloudStream's own gradle/libs.versions.toml compiles itself against, alongside
    // targetSdk 36 - matched exactly below rather than guessing a nearby pair.
    compileSdk = 37

    defaultConfig {
        applicationId = "com.mahdiridoy.iptvapp"
        // CloudStream's :library requires minSdk 23. This does drop support for
        // Android 5.0/5.1 devices.
        minSdk = 23
        targetSdk = 36
        // versionCode must climb on every real build. GITHUB_RUN_NUMBER alone doesn't
        // change when a CI run is just re-run (only run_attempt does, which was why the
        // version - and the release tag built from it - could repeat instead of
        // increasing). APP_VERSION_CODE (set by build-apk.yml from the repo's total
        // commit count) is what CI passes in now; that number only ever goes up, and the
        // release tag embeds this exact same number, so UpdateChecker's tag-vs-installed
        // comparison still lines up correctly. Local Android Studio builds (no CI env
        // vars present) fall back to 3, same as before - those are for testing on your
        // own device, not something distributed via GitHub Releases.
        versionCode = System.getenv("APP_VERSION_CODE")?.toIntOrNull()
            ?: System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()
            ?: 3
        versionName = "1.0.0.8"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
        compose = true
    }
    // No composeOptions{kotlinCompilerExtensionVersion=...} block anymore - as of
    // Kotlin 2.0+, the Compose compiler ships as part of the Kotlin Gradle plugin
    // itself, enabled via the "org.jetbrains.kotlin.plugin.compose" plugin applied
    // above (version-matched to Kotlin 2.4.0 in the root build.gradle.kts). The old
    // composeOptions block is for the pre-2.0 standalone compose-compiler artifact and
    // no longer applies.
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            // The CloudStream :library dependency pulls in a large graph (jackson,
            // ktor, kotlinx-coroutines/serialization/atomicfu, rhino) that's likely to
            // collide with what's already here on shared META-INF metadata files -
            // AGP fails the whole build on the first duplicate it finds otherwise.
            // Broad but harmless: none of these affect app behavior, only packaging.
            excludes += "/META-INF/DEPENDENCIES"
            excludes += "/META-INF/LICENSE*"
            excludes += "/META-INF/NOTICE*"
            excludes += "/META-INF/INDEX.LIST"
            excludes += "/META-INF/*.kotlin_module"
            excludes += "/META-INF/versions/**"
            pickFirsts += "/META-INF/*.version"
        }
    }
}

// Replaces the old android{ kotlinOptions { jvmTarget = "17" } } block - AGP 9's
// built-in Kotlin uses this top-level DSL instead (android.kotlinOptions{} no longer
// resolves once org.jetbrains.kotlin.android isn't applied, per Android's own
// built-in-Kotlin migration guide).
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.leanback:leanback:1.0.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // Media3 ExoPlayer - handles HLS/DASH/progressive M3U8 streams
    implementation("androidx.media3:media3-exoplayer:1.4.0")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.0")
    implementation("androidx.media3:media3-ui:1.4.0")
    implementation("androidx.media3:media3-datasource-okhttp:1.4.0")
    // Chromecast - optional, per the original ask. Pinned to 1.4.0 to match every other
    // media3-* artifact above; media3-cast 1.9.x's rewritten auto-switching CastPlayer
    // needs a MediaSession-based setup and newer media3-common than the rest of this
    // project uses, which isn't a safe jump to make blind in one pass. This uses the
    // older, more manual (but stable, version-matched) SessionAvailabilityListener pattern.
    implementation("androidx.media3:media3-cast:1.4.0")
    implementation("androidx.mediarouter:mediarouter:1.6.0")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jsoup:jsoup:1.17.2")
    implementation("io.coil-kt:coil:2.7.0")
    implementation("io.coil-kt:coil-svg:2.7.0")
    implementation("io.coil-kt:coil-gif:2.7.0")

    // Jetpack Compose (Material 3) - new navigation shell + new screens.
    // LiveTvFragment keeps running as-is, hosted inside Compose via fragment-compose.
    // 2026.04.01 - bumped from 2024.10.01 alongside the Kotlin 2.4.0/AGP 9.1.1 bump
    // needed for the CloudStream :library dependency below; this BOM is the latest
    // confirmed-stable one that still predates Compose 1.12's own compileSdk
    // 37/AGP 9 requirement, so it's a safe pairing rather than forcing a preview BOM.
    val composeBom = platform("androidx.compose:compose-bom:2026.04.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.fragment:fragment-compose:1.8.9")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // Coil 2.x. (Coil 3.x's latest releases need a newer minimum Compose runtime than
    // this project pins - not revisited in this pass since it's unrelated to the
    // Kotlin/AGP bump above.)
    implementation("io.coil-kt:coil-compose:2.7.0")

    // Room - favorites, watch history, resume positions, and (separately - see
    // catalog.db in CatalogDatabase) the Movies & Series catalog synced from M3U.
    // Bumped from 2.6.1 - a real build failed at :app:kspDebugKotlin with
    // "IllegalStateException: unexpected jvm signature V" inside Room's own KSP
    // compiler-processing code (androidx.room.compiler.processing.ksp.
    // KSTypeJavaPoetExtKt.asJTypeName). This is a known class of bug: Room 2.6.1's
    // bundled XProcessing predates KSP2/the Kotlin K2 compiler backend entirely
    // (Room 2.6.1 shipped Nov 2023, well before Kotlin 2.0), so it can't parse JVM
    // signatures the way KSP 2.3.5/Kotlin 2.4.0 produce them. 2.8.4 is the latest
    // stable Room 2.x release (androidx.room package - Room 3.0 is a separate,
    // intentionally-breaking KMP rewrite under androidx.room3, not needed here for an
    // Android-only app and not worth that migration just to fix this).
    implementation("androidx.room:room-runtime:2.8.4")
    implementation("androidx.room:room-ktx:2.8.4")
    // Paging3 support for Room @Query methods returning PagingSource - without this,
    // Room falls back to its own older, non-Paging3 PagingSource implementation.
    implementation("androidx.room:room-paging:2.8.4")
    ksp("androidx.room:room-compiler:2.8.4")

    // Paging3: lets the Movies & Series grid load a 130k+ row catalog from SQLite a
    // page at a time instead of pulling every row into memory up front.
    implementation("androidx.paging:paging-runtime-ktx:3.2.1")
    implementation("androidx.paging:paging-compose:3.2.1")

    // --- CloudStream plugin engine -------------------------------------------------
    // Real .cs3 files are compiled against CloudStream's own classes (MainAPI,
    // ExtractorLink, the app.get() network layer, dozens of built-in link extractors,
    // etc.) - not a JSON manifest. To load and run one, those actual classes need to
    // be present at runtime, not reimplemented by guesswork.
    //
    // Verified directly against the real recloudstream/cloudstream source (not just
    // docs): ":library" is the actual module CloudStream split out specifically so it
    // can be depended on outside the main app - MainAPI, APIHolder, ExtractorLink,
    // BasePlugin/Plugin, and every built-in extractor (DoodExtractor, StreamTape-style
    // hosts, etc.) all live there, and library/build.gradle.kts declares nicehttp,
    // jsoup/ksoup, jackson, rhino, and kotlinx-serialization as ITS OWN dependencies -
    // so this one line is genuinely sufficient, nothing else needs adding by hand.
    // Published only via JitPack (see settings.gradle.kts), same as the real
    // recloudstream/extensions repo's own build.gradle.kts uses to compile plugins
    // against it - used here the other way around, as the *host* app's dependency.
    //
    // "-SNAPSHOT" tracks whatever's newest on JitPack right now, matching upstream's
    // own extensions repo - worth pinning to a specific release tag or commit hash
    // once this resolves and builds cleanly, so a future CloudStream change can't
    // silently break this build.
    //
    // Depending on this pulls in the GPL-3.0 license from CloudStream's codebase -
    // see LICENSE and NOTICE.md at the project root.
    implementation("com.github.recloudstream.cloudstream:library:-SNAPSHOT")

    testImplementation("junit:junit:4.13.2")
}
