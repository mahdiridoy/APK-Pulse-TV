plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.mahdiridoy.iptvapp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mahdiridoy.iptvapp"
        minSdk = 21
        targetSdk = 34
        // versionCode must climb on every real build. GITHUB_RUN_NUMBER alone doesn't
        // change when a CI run is just re-run (only run_attempt does, which was why the
        // version - and the release tag built from it - could repeat instead of
        // increasing). APP_VERSION_CODE (set by build-apk.yml from the repo's total
        // commit count) is what CI passes in now; that number only ever goes up, and the
        // release tag embeds this exact same number, so UpdateChecker's tag-vs-installed
        // comparison still lines up correctly. Local Android Studio builds (no CI env
        // vars present) fall back to 3, same as before - those are for testing on your
        // own device, not something distributed via GitHub Releases.
        versionCode = System.getenv("APP_VERSION_CODE")?.toIntOrNull()
            ?: System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()
            ?: 3
        versionName = "2.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.leanback:leanback:1.0.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // Media3 ExoPlayer - handles HLS/DASH/progressive M3U8 streams
    implementation("androidx.media3:media3-exoplayer:1.4.0")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.0")
    implementation("androidx.media3:media3-ui:1.4.0")
    implementation("androidx.media3:media3-datasource-okhttp:1.4.0")
    // Chromecast - optional, per the original ask. Pinned to 1.4.0 to match every other
    // media3-* artifact above; media3-cast 1.9.x's rewritten auto-switching CastPlayer
    // needs a MediaSession-based setup and newer media3-common than the rest of this
    // project uses, which isn't a safe jump to make blind in one pass. This uses the
    // older, more manual (but stable, version-matched) SessionAvailabilityListener pattern.
    implementation("androidx.media3:media3-cast:1.4.0")
    implementation("androidx.mediarouter:mediarouter:1.6.0")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jsoup:jsoup:1.17.2")
    implementation("com.squareup.picasso:picasso:2.8")

    // Jetpack Compose (Material 3) - new navigation shell + new screens.
    // LiveTvFragment keeps running as-is, hosted inside Compose via fragment-compose.
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.fragment:fragment-compose:1.8.9")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // Coil 2.x - matches our Compose Compiler 1.5.14 / Kotlin 1.9.24 pin. (Coil 3.x's
    // latest releases require a newer Compose runtime than that combination supports.)
    implementation("io.coil-kt:coil-compose:2.7.0")

    // Room - favorites, watch history, resume positions.
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")
}
