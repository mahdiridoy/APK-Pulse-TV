plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.mahdiridoy.iptvapp"
    // Bumped from 34 - CloudStream's own :library (now a dependency, see the
    // CloudStream plugin engine below) is built against compileSdk 37/minSdk 23; AGP
    // rejects a dependency whose minSdk exceeds the app's own. 36 (not the full 37) is
    // deliberate - it's a released, stable API level, so it doesn't also require a
    // newer/preview Android SDK Platform + command-line tools in CI just to compile.
    // If the build still complains about a compileSdk mismatch against :library,
    // matching 37 exactly is the next step - that just needs `sdkmanager
    // "platforms;android-37"` (and possibly a newer AGP) available wherever this
    // builds.
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mahdiridoy.iptvapp"
        // Bumped from 21 - CloudStream's :library requires minSdk 23 (see comment on
        // compileSdk above). This does drop support for Android 5.0/5.1 devices.
        minSdk = 23
        targetSdk = 36
        // versionCode must climb on every real build. GITHUB_RUN_NUMBER alone doesn't
        // change when a CI run is just re-run (only run_attempt does, which was why the
        // version - and the release tag built from it - could repeat instead of
        // increasing). APP_VERSION_CODE (set by build-apk.yml from the repo's total
        // commit count) is what CI passes in now; that number only ever goes up, and the
        // release tag embeds this exact same number, so UpdateChecker's tag-vs-installed
        // comparison still lines up correctly. Local Android Studio builds (no CI env
        // vars present) fall back to 3, same as before - those are for testing on your
        // own device, not something distributed via GitHub Releases.
        versionCode = System.getenv("APP_VERSION_CODE")?.toIntOrNull()
            ?: System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()
            ?: 3
        versionName = "1.0.0.4"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            // The CloudStream :library dependency pulls in a large graph (jackson,
            // ktor, kotlinx-coroutines/serialization/atomicfu, rhino) that's likely to
            // collide with what's already here on shared META-INF metadata files -
            // AGP fails the whole build on the first duplicate it finds otherwise.
            // Broad but harmless: none of these affect app behavior, only packaging.
            excludes += "/META-INF/DEPENDENCIES"
            excludes += "/META-INF/LICENSE*"
            excludes += "/META-INF/NOTICE*"
            excludes += "/META-INF/INDEX.LIST"
            excludes += "/META-INF/*.kotlin_module"
            excludes += "/META-INF/versions/**"
            pickFirsts += "/META-INF/*.version"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.leanback:leanback:1.0.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // Media3 ExoPlayer - handles HLS/DASH/progressive M3U8 streams
    implementation("androidx.media3:media3-exoplayer:1.4.0")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.0")
    implementation("androidx.media3:media3-ui:1.4.0")
    implementation("androidx.media3:media3-datasource-okhttp:1.4.0")
    // Chromecast - optional, per the original ask. Pinned to 1.4.0 to match every other
    // media3-* artifact above; media3-cast 1.9.x's rewritten auto-switching CastPlayer
    // needs a MediaSession-based setup and newer media3-common than the rest of this
    // project uses, which isn't a safe jump to make blind in one pass. This uses the
    // older, more manual (but stable, version-matched) SessionAvailabilityListener pattern.
    implementation("androidx.media3:media3-cast:1.4.0")
    implementation("androidx.mediarouter:mediarouter:1.6.0")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jsoup:jsoup:1.17.2")
    implementation("io.coil-kt:coil:2.7.0")
    implementation("io.coil-kt:coil-svg:2.7.0")
    implementation("io.coil-kt:coil-gif:2.7.0")

    // Jetpack Compose (Material 3) - new navigation shell + new screens.
    // LiveTvFragment keeps running as-is, hosted inside Compose via fragment-compose.
    // 2024.10.01, not 2024.06.00 - PullToRefreshBox (Movies & Series' pull-to-refresh)
    // needs material3 >=1.3.0, which needs bom >=2024.09.00. Picked the smallest bump
    // past that point rather than jumping to the newest BOM, to limit the chance of
    // unrelated API changes breaking something elsewhere in the app.
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.fragment:fragment-compose:1.8.9")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // Coil 2.x - matches our Compose Compiler 1.5.14 / Kotlin 1.9.24 pin. (Coil 3.x's
    // latest releases require a newer Compose runtime than that combination supports.)
    implementation("io.coil-kt:coil-compose:2.7.0")

    // Room - favorites, watch history, resume positions, and (separately - see
    // catalog.db in CatalogDatabase) the Movies & Series catalog synced from M3U.
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    // Paging3 support for Room @Query methods returning PagingSource - without this,
    // Room falls back to its own older, non-Paging3 PagingSource implementation.
    implementation("androidx.room:room-paging:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Paging3: lets the Movies & Series grid load a 130k+ row catalog from SQLite a
    // page at a time instead of pulling every row into memory up front.
    implementation("androidx.paging:paging-runtime-ktx:3.2.1")
    implementation("androidx.paging:paging-compose:3.2.1")

    // --- CloudStream plugin engine -------------------------------------------------
    // Real .cs3 files are compiled against CloudStream's own classes (MainAPI,
    // ExtractorLink, the app.get() network layer, dozens of built-in link extractors,
    // etc.) - not a JSON manifest. To load and run one, those actual classes need to
    // be present at runtime, not reimplemented by guesswork.
    //
    // Verified directly against the real recloudstream/cloudstream source (not just
    // docs): ":library" is the actual module CloudStream split out specifically so it
    // can be depended on outside the main app - MainAPI, APIHolder, ExtractorLink,
    // BasePlugin/Plugin, and every built-in extractor (DoodExtractor, StreamTape-style
    // hosts, etc.) all live there, and library/build.gradle.kts declares nicehttp,
    // jsoup/ksoup, jackson, rhino, and kotlinx-serialization as ITS OWN dependencies -
    // so this one line is genuinely sufficient, nothing else needs adding by hand.
    // Published only via JitPack (see settings.gradle.kts), same as the real
    // recloudstream/extensions repo's own build.gradle.kts uses to compile plugins
    // against it - used here the other way around, as the *host* app's dependency.
    //
    // "-SNAPSHOT" tracks whatever's newest on JitPack right now, matching upstream's
    // own extensions repo - worth pinning to a specific release tag or commit hash
    // once this resolves and builds cleanly, so a future CloudStream change can't
    // silently break this build.
    //
    // Depending on this pulls in the GPL-3.0 license from CloudStream's codebase -
    // see LICENSE and NOTICE.md at the project root.
    implementation("com.github.recloudstream.cloudstream:library:-SNAPSHOT")

    testImplementation("junit:junit:4.13.2")
}
