pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // CloudStream's own plugin ecosystem (the ":library" module real plugins
        // compile against, plus the handful of libs providers commonly call directly)
        // is only published through JitPack, not Maven Central - see app/build.gradle.kts.
        maven("https://jitpack.io")
    }
}

rootProject.name = "IPTVApp"
include(":app")
