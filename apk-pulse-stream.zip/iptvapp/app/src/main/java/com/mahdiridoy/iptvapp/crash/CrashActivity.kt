package com.mahdiridoy.iptvapp.crash

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.mahdiridoy.iptvapp.MainActivity

class CrashActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TRACE = "extra_trace"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val trace = intent.getStringExtra(EXTRA_TRACE) ?: "Unknown error"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
        }

        val title = TextView(this).apply {
            text = "The app hit an error and stopped."
            textSize = 18f
            setPadding(0, 0, 0, 16)
        }

        val traceView = TextView(this).apply {
            text = trace
            textSize = 12f
            setTextIsSelectable(true)
        }

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
            addView(traceView)
        }

        val restartButton = Button(this).apply {
            text = "Restart App"
            setOnClickListener {
                val intent = Intent(this@CrashActivity, MainActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(intent)
                finish()
            }
        }

        root.addView(title)
        root.addView(scroll)
        root.addView(restartButton)
        setContentView(root)
    }
}
