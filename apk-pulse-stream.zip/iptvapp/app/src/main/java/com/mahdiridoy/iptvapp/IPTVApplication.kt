package com.mahdiridoy.iptvapp

import android.app.Application
import com.mahdiridoy.iptvapp.crash.CrashHandler

class IPTVApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler(CrashHandler(this))
    }
}
