package com.mahdiridoy.iptvapp.movies

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.IOException

object RepoRepository {
    private val client = OkHttpClient()

    @Throws(IOException::class)
    fun fetchItems(repo: Repo): List<MovieItem> {
        val request = Request.Builder().url(repo.manifestUrl).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Failed to fetch ${repo.name}: HTTP ${response.code}")
            }
            val body = response.body?.string() ?: "[]"
            return parse(body)
        }
    }

    private fun parse(json: String): List<MovieItem> {
        val array = JSONArray(json)
        val items = mutableListOf<MovieItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val streamUrl = obj.optString("streamUrl")
            if (streamUrl.isBlank()) continue
            items.add(
                MovieItem(
                    title = obj.optString("title", "Untitled"),
                    posterUrl = obj.optString("poster").ifBlank { null },
                    streamUrl = streamUrl
                )
            )
        }
        return items
    }
}
