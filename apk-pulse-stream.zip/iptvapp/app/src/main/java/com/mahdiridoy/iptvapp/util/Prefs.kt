package com.mahdiridoy.iptvapp.util

import android.content.Context

/**
 * Simple SharedPreferences wrapper.
 *
 * IMPORTANT: set DEFAULT_M3U_URL below to your raw GitHub playlist URL, e.g.
 * https://raw.githubusercontent.com/mahdiridoy/Tv/main/output.m3u
 */
object Prefs {
    private const val FILE = "iptv_prefs"
    private const val KEY_M3U_URL = "m3u_url"
    private const val KEY_LAST_ETAG = "last_etag"
    private const val KEY_LAST_FETCH_TIME = "last_fetch_time"

    // TODO: replace with your actual raw GitHub M3U URL
    const val DEFAULT_M3U_URL = "https://mahdiridoy.github.io/Tv/mahdi_iptv.m3u8"

    fun getPlaylistUrl(context: Context): String {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_M3U_URL, DEFAULT_M3U_URL) ?: DEFAULT_M3U_URL
    }

    fun setPlaylistUrl(context: Context, url: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_M3U_URL, url).apply()
    }

    fun getLastEtag(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_LAST_ETAG, null)

    fun setLastEtag(context: Context, etag: String?) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_LAST_ETAG, etag).apply()
    }

    fun setLastFetchTime(context: Context, time: Long) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putLong(KEY_LAST_FETCH_TIME, time).apply()
    }

    fun getLastFetchTime(context: Context): Long =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getLong(KEY_LAST_FETCH_TIME, 0L)
}
