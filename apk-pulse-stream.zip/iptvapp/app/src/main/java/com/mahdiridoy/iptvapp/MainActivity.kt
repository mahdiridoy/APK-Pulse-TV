package com.mahdiridoy.iptvapp

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.mahdiridoy.iptvapp.databinding.ActivityMainBinding
import com.mahdiridoy.iptvapp.livetv.LiveTvFragment
import com.mahdiridoy.iptvapp.movies.MoviesFragment
import com.mahdiridoy.iptvapp.update.UpdateManager
import com.mahdiridoy.iptvapp.util.DeviceUtil
import com.mahdiridoy.iptvapp.util.PlaylistRefreshWorker
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_UPDATE_TAG = "extra_update_tag"
        const val EXTRA_UPDATE_APK_URL = "extra_update_apk_url"
        const val EXTRA_UPDATE_CHECK_REASON = "extra_update_check_reason"
    }

    private lateinit var binding: ActivityMainBinding
    private var navVisible = false

    // Touch tracking for edge-swipe nav reveal / outside-tap dismiss
    private var downX = 0f
    private var downY = 0f
    private var downInsideNav = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Phones: portrait for browsing UI. Android TV: leave as the system's
        // fixed landscape (locking portrait on a TV display just looks broken).
        requestedOrientation = if (DeviceUtil.isTelevision(this)) {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            showLiveTv()
        }

        binding.navLiveTv.setOnClickListener { showLiveTv(); hideNav() }
        binding.navMovies.setOnClickListener { showMovies(); hideNav() }
        binding.navSearch.setOnClickListener { openSearchOnCurrentFragment(); hideNav() }

        binding.navLiveTv.requestFocus()

        schedulePlaylistRefresh()
        handleUpdateIfAvailable()
    }

    private fun handleUpdateIfAvailable() {
        val tag = intent.getStringExtra(EXTRA_UPDATE_TAG)
        val apkUrl = intent.getStringExtra(EXTRA_UPDATE_APK_URL)
        if (tag != null && apkUrl != null) {
            AlertDialog.Builder(this)
                .setTitle(R.string.update_available_title)
                .setMessage(getString(R.string.update_available_message) + " ($tag)")
                .setCancelable(false)
                .setPositiveButton(R.string.update_now) { _, _ ->
                    UpdateManager.downloadAndInstall(this, apkUrl)
                }
                .setNegativeButton(R.string.update_later, null)
                .show()
            return
        }
        // No update found - show why, so this is debuggable without logcat.
        // Remove this Toast once update checks are confirmed working end to end.
        val reason = intent.getStringExtra(EXTRA_UPDATE_CHECK_REASON)
        if (!reason.isNullOrBlank()) {
            Toast.makeText(this, reason, Toast.LENGTH_LONG).show()
        }
    }

    private fun showLiveTv() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.contentContainer, LiveTvFragment())
            .commit()
    }

    private fun showMovies() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.contentContainer, MoviesFragment())
            .commit()
    }

    private fun currentSearchable(): SearchableFragment? =
        supportFragmentManager.findFragmentById(R.id.contentContainer) as? SearchableFragment

    private fun openSearchOnCurrentFragment() {
        currentSearchable()?.openSearch()
    }

    private fun schedulePlaylistRefresh() {
        val request = PeriodicWorkRequestBuilder<PlaylistRefreshWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "playlist_refresh",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    // ---- Auto-hide nav rail: phone edge-swipe + TV D-pad-left-at-edge ----

    private fun showNav() {
        if (navVisible) return
        navVisible = true
        binding.navRail.animate().translationX(0f).setDuration(200).start()
    }

    private fun hideNav() {
        if (!navVisible) return
        navVisible = false
        binding.navRail.animate().translationX(-binding.navRail.width.toFloat()).setDuration(200).start()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                downInsideNav = navVisible &&
                    ev.x >= binding.navRail.left && ev.x <= binding.navRail.right
            }
            MotionEvent.ACTION_UP -> {
                val deltaX = ev.x - downX
                val edgeZonePx = resources.displayMetrics.density * 32
                if (navVisible && !downInsideNav) {
                    hideNav()
                    return true
                } else if (!navVisible && downX <= edgeZonePx && deltaX > edgeZonePx) {
                    showNav()
                    return true
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_DPAD_LEFT && !navVisible) {
            val focusBefore = currentFocus
            val handled = super.dispatchKeyEvent(event)
            val focusAfter = currentFocus
            // Focus didn't move: we're at the leftmost item, so this LEFT press
            // is the "navigate to nav rail" signal from the TV remote.
            if (focusBefore == focusAfter) {
                showNav()
                binding.navLiveTv.requestFocus()
                return true
            }
            return handled
        }
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_BACK) {
            val searchable = currentSearchable()
            if (searchable != null && searchable.isSearchOpen()) {
                searchable.closeSearch()
                return true
            }
            if (navVisible) {
                hideNav()
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }
}
