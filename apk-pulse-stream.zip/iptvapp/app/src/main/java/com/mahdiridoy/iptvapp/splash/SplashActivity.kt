package com.mahdiridoy.iptvapp.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.mahdiridoy.iptvapp.MainActivity
import com.mahdiridoy.iptvapp.R
import com.mahdiridoy.iptvapp.livetv.M3uParser
import com.mahdiridoy.iptvapp.update.UpdateChecker
import com.mahdiridoy.iptvapp.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Shown once per app open: a 5s ad screen while the app checks the M3U for
 * updates and checks GitHub for a new app version in the background, then
 * moves on to MainActivity automatically. Ad only ever shows here, never again
 * mid-session.
 */
class SplashActivity : AppCompatActivity() {

    companion object {
        // Host this exact file (see ad_page_snippet.html in the project root)
        // on your GitHub Pages site. Most ad networks tie a zone to a specific
        // registered domain, and a real page load (not an in-memory data: URI)
        // matches what they expect far more reliably.
        private const val AD_PAGE_URL = "https://mahdiridoy.github.io/Tv/ad.html"
    }

    private var updateInfo: UpdateChecker.ReleaseInfo? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val webView = findViewById<WebView>(R.id.adWebView)
        val countdownText = findViewById<TextView>(R.id.countdownText)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        // Most ad networks (including this one) rely on third-party cookies to
        // serve/track creatives - WebView blocks these by default.
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        // Ad tags frequently deliver via window.open() (popunders); without
        // multi-window support enabled, WebView silently drops them with
        // nothing visibly happening.
        webView.settings.setSupportMultipleWindows(true)
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message
            ): Boolean {
                // Swallow the popup silently instead of leaving it unhandled -
                // this still counts the ad impression without disrupting the
                // 5-second countdown UI.
                val popup = WebView(this@SplashActivity)
                popup.settings.javaScriptEnabled = true
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }
        }

        webView.loadUrl(AD_PAGE_URL)

        // Background work while the ad is showing: M3U refresh + version check.
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                try {
                    M3uParser.fetch(Prefs.getPlaylistUrl(this@SplashActivity))
                } catch (_: Exception) { /* non-fatal, LiveTvFragment will retry */ }
            }
            try {
                updateInfo = withContext(Dispatchers.IO) { UpdateChecker.checkForUpdate(this@SplashActivity) }
            } catch (_: Exception) { /* non-fatal */ }
        }

        var secondsLeft = 5
        val handler = Handler(Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                if (secondsLeft <= 0) {
                    proceed()
                    return
                }
                countdownText.text = getString(R.string.wait_seconds, secondsLeft)
                secondsLeft -= 1
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(tick)
    }

    private fun proceed() {
        val intent = Intent(this, MainActivity::class.java)
        updateInfo?.let {
            intent.putExtra(MainActivity.EXTRA_UPDATE_TAG, it.tagName)
            intent.putExtra(MainActivity.EXTRA_UPDATE_APK_URL, it.apkUrl)
        }
        startActivity(intent)
        finish()
    }
}
