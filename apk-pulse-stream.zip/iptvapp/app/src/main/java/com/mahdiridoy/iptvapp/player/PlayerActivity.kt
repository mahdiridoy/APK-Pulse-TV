package com.mahdiridoy.iptvapp.player

import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.mahdiridoy.iptvapp.R
import kotlin.math.abs

/**
 * Fullscreen landscape playback for both Live TV and Movies/Series.
 * Gestures: horizontal swipe = change channel/item, vertical swipe on the
 * left half = brightness, vertical swipe on the right half = volume.
 * TV remote: CHANNEL_UP/DOWN (or DPAD_UP/DOWN) changes channel like an
 * analog tuner.
 */
class PlayerActivity : AppCompatActivity() {

    companion object

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var indicatorText: TextView
    private lateinit var trackSelector: DefaultTrackSelector

    private var titles: List<String> = emptyList()
    private var urls: List<String> = emptyList()
    private var currentIndex = 0

    private var audioManager: AudioManager? = null

    // gesture tracking
    private var gestureDownX = 0f
    private var gestureDownY = 0f
    private var gestureMode = 0 // 0=undecided, 1=horizontal(channel), 2=vertical-brightness, 3=vertical-volume
    private var startBrightness = 0.5f
    private var startVolume = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // NOTE: deliberately NOT calling setRequestedOrientation() here. On some
        // Android skins, calling it at runtime throws IllegalStateException
        // ("Only fullscreen activities can request orientation") in a way that
        // can kill the process before any Java exception handler reacts. The
        // manifest's android:screenOrientation="landscape" on this Activity
        // already locks it to landscape - that alone is enough, and it's what
        // the very first working build relied on.

        setContentView(R.layout.activity_player)
        playerView = findViewById(R.id.playerView)
        indicatorText = findViewById(R.id.indicatorText)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        enterFullscreen()

        titles = PlaybackQueue.titles
        urls = PlaybackQueue.urls
        currentIndex = PlaybackQueue.startIndex.coerceIn(0, (urls.size - 1).coerceAtLeast(0))

        if (urls.isEmpty()) {
            finish()
            return
        }

        try {
            trackSelector = DefaultTrackSelector(this)
            val exoPlayer = ExoPlayer.Builder(this).setTrackSelector(trackSelector).build()
            player = exoPlayer
            playerView.player = exoPlayer
            playerView.keepScreenOn = true

            findViewById<View>(R.id.qualityButton)?.setOnClickListener { showQualityDialog() }

            playCurrent()
            setupGestures()
        } catch (e: Exception) {
            Toast.makeText(this, "Playback failed to start: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    // ---- Video quality: Auto (adaptive, default) or a specific rendition ----

    private fun showQualityDialog() {
        val exoPlayer = player ?: return
        val options = mutableListOf<Pair<String, TrackSelectionOverride?>>()
        options.add(getString(R.string.quality_auto) to null)

        for (group in exoPlayer.currentTracks.groups) {
            if (group.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until group.length) {
                if (!group.isTrackSupported(i)) continue
                val format = group.getTrackFormat(i)
                val label = if (format.height > 0) "${format.height}p" else {
                    if (format.bitrate > 0) "${format.bitrate / 1000} kbps" else "Unknown"
                }
                options.add(label to TrackSelectionOverride(group.mediaTrackGroup, i))
            }
        }

        val deduped = options.distinctBy { it.first }
        if (deduped.size <= 1) {
            Toast.makeText(this, R.string.quality_unavailable, Toast.LENGTH_SHORT).show()
            return
        }
        val labels = deduped.map { it.first }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle(R.string.quality_dialog_title)
            .setItems(labels) { _, which ->
                val override = deduped[which].second
                val builder = trackSelector.parameters.buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                if (override != null) {
                    builder.addOverride(override)
                }
                trackSelector.parameters = builder.build()
                Toast.makeText(this, deduped[which].first, Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun enterFullscreen() {
        try {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.insetsController?.let {
                    it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                    it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    )
            }
        } catch (e: Exception) {
            // Fullscreen chrome is cosmetic - never let it take playback down with it.
        }
    }

    private fun playCurrent() {
        val exoPlayer = player ?: return
        val title = titles.getOrNull(currentIndex) ?: ""
        // A quality override from the previous item won't map to this item's
        // renditions - reset to Auto every time we switch.
        trackSelector.parameters = trackSelector.parameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
            .build()
        exoPlayer.setMediaItem(MediaItem.fromUri(urls[currentIndex]))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
        if (title.isNotBlank()) {
            Toast.makeText(this, title, Toast.LENGTH_SHORT).show()
        }
    }

    private fun changeChannel(delta: Int) {
        if (urls.size <= 1) return
        currentIndex = (currentIndex + delta + urls.size) % urls.size
        playCurrent()
    }

    // ---- Touch gestures: swipe horizontal = channel, vertical L/R = brightness/volume ----

    private fun setupGestures() {
        playerView.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    gestureDownX = event.x
                    gestureDownY = event.y
                    gestureMode = 0
                    startBrightness = window.attributes.screenBrightness.let { if (it < 0) 0.5f else it }
                    startVolume = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - gestureDownX
                    val dy = event.y - gestureDownY
                    if (gestureMode == 0 && (abs(dx) > 24 || abs(dy) > 24)) {
                        gestureMode = if (abs(dx) > abs(dy)) 1
                        else if (gestureDownX < view.width / 2f) 2 else 3
                    }
                    when (gestureMode) {
                        2 -> adjustBrightness(-dy / view.height)
                        3 -> adjustVolume(-dy / view.height)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (gestureMode == 1) {
                        val dx = event.x - gestureDownX
                        if (abs(dx) > 80) {
                            if (dx < 0) changeChannel(1) else changeChannel(-1)
                        }
                    }
                    indicatorText.visibility = View.GONE
                    gestureMode = 0
                    view.performClick()
                    true
                }
                else -> false
            }
        }
    }

    private fun adjustBrightness(delta: Float) {
        val newValue = (startBrightness + delta).coerceIn(0.05f, 1f)
        val params = window.attributes
        params.screenBrightness = newValue
        window.attributes = params
        indicatorText.visibility = View.VISIBLE
        indicatorText.text = getString(R.string.brightness_percent, (newValue * 100).toInt())
    }

    private fun adjustVolume(delta: Float) {
        val maxVolume = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 1
        val newVolume = (startVolume + delta * maxVolume).toInt().coerceIn(0, maxVolume)
        audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0)
        indicatorText.visibility = View.VISIBLE
        indicatorText.text = getString(R.string.volume_percent, (newVolume * 100 / maxVolume))
    }

    // ---- TV remote: analog-style channel up/down ----

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_DPAD_UP -> {
                changeChannel(-1)
                return true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_DPAD_DOWN -> {
                changeChannel(1)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
