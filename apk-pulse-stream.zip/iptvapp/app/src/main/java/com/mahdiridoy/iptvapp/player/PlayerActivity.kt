package com.mahdiridoy.iptvapp.player

import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.mahdiridoy.iptvapp.R
import kotlin.math.abs

/**
 * Fullscreen landscape playback for both Live TV and Movies/Series.
 * Gestures: horizontal swipe = change channel/item, vertical swipe on the
 * left half = brightness, vertical swipe on the right half = volume.
 * TV remote: CHANNEL_UP/DOWN (or DPAD_UP/DOWN) changes channel like an
 * analog tuner.
 */
class PlayerActivity : AppCompatActivity() {

    companion object

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var indicatorText: TextView

    private var titles: List<String> = emptyList()
    private var urls: List<String> = emptyList()
    private var currentIndex = 0

    private var audioManager: AudioManager? = null

    // gesture tracking
    private var gestureDownX = 0f
    private var gestureDownY = 0f
    private var gestureMode = 0 // 0=undecided, 1=horizontal(channel), 2=vertical-brightness, 3=vertical-volume
    private var startBrightness = 0.5f
    private var startVolume = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // NOTE: deliberately NOT calling setRequestedOrientation() here. On some
        // Android skins, calling it at runtime throws IllegalStateException
        // ("Only fullscreen activities can request orientation") in a way that
        // can kill the process before any Java exception handler reacts. The
        // manifest's android:screenOrientation="landscape" on this Activity
        // already locks it to landscape - that alone is enough, and it's what
        // the very first working build relied on.

        setContentView(R.layout.activity_player)
        playerView = findViewById(R.id.playerView)
        indicatorText = findViewById(R.id.indicatorText)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        enterFullscreen()

        titles = PlaybackQueue.titles
        urls = PlaybackQueue.urls
        currentIndex = PlaybackQueue.startIndex.coerceIn(0, (urls.size - 1).coerceAtLeast(0))

        if (urls.isEmpty()) {
            finish()
            return
        }

        try {
            val exoPlayer = ExoPlayer.Builder(this).build()
            player = exoPlayer
            playerView.player = exoPlayer
            playerView.keepScreenOn = true

            playCurrent()
            setupGestures()
        } catch (e: Exception) {
            Toast.makeText(this, "Playback failed to start: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun enterFullscreen() {
        try {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.insetsController?.let {
                    it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                    it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    )
            }
        } catch (e: Exception) {
            // Fullscreen chrome is cosmetic - never let it take playback down with it.
        }
    }

    private fun playCurrent() {
        val exoPlayer = player ?: return
        val title = titles.getOrNull(currentIndex) ?: ""
        exoPlayer.setMediaItem(MediaItem.fromUri(urls[currentIndex]))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
        if (title.isNotBlank()) {
            Toast.makeText(this, title, Toast.LENGTH_SHORT).show()
        }
    }

    private fun changeChannel(delta: Int) {
        if (urls.size <= 1) return
        currentIndex = (currentIndex + delta + urls.size) % urls.size
        playCurrent()
    }

    // ---- Touch gestures: swipe horizontal = channel, vertical L/R = brightness/volume ----

    private fun setupGestures() {
        playerView.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    gestureDownX = event.x
                    gestureDownY = event.y
                    gestureMode = 0
                    startBrightness = window.attributes.screenBrightness.let { if (it < 0) 0.5f else it }
                    startVolume = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - gestureDownX
                    val dy = event.y - gestureDownY
                    if (gestureMode == 0 && (abs(dx) > 24 || abs(dy) > 24)) {
                        gestureMode = if (abs(dx) > abs(dy)) 1
                        else if (gestureDownX < view.width / 2f) 2 else 3
                    }
                    when (gestureMode) {
                        2 -> adjustBrightness(-dy / view.height)
                        3 -> adjustVolume(-dy / view.height)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (gestureMode == 1) {
                        val dx = event.x - gestureDownX
                        if (abs(dx) > 80) {
                            if (dx < 0) changeChannel(1) else changeChannel(-1)
                        }
                    }
                    indicatorText.visibility = View.GONE
                    gestureMode = 0
                    view.performClick()
                    true
                }
                else -> false
            }
        }
    }

    private fun adjustBrightness(delta: Float) {
        val newValue = (startBrightness + delta).coerceIn(0.05f, 1f)
        val params = window.attributes
        params.screenBrightness = newValue
        window.attributes = params
        indicatorText.visibility = View.VISIBLE
        indicatorText.text = getString(R.string.brightness_percent, (newValue * 100).toInt())
    }

    private fun adjustVolume(delta: Float) {
        val maxVolume = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 1
        val newVolume = (startVolume + delta * maxVolume).toInt().coerceIn(0, maxVolume)
        audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0)
        indicatorText.visibility = View.VISIBLE
        indicatorText.text = getString(R.string.volume_percent, (newVolume * 100 / maxVolume))
    }

    // ---- TV remote: analog-style channel up/down ----

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_DPAD_UP -> {
                changeChannel(-1)
                return true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_DPAD_DOWN -> {
                changeChannel(1)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
