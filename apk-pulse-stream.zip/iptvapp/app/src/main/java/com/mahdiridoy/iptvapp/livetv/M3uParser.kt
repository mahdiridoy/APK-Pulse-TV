package com.mahdiridoy.iptvapp.livetv

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

/**
 * Fetches and parses the M3U playlist hosted on your GitHub repo.
 * Works with standard #EXTM3U / #EXTINF format, including tvg-logo and
 * group-title attributes commonly produced by your Tv pipeline (ridoyiptv.m3u / output.m3u).
 */
object M3uParser {

    private val client = OkHttpClient()

    private val extInfRegex = Regex(
        "#EXTINF:-?\\d+.*?,(.*)"
    )
    private val logoRegex = Regex("tvg-logo=\"([^\"]*)\"")
    private val groupRegex = Regex("group-title=\"([^\"]*)\"")

    @Throws(IOException::class)
    fun fetch(playlistUrl: String): List<Channel> {
        val request = Request.Builder().url(playlistUrl).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Failed to fetch playlist: HTTP ${response.code}")
            }
            val body = response.body?.string() ?: ""
            return parse(body)
        }
    }

    fun parse(content: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        val lines = content.lines()

        var pendingName: String? = null
        var pendingLogo: String? = null
        var pendingGroup: String = "Uncategorized"

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue

            if (line.startsWith("#EXTINF")) {
                val nameMatch = extInfRegex.find(line)
                pendingName = nameMatch?.groupValues?.get(1)?.trim()?.ifEmpty { "Unknown Channel" }
                    ?: "Unknown Channel"
                pendingLogo = logoRegex.find(line)?.groupValues?.get(1)
                pendingGroup = groupRegex.find(line)?.groupValues?.get(1)?.ifEmpty { "Uncategorized" }
                    ?: "Uncategorized"
            } else if (!line.startsWith("#")) {
                // This is a stream URL line following an #EXTINF
                val name = pendingName ?: continue
                channels.add(Channel(name, pendingLogo, pendingGroup, line))
                pendingName = null
                pendingLogo = null
                pendingGroup = "Uncategorized"
            }
        }
        return channels
    }
}
