package com.mahdiridoy.iptvapp.update

import android.content.Context
import com.mahdiridoy.iptvapp.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * Checks the repo's GitHub Releases (the same ones your build-apk.yml workflow
 * creates) for a tag newer than the currently-installed versionCode.
 *
 * IMPORTANT: set GITHUB_REPO below to "owner/repo", e.g. "mahdiridoy/APK-Pulse-TV".
 */
object UpdateChecker {

    private const val GITHUB_REPO = "mahdiridoy/APK-Pulse-TV" // TODO: set your repo
    private val client = OkHttpClient()

    data class ReleaseInfo(val tagName: String, val apkUrl: String, val runNumber: Int)

    /** Returns release info if a newer build is available, else null. */
    fun checkForUpdate(context: Context): ReleaseInfo? {
        val request = Request.Builder()
            .url("https://api.github.com/repos/$GITHUB_REPO/releases/latest")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val body = response.body?.string() ?: return null
            val json = JSONObject(body)
            val tag = json.optString("tag_name")
            // Tag format from build-apk.yml: v{versionName}-{run_number}, e.g. "v1.1-15"
            val runNumber = tag.substringAfterLast("-").toIntOrNull() ?: return null

            if (runNumber <= BuildConfig.VERSION_CODE) return null

            val assets = json.optJSONArray("assets") ?: return null
            var apkUrl: String? = null
            for (i in 0 until assets.length()) {
                val asset = assets.getJSONObject(i)
                if (asset.optString("name").endsWith(".apk")) {
                    apkUrl = asset.optString("browser_download_url")
                    break
                }
            }
            if (apkUrl == null) return null
            return ReleaseInfo(tag, apkUrl, runNumber)
        }
    }
}
