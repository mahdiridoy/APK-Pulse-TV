package com.mahdiridoy.iptvapp.update

import android.content.Context
import android.util.Log
import com.mahdiridoy.iptvapp.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * Checks the repo's GitHub Releases (the same ones your build-apk.yml workflow
 * creates) for a tag newer than the currently-installed build.
 *
 * IMPORTANT: set GITHUB_REPO below to "owner/repo", e.g. "mahdiridoy/APK-Pulse-TV".
 *
 * Common reasons this silently finds nothing even when you've published a release:
 * - The release was created manually in the GitHub UI as a Draft or Pre-release.
 *   The /releases/latest API endpoint ONLY returns the newest non-draft,
 *   non-prerelease release - drafts/prereleases are invisible to it.
 * - No .apk file was attached to the release as an asset.
 * - The tag doesn't end in "-<number>" (build-apk.yml tags as v{version}-{run
 *   number}; a manually-typed tag like "v1.5" won't parse that way, so this
 *   now falls back to comparing version numbers directly - see isNewerVersion).
 */
object UpdateChecker {

    private const val GITHUB_REPO = "mahdiridoy/APK-Pulse-TV" // TODO: set your repo
    private const val TAG = "UpdateChecker"
    private val client = OkHttpClient()

    data class ReleaseInfo(val tagName: String, val apkUrl: String, val runNumber: Int)

    /** Simple wrapper so callers can see the release/no-update reason for debugging. */
    fun checkForUpdate(context: Context): ReleaseInfo? {
        val (info, reason) = checkForUpdateVerbose()
        Log.d(TAG, reason)
        return info
    }

    /** Same check, but always returns a human-readable reason string alongside the result. */
    fun checkForUpdateVerbose(): Pair<ReleaseInfo?, String> {
        try {
            val request = Request.Builder()
                .url("https://api.github.com/repos/$GITHUB_REPO/releases/latest")
                .header("Accept", "application/vnd.github+json")
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return null to "HTTP ${response.code} from GitHub - check GITHUB_REPO is correct and the repo is public"
                }
                val body = response.body?.string()
                if (body.isNullOrBlank()) return null to "Empty response body"
                val json = JSONObject(body)
                val tag = json.optString("tag_name")
                if (tag.isBlank()) {
                    return null to "No releases found (or all releases are Draft/Pre-release, which /releases/latest ignores)"
                }

                val installedCode = BuildConfig.VERSION_CODE
                val runNumber = tag.substringAfterLast("-").toIntOrNull()

                val assets = json.optJSONArray("assets")
                var apkUrl: String? = null
                if (assets != null) {
                    for (i in 0 until assets.length()) {
                        val asset = assets.getJSONObject(i)
                        if (asset.optString("name").endsWith(".apk")) {
                            apkUrl = asset.optString("browser_download_url")
                            break
                        }
                    }
                }
                if (apkUrl == null) {
                    return null to "Release '$tag' found but has no .apk file attached as an asset"
                }

                val isNewer = if (runNumber != null) {
                    runNumber > installedCode
                } else {
                    // Tag didn't end in "-<number>" (e.g. a manually typed "v1.5") -
                    // fall back to comparing version numbers in the tag directly.
                    isNewerVersionString(tag, BuildConfig.VERSION_NAME)
                }

                return if (isNewer) {
                    ReleaseInfo(tag, apkUrl, runNumber ?: installedCode + 1) to
                        "Update available: '$tag' (installed build code=$installedCode)"
                } else {
                    null to "Up to date: latest release is '$tag', installed build code=$installedCode, installed version=${BuildConfig.VERSION_NAME}"
                }
            }
        } catch (e: Exception) {
            return null to "Update check failed: ${e.message}"
        }
    }

    /** Compares "1.2.3"-style version strings extracted from anywhere in the tag. */
    private fun isNewerVersionString(remoteTag: String, localVersion: String): Boolean {
        val remote = Regex("""\d+(\.\d+)*""").find(remoteTag)?.value ?: return false
        val remoteParts = remote.split(".").map { it.toIntOrNull() ?: 0 }
        val localParts = localVersion.split(".").map { it.toIntOrNull() ?: 0 }
        val maxLen = maxOf(remoteParts.size, localParts.size)
        for (i in 0 until maxLen) {
            val r = remoteParts.getOrElse(i) { 0 }
            val l = localParts.getOrElse(i) { 0 }
            if (r != l) return r > l
        }
        return false
    }
}
