package com.mahdiridoy.iptvapp

/** Implemented by LiveTvFragment and MoviesFragment so the nav rail's Search
 * entry works generically without caring which screen is currently showing. */
interface SearchableFragment {
    fun openSearch()
    fun closeSearch()
    fun isSearchOpen(): Boolean
}
