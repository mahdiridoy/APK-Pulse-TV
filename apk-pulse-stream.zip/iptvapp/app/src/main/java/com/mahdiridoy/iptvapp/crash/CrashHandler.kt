package com.mahdiridoy.iptvapp.crash

import android.content.Context
import android.content.Intent
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import kotlin.system.exitProcess

/**
 * Installed in IPTVApplication.onCreate(). Instead of the app silently dying
 * and dropping you to the home screen (which is what a normal uncaught
 * exception does), this writes the full stack trace to a file and opens
 * CrashActivity so you can actually read/share the error.
 */
class CrashHandler(private val appContext: Context) : Thread.UncaughtExceptionHandler {

    private val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        try {
            val sw = StringWriter()
            throwable.printStackTrace(PrintWriter(sw))
            val trace = sw.toString()

            val logFile = File(appContext.getExternalFilesDir(null), "crash_log.txt")
            logFile.writeText(trace)

            val intent = Intent(appContext, CrashActivity::class.java).apply {
                putExtra(CrashActivity.EXTRA_TRACE, trace)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }
            appContext.startActivity(intent)
        } catch (e: Exception) {
            // If even the crash handler fails, fall back to the default behavior.
        } finally {
            android.os.Process.killProcess(android.os.Process.myPid())
            exitProcess(1)
        }
    }
}
