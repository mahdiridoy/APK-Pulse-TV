package com.mahdiridoy.iptvapp.livetv

/**
 * A single entry parsed from an M3U/M3U8 playlist (#EXTINF line + URL).
 */
data class Channel(
    val name: String,
    val logoUrl: String?,
    val group: String,
    val streamUrl: String
)
