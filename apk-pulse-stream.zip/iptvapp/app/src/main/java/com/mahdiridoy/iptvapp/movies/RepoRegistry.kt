package com.mahdiridoy.iptvapp.movies

/**
 * Built-in, non-editable-by-user list of Movies & Series repositories.
 * Add your own repo manifest URLs here - no in-app "add repo" UI by design.
 */
object RepoRegistry {
    val repos: List<Repo> = listOf(
        Repo(
            name = "Sample Movies Repo",
            manifestUrl = "https://raw.githubusercontent.com/mahdiridoy/movie-repos/main/movies.json"
        ),
        Repo(
            name = "Sample Series Repo",
            manifestUrl = "https://raw.githubusercontent.com/mahdiridoy/movie-repos/main/series.json"
        )
        // Add more repos here, same pattern.
    )
}
