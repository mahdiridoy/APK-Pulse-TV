package com.mahdiridoy.iptvapp.player

/**
 * Holds the current playback list in memory instead of passing it through Intent
 * extras. Large M3U playlists (hundreds/thousands of channels) blow past Android's
 * Binder transaction size limit if put in an Intent, which crashes the app the
 * moment you tap a channel. Since PlayerActivity always launches from the same
 * process, a simple in-memory singleton avoids that entirely.
 */
object PlaybackQueue {
    var titles: List<String> = emptyList()
    var urls: List<String> = emptyList()
    var startIndex: Int = 0

    fun set(titles: List<String>, urls: List<String>, startIndex: Int) {
        this.titles = titles
        this.urls = urls
        this.startIndex = startIndex
    }
}
