package com.mahdiridoy.iptvapp.livetv

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.mahdiridoy.iptvapp.SearchableFragment
import com.mahdiridoy.iptvapp.databinding.FragmentLiveTvBinding
import com.mahdiridoy.iptvapp.player.PlaybackQueue
import com.mahdiridoy.iptvapp.player.PlayerActivity
import com.mahdiridoy.iptvapp.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LiveTvFragment : Fragment(), SearchableFragment {

    private var _binding: FragmentLiveTvBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: ChannelAdapter
    private lateinit var searchAdapter: ChannelAdapter
    private var allChannels: List<Channel> = emptyList()
    private var searchVisible = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLiveTvBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val openPlayer = { list: List<Channel>, index: Int ->
            PlaybackQueue.set(list.map { it.name }, list.map { it.streamUrl }, index)
            startActivity(Intent(requireContext(), PlayerActivity::class.java))
        }

        adapter = ChannelAdapter(emptyList()) { channel ->
            val index = allChannels.indexOf(channel).coerceAtLeast(0)
            openPlayer(allChannels, index)
        }

        val spanCount = if (resources.configuration.screenWidthDp > 600) 5 else 3
        binding.channelGrid.layoutManager = GridLayoutManager(requireContext(), spanCount)
        binding.channelGrid.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadPlaylist() }

        setupSearch(openPlayer)
        loadPlaylist()
    }

    /**
     * Always re-fetches the M3U from your GitHub URL. Since you commit a fresh
     * playlist daily via your Tv pipeline, this keeps the app in sync every
     * time Live TV opens or on pull-to-refresh.
     */
    private fun loadPlaylist() {
        binding.swipeRefresh.isRefreshing = true
        val url = Prefs.getPlaylistUrl(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val channels = withContext(Dispatchers.IO) { M3uParser.fetch(url) }
                allChannels = channels
                adapter.updateData(channels)
                binding.emptyState.visibility = if (channels.isEmpty()) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Couldn't load playlist: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                binding.emptyState.visibility = if (allChannels.isEmpty()) View.VISIBLE else View.GONE
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    // ---- Channel search: results are channels only, never movies/series ----

    private fun setupSearch(openPlayer: (List<Channel>, Int) -> Unit) {
        var filtered: List<Channel> = emptyList()
        searchAdapter = ChannelAdapter(emptyList()) { channel ->
            val index = filtered.indexOf(channel).coerceAtLeast(0)
            openPlayer(filtered, index)
        }
        binding.searchResults.layoutManager = LinearLayoutManager(requireContext())
        binding.searchResults.adapter = searchAdapter
        binding.searchClose.setOnClickListener { closeSearch() }

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                val query = s?.toString()?.trim().orEmpty()
                filtered = if (query.isEmpty()) emptyList()
                else allChannels.filter { it.name.contains(query, ignoreCase = true) }
                searchAdapter.updateData(filtered)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun openSearch() {
        if (searchVisible) return
        searchVisible = true
        binding.searchPanel.visibility = View.VISIBLE
        binding.searchPanel.animate().translationX(0f).setDuration(200).start()
        binding.searchInput.requestFocus()
    }

    override fun closeSearch() {
        if (!searchVisible) return
        searchVisible = false
        binding.searchPanel.animate()
            .translationX(binding.searchPanel.width.toFloat())
            .setDuration(200)
            .withEndAction { binding.searchPanel.visibility = View.INVISIBLE }
            .start()
        binding.searchInput.setText("")
    }

    override fun isSearchOpen(): Boolean = searchVisible

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
