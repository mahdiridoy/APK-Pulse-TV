package com.mahdiridoy.iptvapp.update

import com.mahdiridoy.iptvapp.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * Checks a public Google Drive folder for an APK named like "APKPULSEv1.8.apk"
 * and compares its version number against the installed app.
 *
 * SETUP REQUIRED (Google's Drive API needs a key even for public read access):
 * 1. https://console.cloud.google.com -> create/select a project.
 * 2. APIs & Services -> Library -> enable "Google Drive API".
 * 3. APIs & Services -> Credentials -> Create Credentials -> API key.
 *    Restrict it to "Google Drive API" only (safer, since this key ships
 *    inside the APK and is technically extractable).
 * 4. Paste that key into API_KEY below.
 * 5. Make sure the Drive folder is shared as "Anyone with the link - Viewer".
 *
 * File naming: only files matching "...v<version>.apk" are considered, e.g.
 * "APKPULSEv1.8.apk" -> version "1.8". The highest version found wins.
 */
object DriveUpdateChecker {

    private const val API_KEY = "AIzaSyCpTABgrtUvgOLEuxGUqD1Ku8AEN0Ec6bU"
    private const val FOLDER_ID = "1o1LefE_2Z5s-CAv-xm5rsKADT1sCZG9A"

    private val client = OkHttpClient()
    private val versionRegex = Regex("""v(\d+(?:\.\d+)*)\.apk$""", RegexOption.IGNORE_CASE)

    data class DriveUpdateInfo(val fileName: String, val version: String, val downloadUrl: String)

    /** Always returns a human-readable reason alongside the result, for debugging. */
    fun checkForUpdateVerbose(): Pair<DriveUpdateInfo?, String> {
        if (API_KEY == "YOUR_GOOGLE_DRIVE_API_KEY") {
            return null to "Drive update check not configured - set API_KEY in DriveUpdateChecker.kt"
        }
        try {
            val url = "https://www.googleapis.com/drive/v3/files" +
                "?q='$FOLDER_ID'+in+parents+and+trashed=false" +
                "&fields=files(id,name)" +
                "&key=$API_KEY"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return null to "Drive API error: HTTP ${response.code}. Check the API key is valid, " +
                        "the Drive API is enabled, and the folder is shared as 'Anyone with the link'."
                }
                val body = response.body?.string()
                if (body.isNullOrBlank()) return null to "Empty response from Drive"
                val json = JSONObject(body)
                val files = json.optJSONArray("files")
                if (files == null || files.length() == 0) {
                    return null to "No files found in the Drive folder"
                }

                var best: DriveUpdateInfo? = null
                var bestParts: List<Int> = emptyList()

                for (i in 0 until files.length()) {
                    val file = files.getJSONObject(i)
                    val name = file.optString("name")
                    val id = file.optString("id")
                    val match = versionRegex.find(name) ?: continue
                    val versionStr = match.groupValues[1]
                    val parts = versionStr.split(".").map { it.toIntOrNull() ?: 0 }
                    if (best == null || compareVersions(parts, bestParts) > 0) {
                        best = DriveUpdateInfo(
                            fileName = name,
                            version = versionStr,
                            downloadUrl = "https://drive.google.com/uc?export=download&id=$id"
                        )
                        bestParts = parts
                    }
                }

                if (best == null) {
                    return null to "Files found in Drive folder, but none matched the " +
                        "'<name>v<version>.apk' naming pattern (e.g. APKPULSEv1.8.apk)"
                }

                val installedParts = BuildConfig.VERSION_NAME.split(".").map { it.toIntOrNull() ?: 0 }
                return if (compareVersions(bestParts, installedParts) > 0) {
                    best to "Update available: ${best.fileName} (installed v${BuildConfig.VERSION_NAME})"
                } else {
                    null to "Up to date: latest on Drive is v${best.version}, installed v${BuildConfig.VERSION_NAME}"
                }
            }
        } catch (e: Exception) {
            return null to "Drive update check failed: ${e.message}"
        }
    }

    private fun compareVersions(a: List<Int>, b: List<Int>): Int {
        val len = maxOf(a.size, b.size)
        for (i in 0 until len) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x - y
        }
        return 0
    }
}
