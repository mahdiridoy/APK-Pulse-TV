package com.mahdiridoy.iptvapp.movies

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.mahdiridoy.iptvapp.databinding.FragmentMoviesBinding
import com.mahdiridoy.iptvapp.player.PlayerActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MoviesFragment : Fragment() {

    private var _binding: FragmentMoviesBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: MovieItemAdapter
    private lateinit var searchAdapter: MovieItemAdapter
    private var currentItems: List<MovieItem> = emptyList()
    private var searchVisible = false
    private var gridSpanCount = 3

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMoviesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val openPlayer = { list: List<MovieItem>, index: Int ->
            val intent = Intent(requireContext(), PlayerActivity::class.java)
            intent.putStringArrayListExtra(PlayerActivity.EXTRA_TITLES, ArrayList(list.map { it.title }))
            intent.putStringArrayListExtra(PlayerActivity.EXTRA_URLS, ArrayList(list.map { it.streamUrl }))
            intent.putExtra(PlayerActivity.EXTRA_START_INDEX, index)
            startActivity(intent)
        }

        adapter = MovieItemAdapter(emptyList()) { item ->
            val index = currentItems.indexOf(item).coerceAtLeast(0)
            openPlayer(currentItems, index)
        }

        gridSpanCount = if (resources.configuration.screenWidthDp > 600) 5 else 3
        binding.movieGrid.layoutManager = GridLayoutManager(requireContext(), gridSpanCount)
        binding.movieGrid.adapter = adapter

        buildRepoButtons()
        setupSearch(openPlayer)

        RepoRegistry.repos.firstOrNull()?.let { loadRepo(it) }
    }

    private fun buildRepoButtons() {
        binding.repoButtonRow.removeAllViews()
        RepoRegistry.repos.forEach { repo ->
            val button = Button(requireContext()).apply {
                text = repo.name
                isFocusable = true
                isFocusableInTouchMode = true
                setOnClickListener { loadRepo(repo) }
            }
            binding.repoButtonRow.addView(button)
        }
    }

    private fun loadRepo(repo: Repo) {
        binding.moviesEmptyState.visibility = View.GONE
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val items = withContext(Dispatchers.IO) { RepoRepository.fetchItems(repo) }
                currentItems = items
                adapter.updateData(items)
                binding.moviesEmptyState.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Couldn't load ${repo.name}: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                binding.moviesEmptyState.visibility = View.VISIBLE
            }
        }
    }

    // ---- Movie/series search: slides in from the right; results scoped to the
    // currently loaded repo's items only, never Live TV channels ----

    private fun setupSearch(openPlayer: (List<MovieItem>, Int) -> Unit) {
        var filtered: List<MovieItem> = emptyList()
        searchAdapter = MovieItemAdapter(emptyList()) { item ->
            val index = filtered.indexOf(item).coerceAtLeast(0)
            openPlayer(filtered, index)
        }
        binding.searchResults.layoutManager = LinearLayoutManager(requireContext())
        binding.searchResults.adapter = searchAdapter

        binding.searchTrigger.setOnClickListener { showSearch() }
        binding.searchTrigger.setOnFocusChangeListener { _, hasFocus -> if (hasFocus) showSearch() }

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                val query = s?.toString()?.trim().orEmpty()
                filtered = if (query.isEmpty()) emptyList()
                else currentItems.filter { it.title.contains(query, ignoreCase = true) }
                searchAdapter.updateData(filtered)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.movieGrid.setOnKeyListener { _, keyCode, event ->
            if (event.action == android.view.KeyEvent.ACTION_DOWN &&
                keyCode == android.view.KeyEvent.KEYCODE_DPAD_RIGHT
            ) {
                val focusedPos = binding.movieGrid.focusedChild?.let {
                    binding.movieGrid.getChildAdapterPosition(it)
                }
                if (focusedPos != null && (focusedPos + 1) % gridSpanCount == 0) {
                    binding.searchTrigger.requestFocus()
                    return@setOnKeyListener true
                }
            }
            false
        }
    }

    private fun showSearch() {
        if (searchVisible) return
        searchVisible = true
        binding.searchPanel.animate().translationX(0f).setDuration(200).start()
        binding.searchInput.requestFocus()
    }

    private fun hideSearch() {
        if (!searchVisible) return
        searchVisible = false
        binding.searchPanel.animate().translationX(binding.searchPanel.width.toFloat()).setDuration(200).start()
        binding.searchInput.setText("")
    }

    fun isSearchOpen(): Boolean = searchVisible
    fun closeSearch() = hideSearch()

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
