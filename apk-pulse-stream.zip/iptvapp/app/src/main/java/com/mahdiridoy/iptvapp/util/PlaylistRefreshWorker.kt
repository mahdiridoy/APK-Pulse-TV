package com.mahdiridoy.iptvapp.util

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * Periodically HEADs the GitHub-hosted M3U URL and compares ETag so the app
 * knows a fresh playlist is available (your Tv pipeline commits a new file daily).
 * LiveTvFragment re-fetches the full list whenever this detects a change.
 */
class PlaylistRefreshWorker(context: Context, params: WorkerParameters) :
    CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val url = Prefs.getPlaylistUrl(applicationContext)
            val client = OkHttpClient()
            val request = Request.Builder().url(url).head().build()
            client.newCall(request).execute().use { response ->
                val newEtag = response.header("ETag")
                val oldEtag = Prefs.getLastEtag(applicationContext)
                if (newEtag != null && newEtag != oldEtag) {
                    Prefs.setLastEtag(applicationContext, newEtag)
                }
            }
            Prefs.setLastFetchTime(applicationContext, System.currentTimeMillis())
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
