# APK Pulse Stream — Android + Android TV App

Single codebase, works on phone (portrait UI) and Android TV (D-pad navigable).

## What's included

- **Live TV**: pulls `https://mahdiridoy.github.io/Tv/mahdi_iptv.m3u8`, re-fetches on open and
  pull-to-refresh, plus a background check every 6 hours. Configured in
  `app/src/main/java/com/mahdiridoy/iptvapp/util/Prefs.kt`.
- **Movies & Series**: built-in repo list (`movies/RepoRegistry.kt`) pointing at JSON manifests
  you host yourself:
  ```json
  [
    { "title": "Movie Name", "poster": "https://.../poster.jpg", "streamUrl": "https://.../stream.m3u8" }
  ]
  ```
  Add manifest URLs to `RepoRegistry.repos`. No in-app "add repo" UI, as requested. (Does not
  include a Cloudstream `.cs3` plugin loader or MovieBox API integration — see note at the
  bottom.)
- **Orientation**: phone stays portrait everywhere except the player, which forces fullscreen
  landscape the moment you open a channel/movie. Android TV is left at its native fixed display.
- **Playback gestures** (`player/PlayerActivity.kt`): swipe left/right to change
  channel/item; on the left half, swipe up/down for brightness; on the right half, swipe
  up/down for volume. On a TV remote, CHANNEL UP/DOWN (or D-pad UP/DOWN) changes the
  channel like an analog tuner.
- **Auto-hiding nav rail** (`MainActivity.kt`): Live TV / Movies & Series are hidden by default.
  On phone, swipe left-to-right from the very left edge to reveal it, tap elsewhere to hide it.
  On TV, press D-pad LEFT while already at the leftmost grid item to pop it out; press LEFT
  again or BACK to hide it.
- **Channel/movie search**: a search icon in the top-right of each screen slides a panel in
  from the right. On TV, pressing D-pad RIGHT past the last column jumps focus there
  automatically. Live TV search only searches channels; Movies & Series search only searches
  the currently loaded repo's items — the two never mix.
- **Startup ad + freshness check** (`splash/SplashActivity.kt`): every cold start shows a 5-second
  ad screen with a "please wait" countdown. During those 5 seconds the app refreshes the M3U
  and checks GitHub for a newer app version in the background, then moves on to Live TV
  automatically. The ad only ever shows here — never mid-session.
- **Self-update** (`update/UpdateChecker.kt`, `update/UpdateManager.kt`): checks
  `github.com/<repo>/releases/latest` for a newer build. If found, `MainActivity` shows an
  "Update available" dialog; tapping **Update Now** downloads the APK and opens Android's
  installer. Android still requires you to tap through its final "Install unknown app" /
  "Install" confirmation — no app can silently self-install without that, it's an OS security
  requirement, not something this app is choosing to add.
- App icon, round icon, and TV banner are generated from your uploaded APK Pulse logo.

## Before you build

- **Set your repo** in `update/UpdateChecker.kt` → `GITHUB_REPO` (currently
  `"mahdiridoy/APK-Pulse-TV"` — update if different).
- **Movies & Series repos**: add your manifest URLs to `movies/RepoRegistry.kt` whenever
  you're ready. Cloudstream repo URLs go here only in the sense that if you build your own
  manifest in the JSON format above, you can point at it the same way — the app will not
  install `.cs3` plugin binaries or scrape MovieBox itself.

## Getting the APK

Push this project to your GitHub repo. `.github/workflows/build-apk.yml`:
1. builds a debug APK on every push to `main`,
2. uploads it as a workflow **Artifact** (always, even if the release step fails),
3. creates a GitHub **Release** tagged with your app's real version
   (`v{versionName}-{run_number}`, e.g. `v1.1-15`) and attaches the APK — this is what
   `UpdateChecker` polls, and what powers the in-app self-update flow.

If you uploaded the project as a zip instead of unzipping it locally, the workflow finds and
unzips it automatically before building.

## To customize

- M3U URL: `util/Prefs.kt` → `DEFAULT_M3U_URL`
- Movies & Series repos: `movies/RepoRegistry.kt`
- GitHub repo for update checks: `update/UpdateChecker.kt` → `GITHUB_REPO`
- Ad zone/script: `splash/SplashActivity.kt` → `adHtml`
- App name/colors: `res/values/strings.xml`, `res/values/colors.xml`
- App icon/banner: regenerate from a new image into `res/mipmap-*/ic_launcher.png` and
  `res/drawable-nodpi/tv_banner.png`

## Not included (on purpose)

Movies & Series does not include a Cloudstream plugin loader or MovieBox API integration —
those exist specifically to pull unauthorized copies of copyrighted movies/shows. The
manifest-based repo system above is the extension point; what you put in your own JSON
manifests is up to you.
