# Changelog

## 1.0.0.6 - Fixed the AGP 9 "built-in Kotlin" break

Second real build attempt failed at plugin-application time, before any compilation:

```
An exception occurred applying plugin request [id: 'org.jetbrains.kotlin.android']
> Failed to apply plugin 'org.jetbrains.kotlin.android'.
   > The 'org.jetbrains.kotlin.android' plugin is no longer required for Kotlin
     support since AGP 9.0.
     Solution: Remove the 'org.jetbrains.kotlin.android' plugin from this project's
     build file: app/build.gradle.kts.
```

A real, documented AGP 9 breaking change, not a version-number problem this time:
AGP 9.0+ builds Kotlin support directly into `com.android.application` ("built-in
Kotlin") - applying `org.jetbrains.kotlin.android` alongside it now hard-fails instead
of just being redundant, so the 1.0.0.5 bump to AGP 9.1.1 needed this follow-up.

- **`app/build.gradle.kts`**: removed `id("org.jetbrains.kotlin.android")` from the
  plugins block. `org.jetbrains.kotlin.plugin.compose` and `com.google.devtools.ksp`
  stay - only `kotlin.android` is incompatible with built-in Kotlin (KSP added its own
  built-in-Kotlin support back in KSP 2.3.1, already covered by the 2.3.5 pin from
  1.0.0.5).
- **`android { kotlinOptions { jvmTarget = "17" } }`** → top-level **`kotlin {
  compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }`** - `android.kotlinOptions{}`
  no longer resolves once `kotlin.android` isn't applied; this is the DSL AGP 9's
  built-in Kotlin migration guide replaces it with.
- **Root `build.gradle.kts`**: built-in Kotlin bundles Kotlin Gradle Plugin 2.2.10 by
  default - older than the 2.4.0 CloudStream's `:library` was actually compiled with
  (the whole reason 1.0.0.5 pinned Kotlin to 2.4.0 in the first place). Added
  `buildscript { dependencies { classpath("org.jetbrains.kotlin:kotlin-gradle-
  plugin:2.4.0") } }` - the officially documented override for exactly this, so 2.4.0
  is still what's actually used even without the removed plugin declaring it.

## 1.0.0.5 - Fixed the real build failure from CI

First actual build attempt (thank you for the logs) failed at `:app:checkDebugAarMetadata`:

```
Dependency 'com.github.recloudstream.cloudstream:library-android:-SNAPSHOT' requires
libraries and applications that depend on it to compile against version 37 or later of
the Android APIs. :app is currently compiled against android-36. Also, the maximum
recommended compile SDK version for Android Gradle plugin 8.5.0 is 34.
```

Exactly the version-matrix risk flagged (but not yet fixed) in 1.0.0.4's changelog.
Fixed by bumping the whole toolchain to a matched, verified set rather than nudging one
number at a time into more of the same error:

- **AGP**: 8.5.0 -> 9.1.1 (max compileSdk 34 -> 37; also CloudStream's own upstream AGP
  version, a known-working pairing rather than a guess)
- **Gradle wrapper**: 8.7 -> 9.1.0 (AGP 9.1.1's documented minimum - "a hard requirement
  that cannot be bypassed" per its own release notes)
- **Kotlin**: 1.9.24 -> 2.4.0 (matches what `:library` was actually compiled with, to
  avoid a "compiled with a newer version of Kotlin" metadata error)
- **KSP**: 1.9.24-1.0.20 -> 2.3.5 (KSP versioning decoupled from the Kotlin version it
  pairs with as of KSP 2.3.0; 2.3.5 is confirmed to support Kotlin 2.4.0+)
- **compileSdk/targetSdk**: 36/36 -> 37/36, matching CloudStream's own working pair
  exactly instead of guessing a nearby one
- **Compose**: migrated off `composeOptions.kotlinCompilerExtensionVersion` (removed in
  Kotlin 2.0+) onto the `org.jetbrains.kotlin.plugin.compose` Gradle plugin; bumped
  compose-bom 2024.10.01 -> 2026.04.01 to match

**If the next build fails on Android SDK Platform 37 not being installed** (a separate
concern from the Gradle-side version numbers above - the CI runner's SDK
installation/licensing step isn't in this zip, since it lives in your
`.github/workflows/*.yml`, not the app project), that step needs
`sdkmanager "platforms;android-37"` (or equivalent) added - send me that workflow file
if so and I'll fix it directly instead of guessing at it blind.

## 1.0.0.4 - Real CloudStream plugin engine

Adds the actual thing `.cs3` files need to run, verified directly against
CloudStream's own source (recloudstream/cloudstream) rather than guessed:

- **`app/build.gradle.kts` / `settings.gradle.kts`**: depends on CloudStream's real
  `:library` module via JitPack (`com.github.recloudstream.cloudstream:library:-SNAPSHOT`).
  Confirmed by reading the actual source that this one module contains everything a
  plugin needs at runtime - `MainAPI`, `APIHolder`, `ExtractorLink`, `BasePlugin`/`Plugin`,
  every built-in extractor (DoodStream, StreamTape-style hosts, etc.), and all of their
  own dependencies (nicehttp, jsoup, jackson, rhino) - so this one dependency line is
  genuinely sufficient.
- **`plugins/CloudStreamPluginManager.kt`** (new): loads a `.cs3` file for real - a
  direct port of the loading half of CloudStream's own `PluginManager.loadPlugin()`
  (`PathClassLoader` pointed at the file, read `manifest.json` for `pluginClassName`,
  reflectively instantiate, call `.load(context)`). Registered `MainAPI` instances land
  in CloudStream's own `APIHolder.allProviders` - not a reimplemented registry.
- **`plugins/CloudStreamBridge.kt`** (new): `search()` across all loaded plugins,
  `resolveMovieQualities()`/`resolveSeriesEpisodes()`/`resolveEpisodeQualities()` -
  calls straight into each provider's real `search()`/`load()`/`loadLinks()`.
- **`plugins/InstalledPluginStore.kt`** (new): remembers which `.cs3` files are
  installed so they reload on the next app launch (`SplashActivity` now calls
  `CloudStreamPluginManager.reloadInstalledPlugins()` alongside the M3U catalog sync) -
  replaces the old `ProviderRegistry`/`InstalledProvider`, which stored a single
  fabricated "downloadUrl" per provider as if a whole plugin were one direct video link.
- **`RepoRepository.installPlugin()`**: now actually loads the downloaded `.cs3`
  through the real engine instead of just recording its own URL as a fake stream.
- **`MoviesSeriesViewModel`/`MoviesSeriesScreen`**: search now also queries any
  installed plugin live and shows results in a "From your installed plugins" row;
  tapping one resolves real playable links through that provider and plays them.
- **`Quality`/`PlaybackQueue`/`PlayerActivity`**: `Quality` now carries per-link
  headers (Referer etc. - many extractors need their own exact value, not just a
  generic browser UA), threaded through to ExoPlayer's request interceptor.
- **`LICENSE`/`NOTICE.md`** (new): depending on CloudStream's library makes this app
  a derivative work under **GPL-3.0** - see NOTICE.md for what that actually requires
  (this app's source must be made available under GPL-3.0 to anyone the APK is given
  to). This was an explicit, accepted tradeoff for getting real plugin support, not a
  side effect to discover later.

**Known gaps in this pass, worth knowing about**: plugin-backed series only auto-play
their first episode (no full episode list UI yet); a provider's `getMainPage()`
browsing isn't wired in, only `search()`; subtitles from `loadLinks()` aren't hooked
up; and none of this has been build-tested against a real device/CI yet - "-SNAPSHOT"
also means the JitPack dependency isn't pinned, worth locking to a specific commit
once a build succeeds.

## 1.0.0.3

### 1. Movies & Series: nothing ever loaded ("still syncing" forever)
- Root cause: `MoviesSeriesScreen`/`MoviesSeriesViewModel` had been switched to read from `RepoRegistry`/`RepoRepository` (the CloudStream `.cs3` plugin path) instead of the Room/Paging3 catalog. A `.cs3` file is a compiled CloudStream plugin (bytecode meant to run inside CloudStream's own plugin-loading engine), not a JSON list of movies - `RepoRepository.readPackageItems` never finds a real manifest inside one, so it always returned an empty list regardless of network status.
- Fix: `MoviesSeriesScreen`/`MoviesSeriesViewModel` now page directly from Room again (`CatalogDao.pagingSource`/`searchPagingSource`), which `CatalogSyncManager` was already keeping in sync from `SplashActivity` on every launch the whole time - the sync pipeline itself was never broken, only the screen reading from it. Pull-to-refresh now forces `CatalogSyncManager.sync(forceRefresh = true)` directly instead of re-fetching the CloudStream repo.
- `RepoRegistry`/`RepoRepository`/`ProviderRegistry` are left in place (still used by `CatalogPlayback` as a per-item install/playback fallback) but no longer drive the grid.

### 2. Live TV logos not loading for most channels
- Added a `Referer` header (set to the logo URL's own origin) alongside the existing `User-Agent` header in `IPTVApplication`'s image `OkHttpClient` - some CDNs hotlink-block on Referer even with a valid User-Agent present. Channels whose M3U entry has no `tvg-logo` attribute at all still show the placeholder icon - that's a data gap in the source playlist, not something the app can fix on its own.

## 1.0.0.1

### 1. Movie & Series source URL
- Replaced everywhere: `https://huggingface.co/datasets/mahdirid/ridoymovieserver/resolve/main/ridoymovieserver.m3u`
- Removed every reference to the previous URL (the GitHub release asset link). Now defined in exactly one place: `CatalogSyncManager.M3U_CATALOG_URL`.

### 2. Movies & Series: full pipeline rebuilt around Room + Paging3

**The problem this fixes:** the old pipeline downloaded the *entire* ~38MB/134k-entry M3U into one in-memory `String`, parsed all of it into an in-memory `List`, and did this **on every single app launch** - no caching, no pagination, blocking whatever screen needed it until the whole thing finished.

**What changed:**

- **New local database (`catalog.db`, separate from the existing favorites/history database - zero migration risk to either)**: two Room tables per the requested structure -
  - `movies` (id, title, logo, group_name, url, tvg_id) - indexed on `title` and `group_name`
  - `series_episodes` (id, title, logo, group_name, url, show_title, season, episode) - indexed on `show_title`, `group_name`, `season`
  - A `browse_tiles` database view unions both into what the grid actually displays: every movie, plus **one** aggregated row per distinct show (episode count instead of one row per episode) - so a series with 300 episodes still costs exactly one row in the paged grid, same as a single movie.

- **True streaming parse (`CatalogSyncManager.sync`)**: the HTTP response body is read through a `BufferedReader.lineSequence()` and classified line-by-line as it arrives - at no point does the full file exist as one `String` or `List` in memory. Rows are batched (1,000 at a time) and upserted into Room as each batch fills, then the batch buffer is cleared and reused - memory use stays flat regardless of whether the file has 1,000 or 1,000,000 entries.

- **HTTP ETag / Last-Modified conditional requests**: the last successful sync's `ETag`/`Last-Modified` response headers are persisted (SharedPreferences) and sent back as `If-None-Match`/`If-Modified-Since` on the next sync. A `304 Not Modified` response skips the download, the parse, and every database write entirely - this is what "only redownload when the playlist changes" means at the protocol level, not just an app-side heuristic.

- **GZIP**: handled automatically by OkHttp (it requests and transparently decodes `Content-Encoding: gzip` whenever the server offers it) - no extra code needed, and nothing here overrides that default behavior.

- **"Atomic" replace, honestly described**: this is a mark-and-sweep upsert, not a literal file-level database swap. Every row touched during a sync pass gets a fresh `last_synced_at` timestamp; once the full pass completes, anything with an *older* timestamp (i.e. genuinely removed from the remote file) is deleted in one final pass. Practical effect is the same as a true atomic swap - readers never see an empty or partially-cleared table at any point, and the end state always matches the new file exactly - it's just achieved by updating rows in place throughout rather than by swapping two on-disk files.

- **Startup flow, old vs. new:**
  - Old: open app → download 38MB → parse 134k entries in memory → *then* show Movies & Series.
  - New: open app → Room already has whatever was there last time → Movies & Series opens **instantly** reading local SQLite → sync (steps above) runs in the background, and the Paging3 + Room integration auto-invalidates the grid as new/changed rows land, so content fills in progressively without the user ever waiting on it or the UI freezing.

- **Paging3, not an in-memory list**: `MoviesSeriesViewModel` exposes `Flow<PagingData<BrowseTileRow>>` via Room's own `PagingSource` (from the new `room-paging` dependency); the grid (`MoviesSeriesScreen`) collects it with `collectAsLazyPagingItems()`. Only a handful of pages are ever held in memory, whether the table has 100 rows or 130,000. Search re-queries the same way (`WHERE title LIKE ...`, using the `title` index), scoped only to this screen.

- **Pull-to-refresh** now triggers a real network re-sync (`forceRefresh = true`, bypassing the ETag check) instead of just re-reading the same local cache.

- **Series auto-play preserved**: tapping a series still queues every episode, in season/episode order, and the player still auto-advances through them (`PlayerActivity`'s `STATE_ENDED` handling, unchanged) - now sourced from a fast indexed Room query (`episodesForShow`) instead of an in-memory list built by re-parsing the whole file.

### 3. Where things now play from
- **Home's featured row** and **Favorites** (Movies/Series entries) now play directly via a new shared `CatalogPlayback` helper, which looks the item up fresh from Room by id/title/type - both used to route through `movie_detail`/`series_detail` pages backed by the *old* JSON-manifest system, which no longer knows about the M3U catalog now that it lives in Room. A favorited series still rebuilds its full episode queue on tap (not just replaying whichever single episode happened to be playing when it was favorited).
- **Live TV, the player, Settings, channel logos, and the existing UI/theme are untouched** - this update only touches the Movies & Series data path.
- `movie_detail`/`series_detail` routes and their ViewModels (`MoviesViewModel`, `SeriesViewModel`) are left in place but are no longer reachable from anywhere in the app's navigation - kept for reference rather than removed outright, since deleting them added no benefit and some risk.

### 4. Code quality
- `M3uParser` refactored: the EXTINF/tvg-attribute regex logic now lives in exactly one place (`parseExtinfLine`), shared by Live TV's existing in-memory `parse()`/`fetch()` (unchanged behavior - Live TV's playlist is small, no benefit to streaming it) and the new streaming `streamEntries()` used by `CatalogSyncManager`. Previously this logic existed twice.
- `CatalogRepository` trimmed back to only the original JSON-manifest fetching it was built for; the M3U-specific fetching/splitting logic that had accumulated there moved to `CatalogSyncManager`, where it belongs alongside the rest of the sync pipeline.

### 5. Version
- `versionName` → `1.0.0.1`
- `versionCode` continues to auto-increment on every CI build (unchanged mechanism - total commit count, see `build-apk.yml`/`build.gradle.kts`), already satisfying "increment by 1 every build" without a manual bump.

### Honest notes on scope
- Adapter-level `DiffUtil`/`RecyclerView` optimizations weren't applicable here since Movies & Series is a Compose screen (`LazyVerticalGrid`), not a `RecyclerView` - Paging3's Compose integration provides the equivalent diffing/recycling behavior natively.
- New dependencies added: `androidx.room:room-paging:2.6.1` (Room's Paging3 query support), `androidx.paging:paging-runtime-ktx:3.2.1`, `androidx.paging:paging-compose:3.2.1` - versions checked for compatibility with the project's existing Room 2.6.1 rather than assumed.
