# Changelog

## 1.0.0.1

### 1. Movie & Series source URL
- Replaced everywhere: `https://huggingface.co/datasets/mahdirid/ridoymovieserver/resolve/main/ridoymovieserver.m3u`
- Removed every reference to the previous URL (the GitHub release asset link). Now defined in exactly one place: `CatalogSyncManager.M3U_CATALOG_URL`.

### 2. Movies & Series: full pipeline rebuilt around Room + Paging3

**The problem this fixes:** the old pipeline downloaded the *entire* ~38MB/134k-entry M3U into one in-memory `String`, parsed all of it into an in-memory `List`, and did this **on every single app launch** - no caching, no pagination, blocking whatever screen needed it until the whole thing finished.

**What changed:**

- **New local database (`catalog.db`, separate from the existing favorites/history database - zero migration risk to either)**: two Room tables per the requested structure -
  - `movies` (id, title, logo, group_name, url, tvg_id) - indexed on `title` and `group_name`
  - `series_episodes` (id, title, logo, group_name, url, show_title, season, episode) - indexed on `show_title`, `group_name`, `season`
  - A `browse_tiles` database view unions both into what the grid actually displays: every movie, plus **one** aggregated row per distinct show (episode count instead of one row per episode) - so a series with 300 episodes still costs exactly one row in the paged grid, same as a single movie.

- **True streaming parse (`CatalogSyncManager.sync`)**: the HTTP response body is read through a `BufferedReader.lineSequence()` and classified line-by-line as it arrives - at no point does the full file exist as one `String` or `List` in memory. Rows are batched (1,000 at a time) and upserted into Room as each batch fills, then the batch buffer is cleared and reused - memory use stays flat regardless of whether the file has 1,000 or 1,000,000 entries.

- **HTTP ETag / Last-Modified conditional requests**: the last successful sync's `ETag`/`Last-Modified` response headers are persisted (SharedPreferences) and sent back as `If-None-Match`/`If-Modified-Since` on the next sync. A `304 Not Modified` response skips the download, the parse, and every database write entirely - this is what "only redownload when the playlist changes" means at the protocol level, not just an app-side heuristic.

- **GZIP**: handled automatically by OkHttp (it requests and transparently decodes `Content-Encoding: gzip` whenever the server offers it) - no extra code needed, and nothing here overrides that default behavior.

- **"Atomic" replace, honestly described**: this is a mark-and-sweep upsert, not a literal file-level database swap. Every row touched during a sync pass gets a fresh `last_synced_at` timestamp; once the full pass completes, anything with an *older* timestamp (i.e. genuinely removed from the remote file) is deleted in one final pass. Practical effect is the same as a true atomic swap - readers never see an empty or partially-cleared table at any point, and the end state always matches the new file exactly - it's just achieved by updating rows in place throughout rather than by swapping two on-disk files.

- **Startup flow, old vs. new:**
  - Old: open app → download 38MB → parse 134k entries in memory → *then* show Movies & Series.
  - New: open app → Room already has whatever was there last time → Movies & Series opens **instantly** reading local SQLite → sync (steps above) runs in the background, and the Paging3 + Room integration auto-invalidates the grid as new/changed rows land, so content fills in progressively without the user ever waiting on it or the UI freezing.

- **Paging3, not an in-memory list**: `MoviesSeriesViewModel` exposes `Flow<PagingData<BrowseTileRow>>` via Room's own `PagingSource` (from the new `room-paging` dependency); the grid (`MoviesSeriesScreen`) collects it with `collectAsLazyPagingItems()`. Only a handful of pages are ever held in memory, whether the table has 100 rows or 130,000. Search re-queries the same way (`WHERE title LIKE ...`, using the `title` index), scoped only to this screen.

- **Pull-to-refresh** now triggers a real network re-sync (`forceRefresh = true`, bypassing the ETag check) instead of just re-reading the same local cache.

- **Series auto-play preserved**: tapping a series still queues every episode, in season/episode order, and the player still auto-advances through them (`PlayerActivity`'s `STATE_ENDED` handling, unchanged) - now sourced from a fast indexed Room query (`episodesForShow`) instead of an in-memory list built by re-parsing the whole file.

### 3. Where things now play from
- **Home's featured row** and **Favorites** (Movies/Series entries) now play directly via a new shared `CatalogPlayback` helper, which looks the item up fresh from Room by id/title/type - both used to route through `movie_detail`/`series_detail` pages backed by the *old* JSON-manifest system, which no longer knows about the M3U catalog now that it lives in Room. A favorited series still rebuilds its full episode queue on tap (not just replaying whichever single episode happened to be playing when it was favorited).
- **Live TV, the player, Settings, channel logos, and the existing UI/theme are untouched** - this update only touches the Movies & Series data path.
- `movie_detail`/`series_detail` routes and their ViewModels (`MoviesViewModel`, `SeriesViewModel`) are left in place but are no longer reachable from anywhere in the app's navigation - kept for reference rather than removed outright, since deleting them added no benefit and some risk.

### 4. Code quality
- `M3uParser` refactored: the EXTINF/tvg-attribute regex logic now lives in exactly one place (`parseExtinfLine`), shared by Live TV's existing in-memory `parse()`/`fetch()` (unchanged behavior - Live TV's playlist is small, no benefit to streaming it) and the new streaming `streamEntries()` used by `CatalogSyncManager`. Previously this logic existed twice.
- `CatalogRepository` trimmed back to only the original JSON-manifest fetching it was built for; the M3U-specific fetching/splitting logic that had accumulated there moved to `CatalogSyncManager`, where it belongs alongside the rest of the sync pipeline.

### 5. Version
- `versionName` → `1.0.0.1`
- `versionCode` continues to auto-increment on every CI build (unchanged mechanism - total commit count, see `build-apk.yml`/`build.gradle.kts`), already satisfying "increment by 1 every build" without a manual bump.

### Honest notes on scope
- Adapter-level `DiffUtil`/`RecyclerView` optimizations weren't applicable here since Movies & Series is a Compose screen (`LazyVerticalGrid`), not a `RecyclerView` - Paging3's Compose integration provides the equivalent diffing/recycling behavior natively.
- New dependencies added: `androidx.room:room-paging:2.6.1` (Room's Paging3 query support), `androidx.paging:paging-runtime-ktx:3.2.1`, `androidx.paging:paging-compose:3.2.1` - versions checked for compatibility with the project's existing Room 2.6.1 rather than assumed.
