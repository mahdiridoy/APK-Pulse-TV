# ApkPulse Stream v1.2.0

## Features
- Full Android Phone & Android TV support
- Cloudstream extensions auto-plugin loader:
  - phisher98 repo: cloudstreamrepo://raw.githubusercontent.com/phisher98/cloudstream-extensions-phisher/refs/heads/builds/repo.json
  - MegaRepo: cloudstreamrepo://raw.githubusercontent.com/self-similarity/MegaRepo/builds/repo.json
- Vertical gesture controls (Left = Brightness, Right = Volume)
- Horizontal swipe & analog channel buttons
- Right-side pop-in search drawer for Live TV & Movies
- Automatic 5-second splash ad with update verification
