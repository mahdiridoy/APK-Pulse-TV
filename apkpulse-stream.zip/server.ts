import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

const APP_VERSION = "1.2.0";
const GITHUB_REPO_URL = "https://github.com/phisher98/cloudstream-extensions-phisher";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // App version check endpoint
  app.get("/api/version", (req, res) => {
    res.json({
      currentVersion: APP_VERSION,
      latestVersion: "1.2.0",
      updateAvailable: false,
      releaseDate: "2026-07-23",
      githubUrl: GITHUB_REPO_URL,
      downloadUrl: `${GITHUB_REPO_URL}/archive/refs/heads/builds.zip`,
      changelog: [
        "Cloudstream extension repository auto-loader (phisher98 & MegaRepo)",
        "Swipe gestures for volume (right) & brightness (left) in player",
        "Landscape TV mode with Channel Up/Down analog controls",
        "Pop-out search drawer from right side on last channel scroll",
        "Auto 5-second splash ad with background update checks"
      ]
    });
  });

  // Cloudstream Repo Proxy to prevent CORS issues
  app.get("/api/fetch-repo", async (req, res) => {
    try {
      const rawUrl = req.query.url as string;
      if (!rawUrl) {
        return res.status(400).json({ error: "URL parameter is required" });
      }

      // Convert cloudstreamrepo:// to https://
      let targetUrl = rawUrl.replace(/^cloudstreamrepo:\/\//, "https://");
      
      const response = await fetch(targetUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Android TV; Mobile) Cloudstream/3.0",
          "Accept": "application/json, text/plain, */*"
        }
      });

      if (!response.ok) {
        return res.status(response.status).json({ error: `Upstream error: ${response.statusText}` });
      }

      const data = await response.json();
      res.json({ success: true, url: targetUrl, data });
    } catch (error: any) {
      console.error("Proxy fetch error:", error);
      res.status(500).json({ error: error.message || "Failed to fetch remote repository" });
    }
  });

  // M3U Playlist Fetch Proxy
  app.get("/api/fetch-m3u", async (req, res) => {
    try {
      const url = req.query.url as string;
      if (!url) {
        return res.status(400).json({ error: "URL parameter required" });
      }
      const response = await fetch(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) IPTV-Player"
        }
      });
      const text = await response.text();
      res.send(text);
    } catch (error: any) {
      res.status(500).json({ error: "Failed to fetch M3U playlist" });
    }
  });

  // Vite middleware for development vs static serve for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
