import React, { useState } from 'react';
import { Film, Play, Star, Sparkles, Layers, ChevronRight, Info, Tv } from 'lucide-react';
import { Movie, MovieEpisode } from '../types';

interface MovieCatalogProps {
  movies: Movie[];
  onPlayMovie: (movie: Movie, episode?: MovieEpisode) => void;
  onOpenSearch: () => void;
  onSyncRepos?: () => void;
}

export const MovieCatalog: React.FC<MovieCatalogProps> = ({
  movies,
  onPlayMovie,
  onOpenSearch,
  onSyncRepos
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);

  const categories = ['All', 'Movie', 'Series', 'Anime'];

  const filteredMovies = movies.filter(
    (m) => selectedCategory === 'All' || m.category === selectedCategory
  );

  return (
    <div className="space-y-6 font-sans">
      {/* Category Header & Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <Film className="w-6 h-6 text-purple-400" /> Movies & Series Catalog
          </h2>
          <p className="text-xs text-slate-400">Powered by Cloudstream extension repos (phisher98 & MegaRepo)</p>
        </div>

        <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none text-xs">
          {onSyncRepos && (
            <button
              onClick={onSyncRepos}
              className="px-3.5 py-2 rounded-xl bg-indigo-950/80 border border-indigo-700/60 hover:bg-indigo-900 text-indigo-300 font-bold flex items-center gap-1.5 transition shrink-0"
              title="Fetch and sync movies from Cloudstream extension repos"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>Sync Repos & Load Movies</span>
            </button>
          )}
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl border font-semibold transition ${
                selectedCategory === cat
                  ? 'bg-purple-600 border-purple-500 text-white shadow-lg shadow-purple-600/30'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Banner */}
      {movies.length > 0 && (
        <div
          onClick={() => setSelectedMovie(movies[0])}
          className="relative w-full h-64 sm:h-80 rounded-2xl overflow-hidden border border-slate-800 cursor-pointer group shadow-2xl"
        >
          <img
            src={movies[0].backdrop || movies[0].poster}
            alt={movies[0].title}
            className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent p-6 flex flex-col justify-end">
            <div className="flex items-center space-x-2 mb-2">
              <span className="px-2 py-0.5 bg-purple-600 text-white font-bold text-xs rounded">
                FEATURED {movies[0].category.toUpperCase()}
              </span>
              <span className="text-xs text-amber-400 flex items-center gap-1 font-bold">
                <Star className="w-3.5 h-3.5 fill-amber-400" /> {movies[0].rating}
              </span>
              <span className="text-xs text-slate-300 font-medium">• {movies[0].quality}</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-black text-white group-hover:text-purple-300 transition">
              {movies[0].title}
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 line-clamp-2 max-w-2xl mt-1">
              {movies[0].description}
            </p>
            <div className="flex items-center space-x-3 mt-4">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onPlayMovie(movies[0]);
                }}
                className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-purple-600/40 flex items-center gap-2"
              >
                <Play className="w-4 h-4 fill-white" /> Watch Now
              </button>
              <span className="text-xs text-slate-400">Source: {movies[0].sourcePlugin}</span>
            </div>
          </div>
        </div>
      )}

      {/* Grid of Movies & Series */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {filteredMovies.map((movie) => (
          <div
            key={movie.id}
            onClick={() => setSelectedMovie(movie)}
            className="bg-slate-900 border border-slate-800 hover:border-purple-500/50 rounded-2xl overflow-hidden cursor-pointer group transition duration-200 shadow-lg flex flex-col"
          >
            <div className="relative aspect-[2/3] overflow-hidden bg-slate-950">
              <img
                src={movie.poster}
                alt={movie.title}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute top-2 right-2 px-1.5 py-0.5 bg-black/80 backdrop-blur-md rounded text-[10px] font-bold text-amber-400 flex items-center gap-1">
                <Star className="w-3 h-3 fill-amber-400" /> {movie.rating}
              </div>
              <div className="absolute top-2 left-2 px-1.5 py-0.5 bg-purple-950/90 border border-purple-500/40 rounded text-[10px] font-bold text-purple-300">
                {movie.category}
              </div>
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
                <div className="p-3 bg-purple-600 rounded-full text-white shadow-xl">
                  <Play className="w-6 h-6 fill-white ml-0.5" />
                </div>
              </div>
            </div>

            <div className="p-3 flex-1 flex flex-col justify-between">
              <div>
                <h4 className="font-bold text-sm text-white line-clamp-1 group-hover:text-purple-300 transition">
                  {movie.title}
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">{movie.year} • {movie.genre[0]}</p>
              </div>
              {movie.sourcePlugin && (
                <span className="text-[10px] text-purple-400/80 mt-2 block truncate">
                  {movie.sourcePlugin}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Movie Details Modal */}
      {selectedMovie && (
        <div className="fixed inset-0 z-[8500] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md font-sans">
          <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl text-white animate-in zoom-in-95 duration-200">
            <div className="relative h-48 sm:h-64">
              <img
                src={selectedMovie.backdrop || selectedMovie.poster}
                alt={selectedMovie.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent p-6 flex flex-col justify-end">
                <div className="flex items-center space-x-2">
                  <span className="px-2 py-0.5 bg-purple-600 text-white font-bold text-xs rounded">
                    {selectedMovie.category}
                  </span>
                  <span className="text-xs text-amber-400 font-bold flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-amber-400" /> {selectedMovie.rating}
                  </span>
                  <span className="text-xs text-slate-300">{selectedMovie.year}</span>
                </div>
                <h3 className="text-2xl font-black text-white mt-1">{selectedMovie.title}</h3>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{selectedMovie.description}</p>
              
              <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800">
                <span>Genres: {selectedMovie.genre.join(', ')}</span>
                <span>Plugin: {selectedMovie.sourcePlugin}</span>
              </div>

              {/* Episodes List if Series/Anime */}
              {selectedMovie.episodes && selectedMovie.episodes.length > 0 && (
                <div className="space-y-2 pt-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Episodes List:</h4>
                  <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                    {selectedMovie.episodes.map((ep) => (
                      <div
                        key={ep.id}
                        onClick={() => {
                          onPlayMovie(selectedMovie, ep);
                          setSelectedMovie(null);
                        }}
                        className="p-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-purple-500/50 rounded-xl cursor-pointer flex items-center justify-between transition text-xs"
                      >
                        <span className="font-semibold text-slate-200">{ep.title}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-slate-400 text-[10px]">{ep.duration}</span>
                          <Play className="w-3.5 h-3.5 text-purple-400" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-3 pt-3">
                <button
                  onClick={() => setSelectedMovie(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    onPlayMovie(selectedMovie);
                    setSelectedMovie(null);
                  }}
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-600/30 flex items-center gap-2"
                >
                  <Play className="w-4 h-4 fill-white" /> Play Stream
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
