import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import {
  Volume2, VolumeX, Sun, Play, Pause, Maximize2, Minimize2,
  ChevronLeft, ChevronRight, Tv, Shield, Info, RotateCw
} from 'lucide-react';
import { Channel, ViewMode } from '../types';

interface VideoPlayerProps {
  channel: Channel;
  channels: Channel[];
  onSelectChannel: (channel: Channel) => void;
  viewMode: ViewMode;
  onClosePlayer?: () => void;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  channel,
  channels,
  onSelectChannel,
  viewMode,
  onClosePlayer
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(viewMode === 'tv');
  const [volume, setVolume] = useState<number>(0.8);
  const [brightness, setBrightness] = useState<number>(1.0); // 0.2 to 2.0

  // Drag / Gesture HUDs
  const [showVolumeHud, setShowVolumeHud] = useState<boolean>(false);
  const [showBrightnessHud, setShowBrightnessHud] = useState<boolean>(false);
  const [showChannelToast, setShowChannelToast] = useState<boolean>(false);
  const [channelToastText, setChannelToastText] = useState<string>('');

  // Touch tracking ref
  const touchStartRef = useRef<{ x: number; y: number; side: 'left' | 'right'; initVal: number } | null>(null);
  const hudTimeoutRef = useRef<any>(null);

  // Initialize HLS.js or video source
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    video.volume = volume;

    if (Hls.isSupported() && channel.streamUrl.includes('.m3u8')) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
      });
      hls.loadSource(channel.streamUrl);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        video.play().catch(() => setIsPlaying(false));
      });

      return () => {
        hls.destroy();
      };
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = channel.streamUrl;
      video.play().catch(() => setIsPlaying(false));
    } else {
      video.src = channel.streamUrl;
      video.play().catch(() => setIsPlaying(false));
    }
  }, [channel.streamUrl]);

  // Handle Channel Change (Next/Prev)
  const currentIndex = channels.findIndex((c) => c.id === channel.id);
  const nextChannel = () => {
    const nextIdx = (currentIndex + 1) % channels.length;
    const nextCh = channels[nextIdx];
    onSelectChannel(nextCh);
    triggerChannelToast(`CH ${nextCh.channelNumber}: ${nextCh.name}`);
  };

  const prevChannel = () => {
    const prevIdx = (currentIndex - 1 + channels.length) % channels.length;
    const prevCh = channels[prevIdx];
    onSelectChannel(prevCh);
    triggerChannelToast(`CH ${prevCh.channelNumber}: ${prevCh.name}`);
  };

  const triggerChannelToast = (msg: string) => {
    setChannelToastText(msg);
    setShowChannelToast(true);
    setTimeout(() => setShowChannelToast(false), 2500);
  };

  // Keyboard controls for Analog Channel change & Volume on TV
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'PageUp' || e.key === 'ChannelUp' || e.key === ']') {
        e.preventDefault();
        nextChannel();
      } else if (e.key === 'PageDown' || e.key === 'ChannelDown' || e.key === '[') {
        e.preventDefault();
        prevChannel();
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      } else if (e.key === ' ') {
        e.preventDefault();
        togglePlay();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, channels]);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;

    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // TOUCH GESTURE HANDLERS
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length !== 1 || !containerRef.current) return;
    const touch = e.touches[0];
    const rect = containerRef.current.getBoundingClientRect();
    const touchX = touch.clientX - rect.left;
    const isLeft = touchX < rect.width / 2;

    touchStartRef.current = {
      x: touch.clientX,
      y: touch.clientY,
      side: isLeft ? 'left' : 'right',
      initVal: isLeft ? brightness : volume
    };
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!touchStartRef.current || !containerRef.current) return;
    const touch = e.touches[0];
    const deltaY = touchStartRef.current.y - touch.clientY; // slide UP is positive delta
    const rect = containerRef.current.getBoundingClientRect();
    const sensitivity = 1.5 / rect.height; // scale ratio

    if (touchStartRef.current.side === 'left') {
      // BRIGHTNESS GESTURE (LEFT SIDE VERTICAL)
      let newB = touchStartRef.current.initVal + deltaY * sensitivity;
      newB = Math.max(0.2, Math.min(2.0, newB));
      setBrightness(newB);
      setShowBrightnessHud(true);
    } else {
      // VOLUME GESTURE (RIGHT SIDE VERTICAL)
      let newV = touchStartRef.current.initVal + deltaY * sensitivity;
      newV = Math.max(0, Math.min(1.0, newV));
      setVolume(newV);
      if (videoRef.current) {
        videoRef.current.volume = newV;
        setIsMuted(newV === 0);
      }
      setShowVolumeHud(true);
    }

    if (hudTimeoutRef.current) clearTimeout(hudTimeoutRef.current);
    hudTimeoutRef.current = setTimeout(() => {
      setShowBrightnessHud(false);
      setShowVolumeHud(false);
    }, 1200);
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!touchStartRef.current) return;
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - touchStartRef.current.x;
    const deltaY = touch.clientY - touchStartRef.current.y;

    // HORIZONTAL SWIPE FOR CHANNEL SWAP (Requirement #2)
    if (Math.abs(deltaX) > 60 && Math.abs(deltaY) < 40) {
      if (deltaX < 0) {
        // Swipe Left -> Next Channel
        nextChannel();
      } else {
        // Swipe Right -> Previous Channel
        prevChannel();
      }
    }

    touchStartRef.current = null;
  };

  return (
    <div
      ref={containerRef}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className={`relative w-full bg-black overflow-hidden group select-none ${
        isFullscreen ? 'fixed inset-0 z-[8000] h-screen w-screen' : 'aspect-video rounded-2xl shadow-2xl border border-slate-800'
      }`}
    >
      {/* Video element with brightness filter applied */}
      <video
        ref={videoRef}
        style={{ filter: `brightness(${brightness})` }}
        className="w-full h-full object-contain bg-black cursor-pointer"
        onClick={togglePlay}
        playsInline
      />

      {/* TOP OVERLAY BAR */}
      <div className="absolute top-0 inset-x-0 p-4 bg-gradient-to-b from-black/90 via-black/40 to-transparent flex items-center justify-between z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="flex items-center space-x-3">
          {onClosePlayer && (
            <button
              onClick={onClosePlayer}
              className="p-2 bg-slate-900/80 hover:bg-slate-800 text-white rounded-xl border border-slate-700"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 bg-indigo-600 text-white font-mono text-xs font-bold rounded">
              CH {channel.channelNumber}
            </span>
            <span className="text-white font-semibold text-sm drop-shadow">{channel.name}</span>
            {channel.quality && (
              <span className="px-1.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold rounded">
                {channel.quality}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-300 hidden sm:inline">{channel.epgProgram}</span>
          <button
            onClick={toggleFullscreen}
            className="p-2 bg-slate-900/80 hover:bg-slate-800 text-white rounded-xl border border-slate-700"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* BRIGHTNESS HUD (LEFT SIDE INDICATOR) */}
      {showBrightnessHud && (
        <div className="absolute left-6 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center bg-slate-900/90 text-white px-3 py-4 rounded-2xl border border-slate-700 backdrop-blur-md shadow-2xl animate-in fade-in zoom-in duration-150">
          <Sun className="w-5 h-5 text-amber-400 mb-2" />
          <div className="w-2 h-28 bg-slate-800 rounded-full overflow-hidden flex flex-col justify-end p-0.5 border border-slate-700">
            <div
              className="bg-amber-400 w-full rounded-full transition-all"
              style={{ height: `${Math.min(100, (brightness / 2.0) * 100)}%` }}
            />
          </div>
          <span className="text-[10px] font-mono mt-2 font-bold text-amber-300">
            {Math.round((brightness / 2.0) * 100)}%
          </span>
        </div>
      )}

      {/* VOLUME HUD (RIGHT SIDE INDICATOR) */}
      {showVolumeHud && (
        <div className="absolute right-6 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center bg-slate-900/90 text-white px-3 py-4 rounded-2xl border border-slate-700 backdrop-blur-md shadow-2xl animate-in fade-in zoom-in duration-150">
          {volume === 0 ? <VolumeX className="w-5 h-5 text-red-400 mb-2" /> : <Volume2 className="w-5 h-5 text-indigo-400 mb-2" />}
          <div className="w-2 h-28 bg-slate-800 rounded-full overflow-hidden flex flex-col justify-end p-0.5 border border-slate-700">
            <div
              className="bg-indigo-500 w-full rounded-full transition-all"
              style={{ height: `${volume * 100}%` }}
            />
          </div>
          <span className="text-[10px] font-mono mt-2 font-bold text-indigo-300">
            {Math.round(volume * 100)}%
          </span>
        </div>
      )}

      {/* CHANNEL CHANGE TOAST */}
      {showChannelToast && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-30 bg-indigo-900/90 text-white px-5 py-2.5 rounded-full border border-indigo-500 shadow-2xl backdrop-blur-md font-bold text-sm flex items-center space-x-2 animate-in fade-in slide-in-from-top duration-200">
          <Tv className="w-4 h-4 text-indigo-300 animate-pulse" />
          <span>{channelToastText}</span>
        </div>
      )}

      {/* BOTTOM CONTROLS & ANALOG CHANNEL CHANGE BUTTONS */}
      <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/95 via-black/60 to-transparent flex items-center justify-between z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="flex items-center space-x-3">
          <button
            onClick={togglePlay}
            className="p-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-lg shadow-indigo-600/40"
          >
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          </button>

          {/* Analog Channel Up / Channel Down Buttons */}
          <div className="flex items-center bg-slate-900/90 border border-slate-700 rounded-xl overflow-hidden p-1 space-x-1">
            <button
              onClick={prevChannel}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg flex items-center space-x-1"
              title="Previous Channel (Swap Left / [ / Ch Down)"
            >
              <ChevronLeft className="w-4 h-4 text-indigo-400" />
              <span>CH -</span>
            </button>
            <button
              onClick={nextChannel}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg flex items-center space-x-1"
              title="Next Channel (Swap Right / ] / Ch Up)"
            >
              <span>CH +</span>
              <ChevronRight className="w-4 h-4 text-indigo-400" />
            </button>
          </div>
        </div>

        {/* Gesture Guidance hint */}
        <div className="hidden md:flex items-center space-x-4 text-[11px] text-slate-400">
          <span>👈 Slide Left Side: Brightness</span>
          <span>👉 Slide Right Side: Volume</span>
          <span>↔️ Swipe: Change Channel</span>
        </div>
      </div>
    </div>
  );
};
