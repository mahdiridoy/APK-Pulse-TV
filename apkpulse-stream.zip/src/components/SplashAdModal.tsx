import React, { useEffect, useState } from 'react';
import { Loader2, Tv, ShieldCheck, Sparkles } from 'lucide-react';

interface SplashAdModalProps {
  onAdComplete: () => void;
  statusText?: string;
}

export const SplashAdModal: React.FC<SplashAdModalProps> = ({
  onAdComplete,
  statusText = 'Initializing streams & checking updates...'
}) => {
  const [secondsLeft, setSecondsLeft] = useState<number>(5);

  useEffect(() => {
    if (secondsLeft <= 0) {
      onAdComplete();
      return;
    }

    const timer = setTimeout(() => {
      setSecondsLeft((prev) => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [secondsLeft, onAdComplete]);

  return (
    <div className="fixed inset-0 z-[9999] flex flex-col bg-slate-950 text-white select-none overflow-hidden font-sans">
      {/* Top Banner Header */}
      <div className="flex items-center justify-between px-6 py-4 bg-slate-900/90 border-b border-slate-800 backdrop-blur-md">
        <div className="flex items-center space-x-3">
          <img 
            src="/logo.jpg" 
            alt="ApkPulse Stream Logo" 
            className="w-10 h-10 rounded-xl object-cover border border-red-500/40 shadow-lg shadow-red-500/20"
          />
          <div>
            <h1 className="text-xl font-bold tracking-wide text-white flex items-center gap-2">
              ApkPulse <span className="text-xs px-2 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/30 font-bold uppercase tracking-wider">Stream</span>
            </h1>
            <p className="text-xs text-slate-400">Please wait 5 Seconds...</p>
          </div>
        </div>

        <div className="flex items-center space-x-3 bg-slate-800/80 px-4 py-2 rounded-full border border-slate-700">
          <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
          <span className="text-sm font-semibold text-slate-200">
            Redirecting in <span className="text-indigo-400 font-mono text-base px-1.5 py-0.5 bg-indigo-950/80 rounded border border-indigo-800/50">{secondsLeft}s</span>
          </span>
        </div>
      </div>

      {/* Main WebView Ad Sandbox Container */}
      <div className="flex-1 relative w-full h-full bg-slate-900 flex flex-col items-center justify-center p-4">
        {/* Ad Sandbox Frame */}
        <div className="w-full max-w-4xl h-[70vh] bg-slate-950 rounded-2xl border border-slate-800 shadow-2xl relative overflow-hidden flex flex-col">
          <div className="px-4 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Secure Ad Network Verification
            </span>
            <span>Zone: 262866</span>
          </div>

          <div className="flex-1 w-full h-full relative">
            <iframe
              title="Sponsor Ad"
              className="w-full h-full border-0"
              srcDoc={`
                <!DOCTYPE html>
                <html>
                  <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <style>
                      body {
                        margin: 0;
                        padding: 0;
                        background-color: #090d16;
                        color: #ffffff;
                        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        min-height: 100vh;
                        text-align: center;
                      }
                      .card {
                        background: linear-gradient(135deg, rgba(30, 41, 59, 0.8), rgba(15, 23, 42, 0.9));
                        border: 1px solid rgba(255, 255, 255, 0.1);
                        border-radius: 16px;
                        padding: 30px;
                        max-width: 400px;
                        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);
                      }
                      h2 { margin-top: 0; color: #818cf8; font-size: 20px; }
                      p { color: #94a3b8; font-size: 14px; line-height: 1.5; }
                      .badge {
                        display: inline-block;
                        padding: 6px 12px;
                        background: #312e81;
                        color: #c7d2fe;
                        border-radius: 20px;
                        font-size: 12px;
                        margin-bottom: 15px;
                      }
                    </style>
                    <script src="https://quge5.com/88/tag.min.js" data-zone="262866" async data-cfasync="false"></script>
                  </head>
                  <body>
                    <div class="card">
                      <div class="badge">Sponsored Content</div>
                      <h2>ApkPulse Stream Engine</h2>
                      <p>Loading Live TV M3U playlists, checking GitHub version updates, and parsing Cloudstream repositories...</p>
                    </div>
                  </body>
                </html>
              `}
            />
          </div>
        </div>
      </div>

      {/* Bottom Status & Progress Footer */}
      <div className="bg-slate-900 border-t border-slate-800 px-6 py-3 flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
          <span className="font-medium text-slate-300">{statusText}</span>
        </div>
        <div className="flex items-center space-x-4">
          <span>Auto-updating M3U Playlists</span>
          <span>•</span>
          <span>Version Check Active</span>
        </div>
      </div>
    </div>
  );
};
