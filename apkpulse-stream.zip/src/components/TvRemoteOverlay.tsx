import React, { useState } from 'react';
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight, CornerDownLeft, Volume2, VolumeX, Tv, ArrowLeft, Menu, Search, X } from 'lucide-react';

interface TvRemoteOverlayProps {
  onDpadUp: () => void;
  onDpadDown: () => void;
  onDpadLeft: () => void;
  onDpadRight: () => void;
  onSelect: () => void;
  onBack: () => void;
  onChannelUp: () => void;
  onChannelDown: () => void;
  onToggleSearch: () => void;
  onToggleMenu: () => void;
}

export const TvRemoteOverlay: React.FC<TvRemoteOverlayProps> = ({
  onDpadUp,
  onDpadDown,
  onDpadLeft,
  onDpadRight,
  onSelect,
  onBack,
  onChannelUp,
  onChannelDown,
  onToggleSearch,
  onToggleMenu
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);

  return (
    <>
      {/* Floating Remote Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-[7000] p-3 bg-gradient-to-tr from-indigo-600 to-purple-600 text-white rounded-full shadow-2xl border border-indigo-400 hover:scale-105 active:scale-95 transition flex items-center space-x-2"
        title="Android TV Remote Controller"
      >
        <Tv className="w-6 h-6" />
        <span className="text-xs font-bold pr-1 hidden sm:inline">TV Remote</span>
      </button>

      {/* Floating Virtual Remote Controller */}
      {isOpen && (
        <div className="fixed bottom-20 right-6 z-[7001] w-64 bg-slate-900/95 border border-slate-700/80 rounded-3xl p-5 shadow-2xl backdrop-blur-xl text-white select-none animate-in fade-in zoom-in duration-200">
          
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <div className="flex items-center space-x-2">
              <Tv className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-bold text-slate-200">Android TV D-Pad</span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 text-slate-400 hover:text-white rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* D-Pad Controller */}
          <div className="relative w-40 h-40 mx-auto my-2 flex items-center justify-center">
            {/* Background Ring */}
            <div className="absolute inset-0 rounded-full bg-slate-800 border border-slate-700 shadow-inner" />

            {/* UP */}
            <button
              onClick={onDpadUp}
              className="absolute top-2 left-1/2 -translate-x-1/2 p-2 hover:bg-indigo-600/50 rounded-full text-slate-300 hover:text-white transition active:scale-90"
            >
              <ChevronUp className="w-6 h-6" />
            </button>

            {/* DOWN */}
            <button
              onClick={onDpadDown}
              className="absolute bottom-2 left-1/2 -translate-x-1/2 p-2 hover:bg-indigo-600/50 rounded-full text-slate-300 hover:text-white transition active:scale-90"
            >
              <ChevronDown className="w-6 h-6" />
            </button>

            {/* LEFT */}
            <button
              onClick={onDpadLeft}
              className="absolute left-2 top-1/2 -translate-y-1/2 p-2 hover:bg-indigo-600/50 rounded-full text-slate-300 hover:text-white transition active:scale-90"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* RIGHT */}
            <button
              onClick={onDpadRight}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 hover:bg-indigo-600/50 rounded-full text-slate-300 hover:text-white transition active:scale-90"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* CENTER OK / SELECT */}
            <button
              onClick={onSelect}
              className="relative w-14 h-14 bg-gradient-to-tr from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 rounded-full font-bold text-xs flex items-center justify-center shadow-lg active:scale-95 transition"
            >
              OK
            </button>
          </div>

          {/* Action Row */}
          <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-800">
            <button
              onClick={onChannelUp}
              className="py-2 px-3 bg-slate-800 hover:bg-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1"
            >
              <span>CH +</span>
            </button>
            <button
              onClick={onChannelDown}
              className="py-2 px-3 bg-slate-800 hover:bg-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1"
            >
              <span>CH -</span>
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2 mt-2 text-[11px]">
            <button
              onClick={onBack}
              className="py-2 bg-slate-800 hover:bg-slate-700 rounded-xl font-medium flex flex-col items-center justify-center text-slate-300"
            >
              <ArrowLeft className="w-3.5 h-3.5 mb-0.5" />
              <span>Back</span>
            </button>
            <button
              onClick={onToggleMenu}
              className="py-2 bg-slate-800 hover:bg-slate-700 rounded-xl font-medium flex flex-col items-center justify-center text-slate-300"
            >
              <Menu className="w-3.5 h-3.5 mb-0.5" />
              <span>Menu</span>
            </button>
            <button
              onClick={onToggleSearch}
              className="py-2 bg-slate-800 hover:bg-slate-700 rounded-xl font-medium flex flex-col items-center justify-center text-slate-300"
            >
              <Search className="w-3.5 h-3.5 mb-0.5" />
              <span>Search</span>
            </button>
          </div>

        </div>
      )}
    </>
  );
};
