import React, { useState } from 'react';
import { Download, RefreshCw, ShieldAlert, CheckCircle2, Github, ArrowRight, HardDriveDownload } from 'lucide-react';
import { AppUpdateInfo } from '../types';

interface UpdateModalProps {
  updateInfo: AppUpdateInfo;
  onApplyUpdate: () => void;
  onDownloadZip: () => void;
  onClose?: () => void;
  isMandatory?: boolean;
}

export const UpdateModal: React.FC<UpdateModalProps> = ({
  updateInfo,
  onApplyUpdate,
  onDownloadZip,
  onClose,
  isMandatory = false
}) => {
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [isInstalling, setIsInstalling] = useState<boolean>(false);
  const [showPermissionPrompt, setShowPermissionPrompt] = useState<boolean>(false);
  const [updateSuccess, setUpdateSuccess] = useState<boolean>(false);

  const startUpdateProcess = () => {
    setShowPermissionPrompt(true);
  };

  const confirmPermissionAndDownload = () => {
    setShowPermissionPrompt(false);
    setIsDownloading(true);
    setDownloadProgress(10);

    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsDownloading(false);
          setIsInstalling(true);

          setTimeout(() => {
            setIsInstalling(false);
            setUpdateSuccess(true);
            setTimeout(() => {
              onApplyUpdate();
            }, 1200);
          }, 1500);

          return 100;
        }
        return prev + 15;
      });
    }, 200);
  };

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md font-sans">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-white animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-indigo-900/80 via-slate-900 to-purple-900/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-indigo-600/30 border border-indigo-500/40 rounded-xl">
              <RefreshCw className={`w-6 h-6 text-indigo-400 ${isDownloading || isInstalling ? 'animate-spin' : ''}`} />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white">App Update Required</h2>
              <p className="text-xs text-indigo-300">Version {updateInfo.latestVersion} is now available</p>
            </div>
          </div>
          {onClose && !isMandatory && !isDownloading && !isInstalling && (
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white text-sm px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700"
            >
              Later
            </button>
          )}
        </div>

        {/* Body Content */}
        <div className="p-6 space-y-5">
          {showPermissionPrompt ? (
            <div className="p-4 bg-slate-800/80 rounded-xl border border-amber-500/30 space-y-4">
              <div className="flex items-start space-x-3 text-amber-400">
                <ShieldAlert className="w-6 h-6 shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-white">Permission Required for Installation</h3>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Allow ApkPulse Stream to download the latest GitHub build package ({updateInfo.latestVersion}) and apply auto-update files for Android Phone / Android TV?
                  </p>
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  onClick={confirmPermissionAndDownload}
                  className="flex-1 py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-medium text-sm transition shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" /> Allow & Download Now
                </button>
                <button
                  onClick={() => setShowPermissionPrompt(false)}
                  className="py-2.5 px-4 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : updateSuccess ? (
            <div className="text-center py-6 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
              <h3 className="text-lg font-bold text-white">Update Installed Successfully!</h3>
              <p className="text-xs text-slate-400">Applying changes and restarting application context...</p>
            </div>
          ) : isDownloading || isInstalling ? (
            <div className="space-y-4 py-4">
              <div className="flex justify-between text-sm font-medium">
                <span className="text-slate-300">{isInstalling ? 'Installing Update...' : 'Downloading from GitHub...'}</span>
                <span className="text-indigo-400">{downloadProgress}%</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden p-0.5 border border-slate-700">
                <div
                  className="bg-gradient-to-r from-indigo-500 to-purple-500 h-full rounded-full transition-all duration-300 shadow-md shadow-indigo-500/50"
                  style={{ width: `${downloadProgress}%` }}
                />
              </div>
              <p className="text-xs text-center text-slate-400">
                {isInstalling ? 'Applying updated APK/M3U dependencies...' : 'Fetching release asset from GitHub repository...'}
              </p>
            </div>
          ) : (
            <>
              {/* Version Comparison */}
              <div className="grid grid-cols-2 gap-3 text-center">
                <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700">
                  <span className="text-xs text-slate-400 block">Current Installed</span>
                  <span className="text-sm font-semibold text-slate-300">v{updateInfo.currentVersion}</span>
                </div>
                <div className="p-3 bg-indigo-950/40 rounded-xl border border-indigo-800/60">
                  <span className="text-xs text-indigo-300 block">Latest Release</span>
                  <span className="text-sm font-bold text-indigo-400">v{updateInfo.latestVersion}</span>
                </div>
              </div>

              {/* Changelog */}
              <div className="space-y-2">
                <h4 className="text-xs uppercase font-semibold tracking-wider text-slate-400">What's New in GitHub Release:</h4>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 max-h-36 overflow-y-auto text-xs text-slate-300">
                  {updateInfo.changelog?.map((item, idx) => (
                    <div key={idx} className="flex items-start space-x-2">
                      <span className="text-indigo-400 font-bold">•</span>
                      <span>{item}</span>
                    </div>
                  )) || <div>• Bug fixes, Cloudstream repo plugins auto-installation, and TV remote enhancements.</div>}
                </div>
              </div>

              {/* Main Actions */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={startUpdateProcess}
                  className="w-full py-3 px-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition text-sm"
                >
                  <Github className="w-5 h-5" /> Auto Update from GitHub
                </button>

                <button
                  onClick={onDownloadZip}
                  className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 border border-slate-700 transition"
                >
                  <HardDriveDownload className="w-4 h-4 text-emerald-400" /> Download Updated ZIP Bundle
                </button>
              </div>
            </>
          )}

        </div>

        {/* Footer info */}
        <div className="px-6 py-3 bg-slate-950 border-t border-slate-800 text-[11px] text-slate-500 flex justify-between items-center">
          <span>Target: Android TV & Android Mobile</span>
          <span>Auto-checks GitHub on app open</span>
        </div>

      </div>
    </div>
  );
};
