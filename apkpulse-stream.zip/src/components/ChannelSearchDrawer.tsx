import React, { useState, useEffect } from 'react';
import { Search, X, Tv, Film, Sparkles, ChevronRight, Play, Star } from 'lucide-react';
import { Channel, Movie } from '../types';

interface ChannelSearchDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'livetv' | 'movies';
  channels: Channel[];
  movies: Movie[];
  onSelectChannel: (channel: Channel) => void;
  onSelectMovie: (movie: Movie) => void;
}

export const ChannelSearchDrawer: React.FC<ChannelSearchDrawerProps> = ({
  isOpen,
  onClose,
  mode,
  channels,
  movies,
  onSelectChannel,
  onSelectMovie
}) => {
  const [query, setQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedCategory('All');
    }
  }, [isOpen, mode]);

  if (!isOpen) return null;

  // Filter logic strictly separated based on current mode!
  const isLiveTv = mode === 'livetv';

  const categories = isLiveTv
    ? ['All', ...Array.from(new Set(channels.map((c) => c.category)))]
    : ['All', 'Movie', 'Series', 'Anime'];

  const filteredChannels = channels.filter((ch) => {
    const matchesSearch = ch.name.toLowerCase().includes(query.toLowerCase()) ||
      ch.category.toLowerCase().includes(query.toLowerCase()) ||
      ch.channelNumber.toString().includes(query);
    const matchesCat = selectedCategory === 'All' || ch.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const filteredMovies = movies.filter((mov) => {
    const matchesSearch = mov.title.toLowerCase().includes(query.toLowerCase()) ||
      mov.genre.some((g) => g.toLowerCase().includes(query.toLowerCase())) ||
      (mov.sourcePlugin && mov.sourcePlugin.toLowerCase().includes(query.toLowerCase()));
    const matchesCat = selectedCategory === 'All' || mov.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="fixed inset-0 z-[9000] flex justify-end bg-black/70 backdrop-blur-sm animate-in fade-in duration-200 font-sans">
      <div
        className="w-full max-w-md bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-300 text-white"
      >
        {/* Drawer Header */}
        <div className="p-5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-indigo-600/30 border border-indigo-500/40 rounded-xl">
              {isLiveTv ? <Tv className="w-5 h-5 text-indigo-400" /> : <Film className="w-5 h-5 text-purple-400" />}
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Search {isLiveTv ? 'Live TV Channels' : 'Movies & Series'}
              </h2>
              <p className="text-xs text-slate-400">
                {isLiveTv ? 'Results filter ONLY Live TV streams' : 'Results filter ONLY Movies, Series & Anime'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-900 border border-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Input Bar */}
        <div className="p-4 bg-slate-900 border-b border-slate-800 space-y-3">
          <div className="relative">
            <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={isLiveTv ? 'Search by channel name, number or genre...' : 'Search movies, series or anime titles...'}
              className="w-full pl-11 pr-4 py-3 bg-slate-950 border border-slate-700/80 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>

          {/* Category Filter Chips */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none text-xs">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg border whitespace-nowrap font-medium transition ${
                  selectedCategory === cat
                    ? 'bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-600/30'
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Search Results List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {isLiveTv ? (
            filteredChannels.length > 0 ? (
              filteredChannels.map((ch) => (
                <div
                  key={ch.id}
                  onClick={() => {
                    onSelectChannel(ch);
                    onClose();
                  }}
                  className="p-3 bg-slate-950 hover:bg-slate-800/80 border border-slate-800 hover:border-indigo-500/50 rounded-xl cursor-pointer flex items-center justify-between group transition"
                >
                  <div className="flex items-center space-x-3">
                    <img
                      src={ch.logo}
                      alt={ch.name}
                      className="w-12 h-12 rounded-lg object-cover bg-slate-900 border border-slate-800"
                    />
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="px-1.5 py-0.5 bg-indigo-900/60 text-indigo-300 font-mono text-[10px] font-bold rounded">
                          CH {ch.channelNumber}
                        </span>
                        <h4 className="font-semibold text-sm text-slate-200 group-hover:text-indigo-400">{ch.name}</h4>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{ch.epgProgram || ch.category}</p>
                    </div>
                  </div>
                  <Play className="w-5 h-5 text-slate-500 group-hover:text-indigo-400" />
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-slate-500 space-y-2">
                <Tv className="w-10 h-10 mx-auto opacity-30" />
                <p className="text-sm">No Live TV channels found for "{query}"</p>
              </div>
            )
          ) : (
            filteredMovies.length > 0 ? (
              filteredMovies.map((mov) => (
                <div
                  key={mov.id}
                  onClick={() => {
                    onSelectMovie(mov);
                    onClose();
                  }}
                  className="p-3 bg-slate-950 hover:bg-slate-800/80 border border-slate-800 hover:border-purple-500/50 rounded-xl cursor-pointer flex items-center space-x-3 group transition"
                >
                  <img
                    src={mov.poster}
                    alt={mov.title}
                    className="w-12 h-16 rounded-lg object-cover bg-slate-900 border border-slate-800 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2">
                      <span className="px-1.5 py-0.5 bg-purple-900/60 text-purple-300 text-[10px] font-bold rounded">
                        {mov.category}
                      </span>
                      <h4 className="font-semibold text-sm text-slate-200 group-hover:text-purple-400 truncate">{mov.title}</h4>
                    </div>
                    <div className="flex items-center space-x-2 text-xs text-slate-400 mt-1">
                      <span className="flex items-center text-amber-400">
                        <Star className="w-3 h-3 fill-amber-400 mr-1" /> {mov.rating}
                      </span>
                      <span>•</span>
                      <span>{mov.year}</span>
                      <span>•</span>
                      <span className="truncate">{mov.genre.join(', ')}</span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-purple-400" />
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-slate-500 space-y-2">
                <Film className="w-10 h-10 mx-auto opacity-30" />
                <p className="text-sm">No Movies or Series found for "{query}"</p>
              </div>
            )
          )}
        </div>

        {/* Drawer Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 text-xs text-slate-500 flex justify-between items-center">
          <span>{isLiveTv ? `${filteredChannels.length} Channels` : `${filteredMovies.length} Titles`}</span>
          <span>Slide Right to Exit</span>
        </div>
      </div>
    </div>
  );
};
