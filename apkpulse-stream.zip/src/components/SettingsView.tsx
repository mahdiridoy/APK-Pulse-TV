import React, { useState } from 'react';
import { Layers, RefreshCw, CheckCircle2, HardDriveDownload, Plus, Link2, Tv, Sparkles, Radio, FileText, Upload } from 'lucide-react';
import { CLOUDSTREAM_REPOS } from '../data/defaultMovies';
import { PRESET_M3U_PLAYLISTS } from '../utils/m3uParser';

interface SettingsViewProps {
  onAddM3uUrl: (url: string) => void;
  onOpenZipExporter: () => void;
  onCheckUpdates: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  onAddM3uUrl,
  onOpenZipExporter,
  onCheckUpdates
}) => {
  const [customM3u, setCustomM3u] = useState<string>('');
  const [m3uRawText, setM3uRawText] = useState<string>('');
  const [addedM3uSuccess, setAddedM3uSuccess] = useState<boolean>(false);
  const [loadedPreset, setLoadedPreset] = useState<string | null>(null);

  const handleAddM3u = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customM3u.trim()) return;
    onAddM3uUrl(customM3u.trim());
    setCustomM3u('');
    setAddedM3uSuccess(true);
    setTimeout(() => setAddedM3uSuccess(false), 3000);
  };

  const handleRawPasteM3u = (e: React.FormEvent) => {
    e.preventDefault();
    if (!m3uRawText.trim()) return;
    onAddM3uUrl(m3uRawText.trim());
    setM3uRawText('');
    setAddedM3uSuccess(true);
    setTimeout(() => setAddedM3uSuccess(false), 3000);
  };

  const handleLoadPreset = (presetUrl: string, title: string) => {
    onAddM3uUrl(presetUrl);
    setLoadedPreset(title);
    setAddedM3uSuccess(true);
    setTimeout(() => {
      setAddedM3uSuccess(false);
      setLoadedPreset(null);
    }, 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto font-sans text-white">
      <div>
        <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
          <Layers className="w-6 h-6 text-indigo-400" /> Cloudstream Extensions & Repos
        </h2>
        <p className="text-xs text-slate-400">Manage extension repositories, M3U playlists, and app update packages</p>
      </div>

      {/* Cloudstream Repositories */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
        <h3 className="font-bold text-sm text-slate-200 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-purple-400" /> Loaded Extension Repositories
        </h3>
        
        <div className="space-y-3">
          {CLOUDSTREAM_REPOS.map((repoUrl, idx) => (
            <div
              key={idx}
              className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
            >
              <div className="flex items-center space-x-3 overflow-hidden">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <div className="min-w-0">
                  <span className="text-xs font-bold text-indigo-300 block">
                    {idx === 0 ? 'Phisher98 Extension Repo' : 'MegaRepo Full Extensions'}
                  </span>
                  <span className="text-[11px] font-mono text-slate-400 truncate block">
                    {repoUrl}
                  </span>
                </div>
              </div>
              <span className="px-2.5 py-1 bg-emerald-950 text-emerald-400 border border-emerald-800/60 rounded-lg text-[10px] font-bold shrink-0 self-start sm:self-center">
                Plugins Installed
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* M3U Custom Playlist Loader */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
        <h3 className="font-bold text-sm text-slate-200 flex items-center gap-2">
          <Tv className="w-4 h-4 text-indigo-400" /> Custom Live TV M3U Playlist & Presets
        </h3>

        {/* Preset Playlists Buttons */}
        <div>
          <span className="text-xs font-semibold text-slate-400 block mb-2">1-Click Public IPTV Preset Playlists:</span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {PRESET_M3U_PLAYLISTS.map((preset) => (
              <div
                key={preset.id}
                onClick={() => handleLoadPreset(preset.url, preset.title)}
                className="p-3 bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-indigo-500/60 rounded-xl cursor-pointer transition flex items-center justify-between group"
              >
                <div className="min-w-0 pr-2">
                  <span className="text-xs font-bold text-slate-200 group-hover:text-indigo-300 block truncate">
                    {preset.title}
                  </span>
                  <span className="text-[10px] text-slate-400 block truncate">
                    {preset.description}
                  </span>
                </div>
                <button className="px-2.5 py-1 bg-indigo-900/60 text-indigo-300 border border-indigo-700/50 rounded-lg text-[10px] font-bold shrink-0">
                  Load
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* URL Input */}
        <form onSubmit={handleAddM3u} className="flex gap-2 pt-2 border-t border-slate-800">
          <div className="relative flex-1">
            <Link2 className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={customM3u}
              onChange={(e) => setCustomM3u(e.target.value)}
              placeholder="Paste IPTV .m3u or .m3u8 URL..."
              className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-1 shrink-0"
          >
            <Plus className="w-4 h-4" /> Load URL
          </button>
        </form>

        {/* Raw Text Paste & File Upload */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
          <form onSubmit={handleRawPasteM3u} className="space-y-2">
            <span className="text-xs font-semibold text-slate-400 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-indigo-400" /> Paste raw M3U text directly:
            </span>
            <textarea
              rows={2}
              value={m3uRawText}
              onChange={(e) => setM3uRawText(e.target.value)}
              placeholder="#EXTM3U&#10;#EXTINF:-1 tvg-name=&quot;Channel 1&quot;,My TV Channel&#10;http://example.com/stream.m3u8"
              className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-slate-300 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 flex items-center justify-center gap-1"
            >
              <Plus className="w-4 h-4 text-indigo-400" /> Import Raw M3U Content
            </button>
          </form>

          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-400 flex items-center gap-1">
              <Upload className="w-3.5 h-3.5 text-purple-400" /> Upload .m3u file from device:
            </span>
            <label className="flex flex-col items-center justify-center p-3 border-2 border-dashed border-slate-800 hover:border-indigo-500/60 rounded-xl bg-slate-950/60 cursor-pointer transition text-center group">
              <Upload className="w-5 h-5 text-slate-500 group-hover:text-indigo-400 mb-1" />
              <span className="text-xs text-slate-300 font-semibold group-hover:text-white">Choose .m3u / .m3u8 File</span>
              <span className="text-[10px] text-slate-500">From local storage or downloads</span>
              <input
                type="file"
                accept=".m3u,.m3u8,.txt"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                      const text = event.target?.result as string;
                      if (text) {
                        onAddM3uUrl(text);
                        setAddedM3uSuccess(true);
                        setTimeout(() => setAddedM3uSuccess(false), 3000);
                      }
                    };
                    reader.readAsText(file);
                  }
                }}
              />
            </label>
          </div>
        </div>

        {addedM3uSuccess && (
          <p className="text-xs text-emerald-400 font-semibold flex items-center gap-1 pt-1">
            <CheckCircle2 className="w-4 h-4" /> M3U Playlist {loadedPreset ? `("${loadedPreset}")` : ''} loaded into Live TV Channels!
          </p>
        )}
      </div>

      {/* System Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <h4 className="font-bold text-sm text-slate-200">GitHub Release Checker</h4>
          <p className="text-xs text-slate-400">Verifies current release build version against GitHub repository.</p>
          <button
            onClick={onCheckUpdates}
            className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl border border-slate-700 flex items-center justify-center gap-2 transition"
          >
            <RefreshCw className="w-4 h-4 text-amber-400" /> Check GitHub Releases
          </button>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <h4 className="font-bold text-sm text-slate-200">Create Update ZIP</h4>
          <p className="text-xs text-slate-400">Generates updated source and plugin bundle for offline install.</p>
          <button
            onClick={onOpenZipExporter}
            className="w-full py-2.5 px-4 bg-emerald-950/80 hover:bg-emerald-900/80 border border-emerald-800 text-emerald-300 font-semibold text-xs rounded-xl flex items-center justify-center gap-2 transition"
          >
            <HardDriveDownload className="w-4 h-4 text-emerald-400" /> Export Update ZIP
          </button>
        </div>
      </div>
    </div>
  );
};
