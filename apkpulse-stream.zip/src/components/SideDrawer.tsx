import React from 'react';
import { Tv, Film, Settings, HardDriveDownload, Sparkles, X, ChevronRight, Layers, ShieldCheck, RefreshCw, Monitor, Smartphone } from 'lucide-react';
import { AppTab, ViewMode } from '../types';

interface SideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  viewMode: ViewMode;
  onToggleViewMode: () => void;
  onOpenUpdateModal: () => void;
  onOpenZipExporter: () => void;
}

export const SideDrawer: React.FC<SideDrawerProps> = ({
  isOpen,
  onClose,
  activeTab,
  onSelectTab,
  viewMode,
  onToggleViewMode,
  onOpenUpdateModal,
  onOpenZipExporter
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9000] flex justify-start bg-black/70 backdrop-blur-sm animate-in fade-in duration-200 font-sans">
      <div className="w-full max-w-xs bg-slate-900 border-r border-slate-800 h-full flex flex-col shadow-2xl animate-in slide-in-from-left duration-300 text-white">
        
        {/* Drawer Header */}
        <div className="p-5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img 
              src="/logo.jpg" 
              alt="ApkPulse Stream Logo" 
              className="w-10 h-10 rounded-xl object-cover border border-red-500/40 shadow-lg shadow-red-500/20"
            />
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-1.5">
                ApkPulse <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/30 font-bold uppercase tracking-wider">Stream</span>
              </h2>
              <p className="text-xs text-slate-400">Live TV & Media Player</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-900 border border-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* View Mode Switcher Header */}
        <div className="px-4 py-3 bg-slate-950/60 border-b border-slate-800/80 flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Device Mode</span>
          <button
            onClick={onToggleViewMode}
            className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-indigo-950/60 hover:bg-indigo-900/60 border border-indigo-800/60 text-xs font-bold text-indigo-300 transition"
          >
            {viewMode === 'tv' ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-indigo-400" />
                <span>Android TV</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
                <span>Android Phone</span>
              </>
            )}
          </button>
        </div>

        {/* Navigation Items */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          
          <button
            onClick={() => {
              onSelectTab('livetv');
              onClose();
            }}
            className={`w-full p-3 rounded-xl border flex items-center justify-between transition ${
              activeTab === 'livetv'
                ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:bg-slate-800/80'
            }`}
          >
            <div className="flex items-center space-x-3">
              <Tv className="w-5 h-5 text-indigo-300" />
              <div className="text-left">
                <span className="font-bold text-sm block">Live TV Channels</span>
                <span className="text-[11px] text-slate-400">News, Sports, Entertainment</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 opacity-60" />
          </button>

          <button
            onClick={() => {
              onSelectTab('movies');
              onClose();
            }}
            className={`w-full p-3 rounded-xl border flex items-center justify-between transition ${
              activeTab === 'movies'
                ? 'bg-purple-600 border-purple-500 text-white shadow-lg shadow-purple-600/30'
                : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:bg-slate-800/80'
            }`}
          >
            <div className="flex items-center space-x-3">
              <Film className="w-5 h-5 text-purple-300" />
              <div className="text-left">
                <span className="font-bold text-sm block">Movies & Series</span>
                <span className="text-[11px] text-slate-400">Cloudstream Catalog</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 opacity-60" />
          </button>

          <div className="pt-4 pb-2">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider px-2">Extensions & Tools</span>
          </div>

          <button
            onClick={() => {
              onSelectTab('settings');
              onClose();
            }}
            className={`w-full p-3 rounded-xl border flex items-center justify-between transition ${
              activeTab === 'settings'
                ? 'bg-slate-800 border-slate-700 text-white'
                : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:bg-slate-800/80'
            }`}
          >
            <div className="flex items-center space-x-3">
              <Layers className="w-5 h-5 text-indigo-400" />
              <div className="text-left">
                <span className="font-semibold text-sm block">Cloudstream Repos</span>
                <span className="text-[11px] text-slate-400">phisher98 & MegaRepo</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 opacity-60" />
          </button>

          <button
            onClick={() => {
              onOpenUpdateModal();
              onClose();
            }}
            className="w-full p-3 rounded-xl border border-slate-800 bg-slate-950/80 text-slate-300 hover:bg-slate-800/80 flex items-center justify-between transition"
          >
            <div className="flex items-center space-x-3">
              <RefreshCw className="w-5 h-5 text-amber-400" />
              <div className="text-left">
                <span className="font-semibold text-sm block">Check App Updates</span>
                <span className="text-[11px] text-slate-400">GitHub Auto Installer</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 opacity-60" />
          </button>

          <button
            onClick={() => {
              onOpenZipExporter();
              onClose();
            }}
            className="w-full p-3 rounded-xl border border-slate-800 bg-slate-950/80 text-slate-300 hover:bg-slate-800/80 flex items-center justify-between transition"
          >
            <div className="flex items-center space-x-3">
              <HardDriveDownload className="w-5 h-5 text-emerald-400" />
              <div className="text-left">
                <span className="font-semibold text-sm block">Create Update ZIP</span>
                <span className="text-[11px] text-slate-400">Export Application Package</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 opacity-60" />
          </button>

        </div>

        {/* Drawer Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 text-xs text-slate-500 space-y-1">
          <div className="flex justify-between items-center text-slate-400 font-medium">
            <span>ApkPulse Stream Engine</span>
            <span>v1.2.0</span>
          </div>
          <p className="text-[10px] text-slate-600">Slide Right to Open • TV Remote Left D-Pad support</p>
        </div>

      </div>
    </div>
  );
};
