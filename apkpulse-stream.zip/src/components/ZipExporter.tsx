import React, { useState } from 'react';
import JSZip from 'jszip';
import { HardDriveDownload, CheckCircle2, Sparkles, FileArchive, Layers, Code } from 'lucide-react';
import { CLOUDSTREAM_REPOS } from '../data/defaultMovies';

export const ZipExporter: React.FC = () => {
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  const generateAndDownloadZip = async () => {
    setIsExporting(true);
    setDownloadSuccess(false);

    try {
      const zip = new JSZip();

      // Project configuration files
      zip.file("package.json", JSON.stringify({
        name: "apkpulse-stream-app",
        version: "1.2.0",
        private: true,
        scripts: {
          dev: "tsx server.ts",
          build: "vite build && esbuild server.ts --bundle --platform=node --format=cjs --packages=external --sourcemap --outfile=dist/server.cjs",
          start: "node dist/server.cjs"
        },
        dependencies: {
          "express": "^4.21.2",
          "hls.js": "^1.5.8",
          "lucide-react": "^0.546.0",
          "react": "^19.0.1",
          "react-dom": "^19.0.1"
        }
      }, null, 2));

      zip.file("metadata.json", JSON.stringify({
        name: "ApkPulse Stream",
        version: "1.2.0",
        cloudstreamRepos: CLOUDSTREAM_REPOS
      }, null, 2));

      // Cloudstream extension plugin repo configurations
      const repoFolder = zip.folder("cloudstream-extensions");
      if (repoFolder) {
        repoFolder.file("phisher-repo.json", JSON.stringify({
          repoUrl: "https://raw.githubusercontent.com/phisher98/cloudstream-extensions-phisher/refs/heads/builds/repo.json",
          autoInstall: true,
          plugins: ["SuperStream", "Sflix", "DramaCool", "Animesuge"]
        }, null, 2));

        repoFolder.file("megarepo.json", JSON.stringify({
          repoUrl: "https://raw.githubusercontent.com/self-similarity/MegaRepo/builds/repo.json",
          autoInstall: true,
          plugins: ["MegaStream", "Aniwave", "FlixHQ"]
        }, null, 2));
      }

      // App metadata & instructions
      zip.file("README.md", `# ApkPulse Stream v1.2.0

## Features
- Full Android Phone & Android TV support
- Cloudstream extensions auto-plugin loader:
  - phisher98 repo: cloudstreamrepo://raw.githubusercontent.com/phisher98/cloudstream-extensions-phisher/refs/heads/builds/repo.json
  - MegaRepo: cloudstreamrepo://raw.githubusercontent.com/self-similarity/MegaRepo/builds/repo.json
- Vertical gesture controls (Left = Brightness, Right = Volume)
- Horizontal swipe & analog channel buttons
- Right-side pop-in search drawer for Live TV & Movies
- Automatic 5-second splash ad with update verification
`);

      // Generate Blob & trigger download
      const content = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(content);
      const link = document.createElement("a");
      link.href = url;
      link.download = "apkpulse-stream-v1.2.0-update.zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setIsExporting(false);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error("ZIP Generation error:", err);
      setIsExporting(false);
    }
  };

  return (
    <div className="p-6 max-w-2xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl text-white shadow-2xl space-y-5 font-sans">
      <div className="flex items-center space-x-3">
        <div className="p-3 bg-emerald-600/30 border border-emerald-500/40 rounded-xl">
          <FileArchive className="w-6 h-6 text-emerald-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-white">Export Update ZIP Package</h2>
          <p className="text-xs text-slate-400">Generate updated deployment zip with built-in Cloudstream repositories</p>
        </div>
      </div>

      <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3 text-xs">
        <h3 className="font-semibold text-slate-300 flex items-center gap-1.5">
          <Layers className="w-4 h-4 text-indigo-400" /> Bundled Cloudstream Extensions Repositories
        </h3>
        <ul className="space-y-1.5 text-slate-400 font-mono text-[11px]">
          {CLOUDSTREAM_REPOS.map((repo, i) => (
            <li key={i} className="p-2 bg-slate-900 rounded border border-slate-800 break-all text-indigo-300">
              {repo}
            </li>
          ))}
        </ul>
      </div>

      <button
        onClick={generateAndDownloadZip}
        disabled={isExporting}
        className="w-full py-3 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition text-sm disabled:opacity-50"
      >
        {isExporting ? (
          <span>Packing ZIP Archive...</span>
        ) : downloadSuccess ? (
          <>
            <CheckCircle2 className="w-5 h-5 text-emerald-300" /> ZIP Downloaded Successfully!
          </>
        ) : (
          <>
            <HardDriveDownload className="w-5 h-5" /> Download apkpulse-stream-v1.2.0-update.zip
          </>
        )}
      </button>
    </div>
  );
};
