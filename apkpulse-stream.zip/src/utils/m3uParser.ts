import { Channel } from '../types';

export interface M3uParseResult {
  channels: Channel[];
  error?: string;
}

export function parseM3uText(text: string): Channel[] {
  const lines = text.split(/\r?\n/);
  const channels: Channel[] = [];

  let currentMetadata: {
    name?: string;
    logo?: string;
    group?: string;
  } = {};

  let channelCount = 1;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    if (!line) continue;

    if (line.startsWith('#EXTINF:')) {
      currentMetadata = {};

      // Extract tvg-logo if present
      const logoMatch = line.match(/(?:tvg-logo|logo)=["']([^"']+)["']/i);
      if (logoMatch && logoMatch[1]) {
        currentMetadata.logo = logoMatch[1];
      }

      // Extract group-title or category if present
      const groupMatch = line.match(/(?:group-title|tvg-group)=["']([^"']+)["']/i);
      if (groupMatch && groupMatch[1]) {
        currentMetadata.group = groupMatch[1];
      }

      // Extract Channel Name (after last comma)
      const commaIndex = line.lastIndexOf(',');
      if (commaIndex !== -1) {
        const rawName = line.substring(commaIndex + 1).trim();
        if (rawName) {
          currentMetadata.name = rawName;
        }
      }

      // Fallback name from tvg-name
      if (!currentMetadata.name) {
        const nameMatch = line.match(/tvg-name=["']([^"']+)["']/i);
        if (nameMatch && nameMatch[1]) {
          currentMetadata.name = nameMatch[1];
        }
      }
    } else if (line.startsWith('http://') || line.startsWith('https://') || line.startsWith('rtmp://')) {
      const name = currentMetadata.name || `IPTV Channel ${channelCount}`;
      const group = currentMetadata.group || 'General IPTV';
      const logo =
        currentMetadata.logo ||
        `https://images.unsplash.com/photo-1593784991095-a205069470b6?w=300&q=80`;

      channels.push({
        id: `m3u-${Date.now()}-${channelCount}`,
        channelNumber: channelCount,
        name: name,
        category: group,
        logo: logo,
        streamUrl: line,
        quality: line.includes('.m3u8') ? 'HD HLS' : 'Live Stream'
      });

      channelCount++;
      currentMetadata = {};
    }
  }

  return channels;
}

export const PRESET_M3U_PLAYLISTS = [
  {
    id: 'mahdi-iptv-main',
    title: 'Mahdi IPTV Live TV Playlist',
    description: 'Main custom live TV stream channels (mahdi_iptv.m3u8)',
    url: 'https://mahdiridoy.github.io/Tv/mahdi_iptv.m3u8'
  },
  {
    id: 'iptv-org-news',
    title: 'IPTV-Org Global News Channels',
    description: '100+ Free public live news streams worldwide',
    url: 'https://iptv-org.github.io/iptv/categories/news.m3u'
  },
  {
    id: 'iptv-org-movies',
    title: 'IPTV-Org Live Movies & Cinema',
    description: 'Free public movie broadcasting streams',
    url: 'https://iptv-org.github.io/iptv/categories/movies.m3u'
  },
  {
    id: 'iptv-org-sports',
    title: 'IPTV-Org Sports Channels',
    description: 'Live sports and racing TV broadcasts',
    url: 'https://iptv-org.github.io/iptv/categories/sports.m3u'
  }
];
