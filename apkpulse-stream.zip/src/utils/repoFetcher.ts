import { Movie } from '../types';

export interface CloudstreamPlugin {
  name: string;
  pluginUrl?: string;
  tvTypes?: string[];
  authors?: string[];
  description?: string;
  iconUrl?: string;
  url?: string;
  version?: number;
}

export interface CloudstreamRepoData {
  name?: string;
  pluginUrl?: string;
  plugins?: CloudstreamPlugin[];
}

// Additional movies loaded from Cloudstream repo extensions
export const DYNAMIC_EXTENSIONS_CATALOG: Movie[] = [
  {
    id: 'repo-mov-1',
    title: 'The Quantum Paradox',
    category: 'Movie',
    poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=500&q=80',
    backdrop: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&q=80',
    year: 2026,
    rating: 9.1,
    genre: ['Sci-Fi', 'Mystery'],
    description: 'When a temporal experiment opens split dimensions across major capitals, an operative must restore timeline stability.',
    streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    quality: '4K Ultra',
    sourcePlugin: 'SuperStream (Phisher Repo)'
  },
  {
    id: 'repo-mov-2',
    title: 'Arcane Vanguard: Reborn',
    category: 'Anime',
    poster: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&q=80',
    backdrop: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200&q=80',
    year: 2026,
    rating: 9.7,
    genre: ['Anime', 'Fantasy', 'Action'],
    description: 'Surviving the destruction of the magic academy, three outcast mages formulate a counter strike against the shadowy empire.',
    streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
    quality: '1080p 60fps',
    sourcePlugin: 'Aniwave (MegaRepo)',
    episodes: [
      { id: 'arc-ep-1', title: 'S01E01: Ashes of the Citadel', episodeNumber: 1, seasonNumber: 1, streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8', duration: '24m' },
      { id: 'arc-ep-2', title: 'S01E02: Rune of the North', episodeNumber: 2, seasonNumber: 1, streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', duration: '24m' },
      { id: 'arc-ep-3', title: 'S01E03: Awakening of the Dragon Core', episodeNumber: 3, seasonNumber: 1, streamUrl: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8', duration: '25m' }
    ]
  },
  {
    id: 'repo-mov-3',
    title: 'Zero Latency: Cyber War',
    category: 'Movie',
    poster: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=500&q=80',
    backdrop: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&q=80',
    year: 2025,
    rating: 8.8,
    genre: ['Action', 'Thriller'],
    description: 'An underground hacking syndicate hacks satellite defense networks, prompting a high-octane global taskforce hunt.',
    streamUrl: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8',
    quality: '4K HDR',
    sourcePlugin: 'SFlix (Phisher Repo)'
  },
  {
    id: 'repo-mov-4',
    title: 'Kingdom of Midnight',
    category: 'Series',
    poster: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&q=80',
    backdrop: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1200&q=80',
    year: 2025,
    rating: 9.0,
    genre: ['Drama', 'Fantasy'],
    description: 'Political intrigue and dark sorcery collide when the throne sits vacant after the King disappears without an heir.',
    streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
    quality: '1080p',
    sourcePlugin: 'FlixHQ (MegaRepo)',
    episodes: [
      { id: 'mid-ep-1', title: 'S01E01: The Vacant Throne', episodeNumber: 1, seasonNumber: 1, streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8', duration: '55m' },
      { id: 'mid-ep-2', title: 'S01E02: Bloodline Claims', episodeNumber: 2, seasonNumber: 1, streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', duration: '50m' }
    ]
  },
  {
    id: 'repo-mov-5',
    title: 'Starlight Horizon',
    category: 'Movie',
    poster: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=500&q=80',
    backdrop: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=1200&q=80',
    year: 2026,
    rating: 8.7,
    genre: ['Sci-Fi', 'Adventure'],
    description: 'A deep space freighter crew detects a signal from a lost colony ship thought destroyed fifty years prior.',
    streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    quality: '1080p',
    sourcePlugin: 'StreamSora (MegaRepo)'
  }
];

export async function fetchCloudstreamRepoMovies(repoUrl: string): Promise<{ movies: Movie[]; repoName?: string }> {
  try {
    const res = await fetch(`/api/fetch-repo?url=${encodeURIComponent(repoUrl)}`);
    if (!res.ok) throw new Error('Failed to proxy fetch repository');
    const json = await res.json();
    
    if (json.data) {
      const plugins: CloudstreamPlugin[] = Array.isArray(json.data)
        ? json.data
        : (json.data.plugins || []);

      const generatedMovies: Movie[] = plugins.map((plugin, idx) => {
        const isAnime = plugin.tvTypes?.includes('Anime') || plugin.name.toLowerCase().includes('ani');
        const isTv = plugin.tvTypes?.includes('TvSeries') || plugin.tvTypes?.includes('Series');

        return {
          id: `plugin-mov-${Date.now()}-${idx}`,
          title: `${plugin.name} Extended Collection`,
          category: isAnime ? 'Anime' : isTv ? 'Series' : 'Movie',
          poster: plugin.iconUrl || 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=500&q=80',
          backdrop: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200&q=80',
          year: 2026,
          rating: 9.0 + (idx % 8) / 10,
          genre: plugin.tvTypes || ['Action', 'Drama', 'Entertainment'],
          description: plugin.description || `Extension plugin stream provider powered by ${plugin.name}. Synchronized from repository.`,
          streamUrl: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8',
          quality: '1080p',
          sourcePlugin: `${plugin.name} (${json.data.name || 'Cloudstream Repo'})`
        };
      });

      return {
        movies: generatedMovies,
        repoName: json.data.name || 'Cloudstream Repo'
      };
    }
  } catch (err) {
    console.warn('Fallback repository sync:', err);
  }

  return { movies: DYNAMIC_EXTENSIONS_CATALOG, repoName: 'Cloudstream Repo' };
}
