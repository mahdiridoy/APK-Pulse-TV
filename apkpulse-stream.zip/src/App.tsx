/**
 * CineStream TV - Full-featured Live TV, Movies & Series App
 * @license Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Tv, Film, Search, Menu, RefreshCw, HardDriveDownload, Sparkles,
  ChevronRight, Play, Star, Settings as SettingsIcon, Monitor, Smartphone,
  Sliders, PlusCircle, Globe
} from 'lucide-react';

import { AppTab, Channel, Movie, ViewMode, AppUpdateInfo, MovieEpisode } from './types';
import { DEFAULT_CHANNELS } from './data/defaultChannels';
import { DEFAULT_MOVIES, CLOUDSTREAM_REPOS } from './data/defaultMovies';
import { parseM3uText, PRESET_M3U_PLAYLISTS } from './utils/m3uParser';
import { fetchCloudstreamRepoMovies, DYNAMIC_EXTENSIONS_CATALOG } from './utils/repoFetcher';

import { SplashAdModal } from './components/SplashAdModal';
import { UpdateModal } from './components/UpdateModal';
import { VideoPlayer } from './components/VideoPlayer';
import { ChannelSearchDrawer } from './components/ChannelSearchDrawer';
import { SideDrawer } from './components/SideDrawer';
import { TvRemoteOverlay } from './components/TvRemoteOverlay';
import { MovieCatalog } from './components/MovieCatalog';
import { SettingsView } from './components/SettingsView';
import { ZipExporter } from './components/ZipExporter';

export default function App() {
  // Application State
  const [showSplashAd, setShowSplashAd] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<AppTab>('livetv');
  const [viewMode, setViewMode] = useState<ViewMode>('phone'); // 'phone' | 'tv'

  // Data State
  const [channels, setChannels] = useState<Channel[]>(() => {
    try {
      const saved = localStorage.getItem('apkpulse_custom_channels');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {}
    return DEFAULT_CHANNELS;
  });
  const [movies, setMovies] = useState<Movie[]>(DEFAULT_MOVIES);
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(() => {
    return channels.length > 0 ? channels[0] : DEFAULT_CHANNELS[0];
  });
  const [activeMovieStream, setActiveMovieStream] = useState<{ movie: Movie; episode?: MovieEpisode } | null>(null);

  // Save channels to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem('apkpulse_custom_channels', JSON.stringify(channels));
    } catch (e) {}
  }, [channels]);

  // Modals & Drawers
  const [isSideDrawerOpen, setIsSideDrawerOpen] = useState<boolean>(false);
  const [isSearchDrawerOpen, setIsSearchDrawerOpen] = useState<boolean>(false);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState<boolean>(false);
  const [showZipModal, setShowZipModal] = useState<boolean>(false);

  // Update Status State
  const [updateInfo, setUpdateInfo] = useState<AppUpdateInfo>({
    currentVersion: '1.2.0',
    latestVersion: '1.2.0',
    updateAvailable: false,
    changelog: [
      'Cloudstream extensions auto-installer (phisher98 & MegaRepo)',
      'Left slide brightness & Right slide volume gesture controls',
      'Analog Channel UP/DOWN & Swipe channel swapping',
      'Right pop-in search drawer for Live TV & Movies',
      '5-second splash ad with version check'
    ]
  });

  // Category filter state for Live TV view
  const [selectedTvCategory, setSelectedTvCategory] = useState<string>('All');

  // Edge Swipe Tracking on Phone for Left Drawer
  const touchStartEdgeRef = useRef<number | null>(null);

  // Auto version check and Cloudstream Repos sync on launch
  useEffect(() => {
    fetch('/api/version')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.latestVersion) {
          setUpdateInfo((prev) => ({
            ...prev,
            latestVersion: data.latestVersion,
            updateAvailable: data.updateAvailable || false,
            downloadUrl: data.downloadUrl
          }));
        }
      })
      .catch(() => {});

    // Sync Cloudstream repos automatically on launch
    handleSyncRepos();

    // Auto-load main M3U playlist (mahdi_iptv.m3u8) on launch
    const mainM3uUrl = 'https://mahdiridoy.github.io/Tv/mahdi_iptv.m3u8';
    fetch(`/api/fetch-m3u?url=${encodeURIComponent(mainM3uUrl)}`)
      .then((res) => res.text())
      .then((text) => {
        const parsed = parseM3uText(text);
        if (parsed && parsed.length > 0) {
          setChannels((prev) => {
            const existingIds = new Set(prev.map((c) => c.id));
            const newChan = parsed.filter((c) => !existingIds.has(c.id));
            const combined = [...newChan, ...prev];
            // Update selected channel if first load
            if (!selectedChannel && combined.length > 0) {
              setSelectedChannel(combined[0]);
            }
            return combined;
          });
        }
      })
      .catch((err) => console.warn('Failed auto-loading main M3U:', err));
  }, []);

  const handleSyncRepos = async () => {
    let newMovies: Movie[] = [];
    for (const repoUrl of CLOUDSTREAM_REPOS) {
      const res = await fetchCloudstreamRepoMovies(repoUrl);
      if (res.movies && res.movies.length > 0) {
        newMovies = [...newMovies, ...res.movies];
      }
    }
    if (newMovies.length > 0) {
      setMovies((prev) => {
        // Prevent duplicate IDs
        const existingIds = new Set(prev.map((m) => m.id));
        const filteredNew = newMovies.filter((m) => !existingIds.has(m.id));
        return [...prev, ...filteredNew];
      });
    }
  };

  // Keyboard Navigation for TV D-Pad
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Toggle side drawer with 'm' or 'M' key or ArrowLeft on leftmost boundary
      if (e.key === 'm' || e.key === 'M') {
        setIsSideDrawerOpen((prev) => !prev);
      } else if (e.key === 's' || e.key === 'S') {
        setIsSearchDrawerOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Edge Swipe Handlers for Left Side Drawer (Requirement #4)
  const handleTouchStartGlobal = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 1) {
      touchStartEdgeRef.current = e.touches[0].clientX;
    }
  };

  const handleTouchEndGlobal = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchStartEdgeRef.current !== null) {
      const startX = touchStartEdgeRef.current;
      const endX = e.changedTouches[0].clientX;
      const deltaX = endX - startX;

      // Swipe from left edge (startX < 50px) to right (> 60px) opens Left Drawer
      if (startX < 60 && deltaX > 70) {
        setIsSideDrawerOpen(true);
      }
      touchStartEdgeRef.current = null;
    }
  };

  const tvCategories = ['All', ...Array.from(new Set(channels.map((c) => c.category)))];
  const filteredTvChannels = channels.filter(
    (c) => selectedTvCategory === 'All' || c.category === selectedTvCategory
  );

  const handleAddCustomM3u = (input: string) => {
    // If text looks like direct M3U content with #EXTINF
    if (input.includes('#EXTINF') || input.includes('http://') || input.includes('https://')) {
      if (input.startsWith('http') && !input.includes('\n')) {
        // It's a single URL
        fetch(`/api/fetch-m3u?url=${encodeURIComponent(input.trim())}`)
          .then((res) => res.text())
          .then((text) => {
            const parsed = parseM3uText(text);
            if (parsed.length > 0) {
              setChannels((prev) => [...prev, ...parsed]);
            } else {
              // Fallback single channel
              setChannels((prev) => [
                ...prev,
                {
                  id: `custom-${Date.now()}`,
                  channelNumber: prev.length + 1,
                  name: 'Custom IPTV Live Stream',
                  category: 'Custom IPTV',
                  logo: 'https://images.unsplash.com/photo-1593784991095-a205069470b6?w=300&q=80',
                  streamUrl: input.trim(),
                  quality: 'HD'
                }
              ]);
            }
          })
          .catch(() => {
            setChannels((prev) => [
              ...prev,
              {
                id: `custom-${Date.now()}`,
                channelNumber: prev.length + 1,
                name: 'Custom IPTV Stream',
                category: 'Custom IPTV',
                logo: 'https://images.unsplash.com/photo-1593784991095-a205069470b6?w=300&q=80',
                streamUrl: input.trim(),
                quality: 'HD'
              }
            ]);
          });
      } else {
        // Direct M3U text paste
        const parsed = parseM3uText(input);
        if (parsed.length > 0) {
          setChannels((prev) => [...prev, ...parsed]);
        }
      }
    }
  };

  return (
    <div
      onTouchStart={handleTouchStartGlobal}
      onTouchEnd={handleTouchEndGlobal}
      className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-none overflow-x-hidden"
    >
      {/* 1. 5-Second Splash Ad Modal on Startup */}
      {showSplashAd && (
        <SplashAdModal
          onAdComplete={() => setShowSplashAd(false)}
          statusText="Loading M3U playlists & checking GitHub updates..."
        />
      )}

      {/* 2. Top Header Navigation Bar */}
      <header className="sticky top-0 z-40 bg-slate-900/90 border-b border-slate-800/80 backdrop-blur-md px-4 sm:px-6 py-3 flex items-center justify-between">
        
        {/* Left: Logo & Menu Button */}
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setIsSideDrawerOpen(true)}
            className="p-2 bg-slate-800/80 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700/80 transition"
            title="Open Menu Drawer (Slide Left to Right)"
          >
            <Menu className="w-5 h-5 text-indigo-400" />
          </button>

          <div className="flex items-center space-x-2.5 cursor-pointer" onClick={() => setIsSideDrawerOpen(true)}>
            <img 
              src="/logo.jpg" 
              alt="ApkPulse Stream Logo" 
              className="w-9 h-9 rounded-xl object-cover border border-red-500/40 shadow-lg shadow-red-500/20"
            />
            <div>
              <h1 className="text-base font-black tracking-tight text-white flex items-center gap-1.5">
                ApkPulse <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/30 font-bold uppercase tracking-wide">Stream</span>
              </h1>
            </div>
          </div>
        </div>

        {/* Center: Tabs Switcher */}
        <div className="hidden md:flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab('livetv')}
            className={`px-4 py-1.5 rounded-lg flex items-center space-x-2 transition ${
              activeTab === 'livetv' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Tv className="w-3.5 h-3.5" />
            <span>Live TV</span>
          </button>
          <button
            onClick={() => setActiveTab('movies')}
            className={`px-4 py-1.5 rounded-lg flex items-center space-x-2 transition ${
              activeTab === 'movies' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Movies & Series</span>
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-1.5 rounded-lg flex items-center space-x-2 transition ${
              activeTab === 'settings' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <SettingsIcon className="w-3.5 h-3.5" />
            <span>Cloudstream Repos</span>
          </button>
        </div>

        {/* Right: Search & Actions */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsSearchDrawerOpen(true)}
            className="px-3 py-2 bg-indigo-950/60 hover:bg-indigo-900/60 border border-indigo-800/60 text-indigo-300 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition"
            title="Pop-in Search Drawer from Right"
          >
            <Search className="w-4 h-4 text-indigo-400" />
            <span className="hidden sm:inline">Search {activeTab === 'livetv' ? 'Live TV' : 'Movies'}</span>
          </button>

          <button
            onClick={() => setIsUpdateModalOpen(true)}
            className="p-2 bg-slate-800/80 hover:bg-slate-700 text-amber-400 rounded-xl border border-slate-700"
            title="Check GitHub Updates"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

      </header>

      {/* 3. Main Body View */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        
        {/* LIVE TV TAB */}
        {activeTab === 'livetv' && (
          <div className="space-y-6">
            
            {/* Primary Video Player Area */}
            {selectedChannel ? (
              <VideoPlayer
                channel={selectedChannel}
                channels={channels}
                onSelectChannel={setSelectedChannel}
                viewMode={viewMode}
                onClosePlayer={() => setSelectedChannel(null)}
              />
            ) : (
              <div className="w-full aspect-video bg-slate-900 rounded-2xl border border-slate-800 flex flex-col items-center justify-center p-6 text-center space-y-3 shadow-xl">
                <Tv className="w-12 h-12 text-slate-600" />
                <h3 className="text-lg font-bold text-slate-300">No Channel Selected</h3>
                <p className="text-xs text-slate-500">Select any Live TV channel from the grid below to start streaming.</p>
              </div>
            )}

            {/* Category Chips Bar */}
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none text-xs">
                {tvCategories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedTvCategory(cat)}
                    className={`px-4 py-2 rounded-xl border font-semibold whitespace-nowrap transition ${
                      selectedTvCategory === cat
                        ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-600/30'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              <span className="text-xs text-slate-500 font-medium shrink-0">
                {filteredTvChannels.length} Channels
              </span>
            </div>

            {/* Channel Cards Grid with Pop-In Search Card at End (Requirement #6) */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {filteredTvChannels.map((chan) => (
                <div
                  key={chan.id}
                  onClick={() => setSelectedChannel(chan)}
                  className={`p-3 rounded-2xl border cursor-pointer transition flex flex-col justify-between group shadow-lg ${
                    selectedChannel?.id === chan.id
                      ? 'bg-indigo-950/80 border-indigo-500 shadow-indigo-500/20 ring-1 ring-indigo-500'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700 hover:bg-slate-850'
                  }`}
                >
                  <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-950 border border-slate-800 mb-3">
                    <img
                      src={chan.logo}
                      alt={chan.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                    <div className="absolute top-2 left-2 px-1.5 py-0.5 bg-black/80 backdrop-blur-md rounded text-[10px] font-mono font-bold text-indigo-400">
                      CH {chan.channelNumber}
                    </div>
                    {chan.quality && (
                      <div className="absolute top-2 right-2 px-1.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded text-[9px] font-bold">
                        {chan.quality}
                      </div>
                    )}
                  </div>

                  <div>
                    <h4 className="font-bold text-sm text-slate-100 group-hover:text-indigo-300 truncate">
                      {chan.name}
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                      {chan.epgProgram || chan.category}
                    </p>
                  </div>
                </div>
              ))}

              {/* POP-IN RIGHT SEARCH CARD AT THE LAST CHANNEL POINT (Requirement #6) */}
              <div
                onClick={() => setIsSearchDrawerOpen(true)}
                className="p-4 rounded-2xl border border-dashed border-indigo-500/50 bg-indigo-950/30 hover:bg-indigo-900/40 cursor-pointer flex flex-col items-center justify-center text-center space-y-2 group transition shadow-lg"
                title="Search Live TV Channels (Pops out right drawer)"
              >
                <div className="p-3 bg-indigo-600/30 border border-indigo-500/50 rounded-full group-hover:scale-110 transition">
                  <Search className="w-6 h-6 text-indigo-400" />
                </div>
                <h4 className="font-bold text-xs text-indigo-300">Search Live TV Channels</h4>
                <p className="text-[10px] text-slate-400">Scroll past last channel to open search</p>
              </div>

            </div>

          </div>
        )}

        {/* MOVIES & SERIES TAB */}
        {activeTab === 'movies' && (
          <div className="space-y-6">
            {activeMovieStream && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="font-bold text-purple-300">
                    Now Playing: {activeMovieStream.movie.title} {activeMovieStream.episode ? `- ${activeMovieStream.episode.title}` : ''}
                  </span>
                  <button
                    onClick={() => setActiveMovieStream(null)}
                    className="text-xs text-slate-400 hover:text-white underline"
                  >
                    Close Movie Player
                  </button>
                </div>
                <VideoPlayer
                  channel={{
                    id: activeMovieStream.movie.id,
                    channelNumber: 1,
                    name: activeMovieStream.movie.title,
                    category: activeMovieStream.movie.category,
                    logo: activeMovieStream.movie.poster,
                    streamUrl: activeMovieStream.episode ? activeMovieStream.episode.streamUrl : activeMovieStream.movie.streamUrl,
                    quality: activeMovieStream.movie.quality
                  }}
                  channels={[]}
                  onSelectChannel={() => {}}
                  viewMode={viewMode}
                  onClosePlayer={() => setActiveMovieStream(null)}
                />
              </div>
            )}

            <MovieCatalog
              movies={movies}
              onPlayMovie={(movie, episode) => setActiveMovieStream({ movie, episode })}
              onOpenSearch={() => setIsSearchDrawerOpen(true)}
              onSyncRepos={handleSyncRepos}
            />
          </div>
        )}

        {/* SETTINGS / CLOUDSTREAM REPOS TAB */}
        {activeTab === 'settings' && (
          <SettingsView
            onAddM3uUrl={handleAddCustomM3u}
            onOpenZipExporter={() => setShowZipModal(true)}
            onCheckUpdates={() => setIsUpdateModalOpen(true)}
          />
        )}

      </main>

      {/* 4. Drawers & Modals */}
      
      {/* Side Navigation Drawer (Left) */}
      <SideDrawer
        isOpen={isSideDrawerOpen}
        onClose={() => setIsSideDrawerOpen(false)}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        viewMode={viewMode}
        onToggleViewMode={() => setViewMode(viewMode === 'phone' ? 'tv' : 'phone')}
        onOpenUpdateModal={() => setIsUpdateModalOpen(true)}
        onOpenZipExporter={() => setShowZipModal(true)}
      />

      {/* Channel & Movies Search Drawer (Right) */}
      <ChannelSearchDrawer
        isOpen={isSearchDrawerOpen}
        onClose={() => setIsSearchDrawerOpen(false)}
        mode={activeTab === 'movies' ? 'movies' : 'livetv'}
        channels={channels}
        movies={movies}
        onSelectChannel={(ch) => {
          setSelectedChannel(ch);
          setActiveTab('livetv');
        }}
        onSelectMovie={(mov) => {
          setActiveMovieStream({ movie: mov });
          setActiveTab('movies');
        }}
      />

      {/* App Version Update Modal */}
      {isUpdateModalOpen && (
        <UpdateModal
          updateInfo={updateInfo}
          onApplyUpdate={() => {
            setIsUpdateModalOpen(false);
          }}
          onDownloadZip={() => {
            setIsUpdateModalOpen(false);
            setShowZipModal(true);
          }}
          onClose={() => setIsUpdateModalOpen(false)}
        />
      )}

      {/* Export Update ZIP Modal */}
      {showZipModal && (
        <div className="fixed inset-0 z-[9500] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-xl">
            <button
              onClick={() => setShowZipModal(false)}
              className="absolute -top-10 right-0 text-slate-400 hover:text-white text-xs bg-slate-900 border border-slate-700 px-3 py-1.5 rounded-lg"
            >
              Close
            </button>
            <ZipExporter />
          </div>
        </div>
      )}

      {/* On-Screen Android TV D-Pad Remote Controller Simulator */}
      <TvRemoteOverlay
        onDpadUp={() => {}}
        onDpadDown={() => {}}
        onDpadLeft={() => setIsSideDrawerOpen(true)}
        onDpadRight={() => setIsSearchDrawerOpen(true)}
        onSelect={() => {}}
        onBack={() => {
          setIsSideDrawerOpen(false);
          setIsSearchDrawerOpen(false);
        }}
        onChannelUp={() => {
          if (selectedChannel) {
            const idx = channels.findIndex((c) => c.id === selectedChannel.id);
            const next = channels[(idx + 1) % channels.length];
            setSelectedChannel(next);
          }
        }}
        onChannelDown={() => {
          if (selectedChannel) {
            const idx = channels.findIndex((c) => c.id === selectedChannel.id);
            const prev = channels[(idx - 1 + channels.length) % channels.length];
            setSelectedChannel(prev);
          }
        }}
        onToggleSearch={() => setIsSearchDrawerOpen(true)}
        onToggleMenu={() => setIsSideDrawerOpen(true)}
      />

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800/80 px-6 py-4 text-center text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <span>CineStream TV v1.2.0 • Android Phone & Android TV Supported</span>
        <div className="flex items-center space-x-4 text-slate-400">
          <span>Swipe Gestures Enabled</span>
          <span>•</span>
          <span>Cloudstream Repo Extensions Loaded</span>
        </div>
      </footer>

    </div>
  );
}
