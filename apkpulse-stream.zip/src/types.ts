export type AppTab = 'livetv' | 'movies' | 'settings' | 'zip';

export type ViewMode = 'phone' | 'tv';

export interface Channel {
  id: string;
  name: string;
  category: string;
  logo: string;
  streamUrl: string;
  channelNumber: number;
  epgProgram?: string;
  quality?: string;
  language?: string;
}

export interface MovieEpisode {
  id: string;
  title: string;
  episodeNumber: number;
  seasonNumber?: number;
  streamUrl: string;
  duration?: string;
}

export interface Movie {
  id: string;
  title: string;
  category: 'Movie' | 'Series' | 'Anime';
  poster: string;
  backdrop?: string;
  year: number;
  rating: number;
  genre: string[];
  description: string;
  streamUrl: string;
  episodes?: MovieEpisode[];
  sourcePlugin?: string;
  quality?: string;
}

export interface CloudstreamPlugin {
  name: string;
  url: string;
  status: 'loaded' | 'loading' | 'error';
  itemCount: number;
  author?: string;
  description?: string;
  version?: string;
}

export interface CloudstreamRepo {
  originalUrl: string;
  httpUrl: string;
  name: string;
  pluginCount: number;
  plugins: CloudstreamPlugin[];
}

export interface AppUpdateInfo {
  currentVersion: string;
  latestVersion: string;
  updateAvailable: boolean;
  releaseDate?: string;
  changelog?: string[];
  downloadUrl?: string;
  githubUrl?: string;
}

export interface PlayerGestureState {
  isDraggingLeft: boolean; // Brightness
  isDraggingRight: boolean; // Volume
  brightness: number; // 0.1 to 2.0
  volume: number; // 0.0 to 1.0
  startY: number;
  startValue: number;
  showBrightnessIndicator: boolean;
  showVolumeIndicator: boolean;
  indicatorTimeout?: any;
}
