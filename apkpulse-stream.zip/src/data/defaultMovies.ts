import { Movie } from '../types';

export const CLOUDSTREAM_REPOS = [
  "cloudstreamrepo://raw.githubusercontent.com/phisher98/cloudstream-extensions-phisher/refs/heads/builds/repo.json",
  "cloudstreamrepo://raw.githubusercontent.com/self-similarity/MegaRepo/builds/repo.json"
];

export const DEFAULT_MOVIES: Movie[] = [
  {
    id: 'mov-1',
    title: 'Cyberpunk Odyssey 2099',
    category: 'Movie',
    poster: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&q=80',
    backdrop: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200&q=80',
    year: 2025,
    rating: 8.9,
    genre: ['Sci-Fi', 'Action', 'Cyberpunk'],
    description: 'In a rain-slicked metropolis dominated by mega-corporations, a rogue netrunner discovers an AI consciousness capable of altering reality itself.',
    streamUrl: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8',
    quality: '4K HDR',
    sourcePlugin: 'SuperStream (Phisher Repo)'
  },
  {
    id: 'mov-2',
    title: 'Shadow Realm Chronicles',
    category: 'Series',
    poster: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&q=80',
    backdrop: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&q=80',
    year: 2024,
    rating: 9.2,
    genre: ['Fantasy', 'Drama', 'Adventure'],
    description: 'When ancient portals reopen across seven continents, guardians from elemental tribes must unite to defeat the Void Lord.',
    streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
    quality: '1080p',
    sourcePlugin: 'MegaStream (MegaRepo)',
    episodes: [
      { id: 'ep-1', title: 'S01E01: The Portal Awakens', episodeNumber: 1, seasonNumber: 1, streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8', duration: '48m' },
      { id: 'ep-2', title: 'S01E02: Guardians of the Mist', episodeNumber: 2, seasonNumber: 1, streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', duration: '52m' },
      { id: 'ep-3', title: 'S01E03: The Obsidian Citadel', episodeNumber: 3, seasonNumber: 1, streamUrl: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8', duration: '50m' }
    ]
  },
  {
    id: 'mov-3',
    title: 'Neon Blade: Zero',
    category: 'Anime',
    poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=500&q=80',
    backdrop: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200&q=80',
    year: 2025,
    rating: 9.5,
    genre: ['Anime', 'Action', 'Mecha'],
    description: 'A young pilot syncs with a prohibited humanoid mech to defend Neo-Tokyo from interstellar colossal invaders.',
    streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    quality: '1080p 60fps',
    sourcePlugin: 'Aniwave (MegaRepo)'
  },
  {
    id: 'mov-4',
    title: 'Galactic Horizon',
    category: 'Movie',
    poster: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=500&q=80',
    backdrop: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=1200&q=80',
    year: 2024,
    rating: 8.6,
    genre: ['Sci-Fi', 'Thriller'],
    description: 'An deep-space exploration vessel stumbles upon an abandoned space station harboring quantum zero-point energy.',
    streamUrl: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8',
    quality: '4K Ultra',
    sourcePlugin: 'Sflix (Phisher Repo)'
  },
  {
    id: 'mov-5',
    title: 'The Silent Alpine',
    category: 'Movie',
    poster: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=500&q=80',
    backdrop: 'https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?w=1200&q=80',
    year: 2023,
    rating: 8.3,
    genre: ['Mystery', 'Thriller'],
    description: 'Trapped during a high-altitude blizzard in the Swiss Alps, five strangers realize one among them is a notorious espionage agent.',
    streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
    quality: '1080p',
    sourcePlugin: 'FlixHQ (MegaRepo)'
  },
  {
    id: 'mov-6',
    title: 'Dynasty of Dragons',
    category: 'Series',
    poster: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=500&q=80',
    backdrop: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&q=80',
    year: 2025,
    rating: 9.1,
    genre: ['Historical', 'Action', 'Fantasy'],
    description: 'An epic historical drama following the rise of the Tang dynasty dragon masters fighting off dark warlords.',
    streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    quality: '1080p',
    sourcePlugin: 'DramaCool (Phisher Repo)',
    episodes: [
      { id: 'ep-101', title: 'Episode 1: The Emperor Covenant', episodeNumber: 1, seasonNumber: 1, streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', duration: '45m' },
      { id: 'ep-102', title: 'Episode 2: Blade of Phoenix', episodeNumber: 2, seasonNumber: 1, streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8', duration: '46m' }
    ]
  }
];
