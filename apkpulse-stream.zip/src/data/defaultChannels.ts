import { Channel } from '../types';

export const DEFAULT_CHANNELS: Channel[] = [
  {
    id: 'ch-1',
    channelNumber: 1,
    name: 'BBC News HD',
    category: 'News',
    logo: 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?w=300&q=80',
    streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    epgProgram: 'Global News Hour Live & World Weather',
    quality: '1080p',
    language: 'English'
  },
  {
    id: 'ch-2',
    channelNumber: 2,
    name: 'Sky Sports Ultra',
    category: 'Sports',
    logo: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=300&q=80',
    streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
    epgProgram: 'Premier League Match Highlights & Live Commentary',
    quality: '4K',
    language: 'English'
  },
  {
    id: 'ch-3',
    channelNumber: 3,
    name: 'CineMax Movies HD',
    category: 'Movies',
    logo: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=300&q=80',
    streamUrl: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8',
    epgProgram: 'Tears of Steel - Sci-Fi Feature Film',
    quality: '1080p',
    language: 'English'
  },
  {
    id: 'ch-4',
    channelNumber: 4,
    name: 'NatGeo Wild World',
    category: 'Documentary',
    logo: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&q=80',
    streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    epgProgram: 'Serengeti Migration & Deep Ocean Explorers',
    quality: '1080p',
    language: 'English'
  },
  {
    id: 'ch-5',
    channelNumber: 5,
    name: 'Cartoon Network Kids',
    category: 'Kids',
    logo: 'https://images.unsplash.com/photo-1563089145-599997674d42?w=300&q=80',
    streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
    epgProgram: 'The Animated Universe & Superhero Adventures',
    quality: '720p',
    language: 'English'
  },
  {
    id: 'ch-6',
    channelNumber: 6,
    name: 'MTV Live Hits',
    category: 'Music',
    logo: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&q=80',
    streamUrl: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8',
    epgProgram: 'Global Top 40 Countdown & Live Concerts',
    quality: '1080p',
    language: 'English'
  },
  {
    id: 'ch-7',
    channelNumber: 7,
    name: 'HBO Max Cinema',
    category: 'Movies',
    logo: 'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=300&q=80',
    streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    epgProgram: 'Blockbuster Premiere Night',
    quality: '4K',
    language: 'English'
  },
  {
    id: 'ch-8',
    channelNumber: 8,
    name: 'ESPN World Sports',
    category: 'Sports',
    logo: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=300&q=80',
    streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
    epgProgram: 'NBA Finals Rewind & UEFA Champions League',
    quality: '1080p',
    language: 'English'
  },
  {
    id: 'ch-9',
    channelNumber: 9,
    name: 'Discovery Planet',
    category: 'Documentary',
    logo: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=300&q=80',
    streamUrl: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8',
    epgProgram: 'Mythbusters & Cosmos Exploration',
    quality: '1080p',
    language: 'English'
  },
  {
    id: 'ch-10',
    channelNumber: 10,
    name: 'CNN International Live',
    category: 'News',
    logo: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=300&q=80',
    streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    epgProgram: 'Global Breaking News & Financial Markets',
    quality: '1080p',
    language: 'English'
  }
];
